package com.sense.security.util;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.within;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import java.util.Date;
import java.util.List;

import org.assertj.core.util.DateUtil;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.util.ReflectionTestUtils;

import com.sense.security.model.JwtUserDetails;

import io.jsonwebtoken.Clock;
import io.jsonwebtoken.ExpiredJwtException;

public class JwtTokenUtilTest {

	private static final String TEST_USERNAME = "user101";

	@InjectMocks
	private JwtTokenUtil jwtTokenUtil;

	@Mock
	private Clock clockMock;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);

		ReflectionTestUtils.setField(jwtTokenUtil, "expiration", 3600L);
		ReflectionTestUtils.setField(jwtTokenUtil, "secret", "mySecret");
	}

	@Test
	public void testGetUserNameFromToken() {
		when(clockMock.now()).thenReturn(DateUtil.now());
		String token = generateToken();
		assertThat(jwtTokenUtil.getUserNameFromToken(token)).isEqualTo(TEST_USERNAME);
	}

	@Test
	public void testGetIssuedAtDateFromToken() {
		final Date now = DateUtil.now();
		when(clockMock.now()).thenReturn(now);
		String token = generateToken();
		assertThat(jwtTokenUtil.getIssuedAtDateFromToken(token)).isInSameMinuteWindowAs(now);
	}

	@Test
	public void testGetExpirationDateFromToken() {
		final Date now = DateUtil.now();
		when(clockMock.now()).thenReturn(now);
		String token = generateToken();
		final Date expirationDateFromToken = jwtTokenUtil.getExpirationDateFromToken(token);
		assertThat(DateUtil.timeDifference(expirationDateFromToken, now)).isCloseTo(3600000L, within(1000L));
	}

	@Test(expected = ExpiredJwtException.class)
	public void testExpiredTokenCannotBeRefreshed() throws Exception {
		when(clockMock.now()).thenReturn(DateUtil.yesterday());
		String token = generateToken();
		jwtTokenUtil.canTokenBeRefreshed(token, DateUtil.tomorrow());
	}

	@Test
	public void testGetAuthoritiesFromToken() {
		when(clockMock.now()).thenReturn(DateUtil.now());
		String token = generateToken();
		List<String> authorities = jwtTokenUtil.getAuthoritiesFromToken(token);
		String authority = authorities.stream().filter(a -> a.equals("ADMIN")).findAny().orElse(null);
		assertThat(authority).isEqualTo("ADMIN");
	}

	@Test
	public void testChangedPasswordCannotBeRefreshed() throws Exception {
		when(clockMock.now()).thenReturn(DateUtil.now());
		String token = generateToken();
		assertThat(jwtTokenUtil.canTokenBeRefreshed(token, DateUtil.tomorrow())).isFalse();
	}

	@Test
	public void testCanRefreshToken() throws Exception {
		when(clockMock.now()).thenReturn(DateUtil.now()).thenReturn(DateUtil.tomorrow());
		String firstToken = generateToken();
		String refreshedToken = jwtTokenUtil.refreshToken(firstToken);
		Date firstTokenDate = jwtTokenUtil.getIssuedAtDateFromToken(firstToken);
		Date refreshedTokenDate = jwtTokenUtil.getIssuedAtDateFromToken(refreshedToken);
		assertThat(firstTokenDate).isBefore(refreshedTokenDate);
	}

	@Test
	public void testCanValidateToken() throws Exception {
		when(clockMock.now()).thenReturn(DateUtil.now());
		UserDetails userDetails = mock(UserDetails.class);
		when(userDetails.getUsername()).thenReturn(TEST_USERNAME);

		String token = generateToken();
		assertThat(jwtTokenUtil.validateToken(token)).isTrue();
	}

	public String generateToken() {
		UserDetails userDetails = org.springframework.security.core.userdetails.User.withDefaultPasswordEncoder()
				.username("user101").password("password").authorities("CREATE_USER","ADMIN").build();
		final String token = jwtTokenUtil
				.generateToken(new JwtUserDetails(userDetails.getUsername(), userDetails.getUsername(), null,
						userDetails.getPassword(), userDetails.getAuthorities(), userDetails.isEnabled(), null, null));
		return token;
	}
}

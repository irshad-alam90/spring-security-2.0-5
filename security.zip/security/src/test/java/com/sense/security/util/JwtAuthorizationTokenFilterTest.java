package com.sense.security.util;

import static org.mockito.Mockito.mock;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class JwtAuthorizationTokenFilterTest {

    @InjectMocks
    private JwtAuthorizationTokenFilter jwtAuthorizationTokenFilter;

    @Mock
    private JwtTokenUtil jtu;

    @Test
    public void testDoFilterInternal() throws ServletException, IOException {
        String token = "ksfldkjeqru4rkelrjlffjerrgler";
        HttpServletRequest request = mock(HttpServletRequest.class);
        HttpServletResponse response = mock(HttpServletResponse.class);
        FilterChain filterChain = mock(FilterChain.class);

        Mockito.when(request.getHeader(Mockito.anyString())).thenReturn("Bearer " + token);
        Mockito.when(jtu.getUserNameFromToken(Mockito.anyString())).thenReturn("user1");

        List<String> authorities = new ArrayList<>();
        authorities.add("CREATE_USER");
        Mockito.when(jtu.getAuthoritiesFromToken(Mockito.anyString())).thenReturn(authorities);
        Mockito.when(jtu.validateToken(Mockito.anyString())).thenReturn(true);
        jwtAuthorizationTokenFilter.doFilterInternal(request, response, filterChain);
    }
}

package com.sense.security.service;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.neo4j.ogm.session.Session;
import org.neo4j.ogm.session.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.neo4j.repository.config.EnableNeo4jRepositories;
import org.springframework.data.neo4j.transaction.Neo4jTransactionManager;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.sense.security.model.JwtUserDetails;
import com.sense.sensemodel.model.assets.AssetType;
import com.sense.sensemodel.model.users.AccessRight;
import com.sense.sensemodel.model.users.Department;
import com.sense.sensemodel.model.users.Role;
import com.sense.sensemodel.model.users.User;
import com.sense.sensemodel.repository.users.DepartmentRepository;
import com.sense.sensemodel.repository.users.UserRepository;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { JwtUserDetailsServiceTest.TestConfig.class })
@Transactional
public class JwtUserDetailsServiceTest {

    @Autowired
    private JwtUserDetailsService userDetailsService;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private DepartmentRepository departmentRepository;

    @Test(expected = RuntimeException.class)
    public void testLoadUserByUserNameIfUserNotFound() {
        String userId = "user101";
        User user = new User();
        user.setUserId(userId);
        userDetailsService.loadUserByUsername(userId);
    }

    @Test
    public void testLoadUserByUserName() {
        String userId = "user101";
        Set<AccessRight> accessRights = new HashSet<>();
        AccessRight accessRight = new AccessRight("CREATE_USER");
        accessRights.add(accessRight);
        Map<String, String> departmentRole = new HashMap<>();
        departmentRole.put("dep101", "r101");
        Set<String> orgParts = new HashSet<>();
        orgParts.add("d101");
        User user = new User("user101", "user1", "user1@gmail.com", "password", "Manager", departmentRole, accessRights,
                orgParts, "c101");
        user.setUserId(userId);
        userRepository.save(user);

        AssetType assetType = new AssetType();
        assetType.setType("assetType1");
        assetType.setCompany("c101");
        Set<AssetType> accessibleAssetTypes = new HashSet<>(Arrays.asList(assetType));
        Role role = new Role("Manager", null, accessRights);
        role.setCode("r101");
        Department department = new Department("department1", "c101", role, accessibleAssetTypes);
        department.setCode("dep101");
        departmentRepository.save(department);

        JwtUserDetails userDetails = userDetailsService.loadUserByUsername(userId);
        assertEquals(user.getUserId(), userDetails.getUsername());
    }

    @Configuration
    @EntityScan(basePackages = "com.sense.sensemodel")
    @ComponentScan({ "com.sense.security.service" })
    @EnableNeo4jRepositories("com.sense.sensemodel.repository")
    public static class TestConfig {
        @Bean
        public SessionFactory sessionFactory() {
            // with domain entity base package(s)
            return new SessionFactory("com.sense.sensemodel");
        }

        @Bean
        public Neo4jTransactionManager transactionManager() {
            return new Neo4jTransactionManager(sessionFactory());
        }

        @Bean
        public Session session() {
            return transactionManager().getSessionFactory().openSession();
        }
    }
}

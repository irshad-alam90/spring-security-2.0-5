package com.sense.security.model;

import java.io.Serializable;

public class JwtAuthenticationResponse implements Serializable {

    private static final long serialVersionUID = 1250166508152483573L;

    private final String token;

    private final String userCompany; 
    
    public JwtAuthenticationResponse(String token, String company) {
        this.token = token;
        this.userCompany = company;
    }

    public String getToken() {
        return this.token;
    }

	public String getUserCompany() {
		return userCompany;
	}
}

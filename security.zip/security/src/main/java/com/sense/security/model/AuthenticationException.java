package com.sense.security.model;

public class AuthenticationException extends RuntimeException {
    private static final long serialVersionUID = 2770971986114802070L;

	public AuthenticationException(String message, Throwable cause) {
        super(message, cause);
    }
}

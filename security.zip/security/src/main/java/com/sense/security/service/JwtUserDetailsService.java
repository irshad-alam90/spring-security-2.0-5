package com.sense.security.service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.sense.security.model.JwtUserDetails;
import com.sense.sensemodel.model.users.AccessType;
import com.sense.sensemodel.model.users.Department;
import com.sense.sensemodel.model.users.User;
import com.sense.sensemodel.repository.users.DepartmentRepository;
import com.sense.sensemodel.repository.users.UserRepository;

@Service
public class JwtUserDetailsService implements UserDetailsService {

    @Autowired
    private DepartmentRepository departmentRepository;

    @Autowired
    private UserRepository userRepository;

    // TODO: MOVE TO CALL USER SERVICE
    @Override
    public JwtUserDetails loadUserByUsername(String userId) throws UsernameNotFoundException {
        User user = userRepository.findByUserIdAndEnabled(userId, true)
                .orElseThrow(() -> new UsernameNotFoundException("user not found:" + userId));

        Set<Department> userDepartments = departmentRepository
                .findByCodeInAndActiveInd(user.getDepartmentRoles().keySet(), true);
        String userCompany = user.getCompanyId();
        Set<String> accessibleOrgParts = new HashSet<>();
        accessibleOrgParts.addAll(user.getOrgParts());
        Set<AccessType> accessTypeNames = user.getAccessRights().stream()
                .map(r -> AccessType.valueOf(r.getAccessType())).collect(Collectors.toSet());
        Set<String> accessibleAssetTypes = userDepartments.stream().flatMap(d -> d.getAccessibleAssetTypes().stream())
                .map(at -> at.getType()).collect(Collectors.toSet());

        Set<String> authorities = new HashSet<>();
        accessibleOrgParts.stream().forEach(o -> authorities.add("ORGPART_" + o));
        accessibleAssetTypes.stream().forEach(at -> authorities.add("ASSETTYPE_" + at));
        accessTypeNames.stream().forEach(ac -> authorities.add(ac.name()));

        JwtUserDetails jwtUserDetails = new JwtUserDetails(user.getUserId(), user.getName(), user.getEmail(),
                user.getPswrd(), mapToGrantedAuthorities(authorities), user.isEnabled(),
                user.getLastPasswordResetDate(), userCompany);
        return jwtUserDetails;
    }

    private List<GrantedAuthority> mapToGrantedAuthorities(Set<String> authorities) {
        return authorities.stream().map(authority -> new SimpleGrantedAuthority(authority))
                .collect(Collectors.toList());
    }
}

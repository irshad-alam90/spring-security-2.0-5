package com.sense.security.model;

import java.io.Serializable;

public class JwtAuthenticationRequest implements Serializable {
	private static final long serialVersionUID = 2774152833171939778L;

	private String userId;
	private String password;
	private String newPassword;

	public JwtAuthenticationRequest() {
		super();
	}

	public JwtAuthenticationRequest(String userId, String password) {
		this.setUserId(userId);
		this.setPassword(password);
	}

	public JwtAuthenticationRequest(String userId, String password, String newPassword) {
		this.setUserId(userId);
		this.setPassword(password);
		this.setNewPassword(newPassword);
	}

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getNewPassword() {
		return newPassword;
	}

	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}
}

package com.sense.security.util;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import io.jsonwebtoken.ExpiredJwtException;

@Component
public class JwtAuthorizationTokenFilter extends OncePerRequestFilter {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	private final UserDetailsService userDetailsService;
	private final JwtTokenUtil jwtTokenUtil;
	private final String tokenHeader;

	public JwtAuthorizationTokenFilter(UserDetailsService userDetailsService, JwtTokenUtil jwtTokenUtil) {
		this.userDetailsService = userDetailsService;
		this.jwtTokenUtil = jwtTokenUtil;
		this.tokenHeader = "Authorization";
	}

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
			throws ServletException, IOException {
		logger.debug("processing authentication for '{}'", request.getRequestURL());
		final String requestHeader = request.getHeader(this.tokenHeader);
		String userName = null;
		String authToken = null;
		if (requestHeader != null && requestHeader.startsWith("Bearer ")) {
			authToken = requestHeader.substring(7);
			try {
				userName = jwtTokenUtil.getUserNameFromToken(authToken);
			} catch (IllegalArgumentException e) {
				logger.error("an error occured during getting username from token", e);
			} catch (ExpiredJwtException e) {
				logger.warn("the token is expired and not valid anymore", e);
				throw e;
			} catch (Exception e) {
				logger.error("an error occured processing info from token", e);
			}
		} else {
			logger.warn("couldn't find bearer string, will ignore the header");
		}

		logger.debug("checking authentication for user '{}'", userName);
		if (userName != null && SecurityContextHolder.getContext().getAuthentication() == null && authToken != null) {
			logger.debug("security context was null, so authorizating user");
			List<String> authorities = jwtTokenUtil.getAuthoritiesFromToken(authToken);
			if (authorities != null && jwtTokenUtil.validateToken(authToken)) {
				// TODO: GET DATA FROM CACHE AND LOAD AUTHORITIES FROM THERE SO THAT ORG CHANGES CAN REFLECT
				// CHECK IF USER IS DISABLED
				//UserDetails userDetails = this.userDetailsService.loadUserByUsername(username);
				UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(userName,
						null, authorities.stream().map(SimpleGrantedAuthority::new).collect(Collectors.toList()));
				authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
				logger.info("authorized user '{}', setting security context", userName);
				SecurityContextHolder.getContext().setAuthentication(authentication);
			}
		}
		chain.doFilter(request, response);
	}
}

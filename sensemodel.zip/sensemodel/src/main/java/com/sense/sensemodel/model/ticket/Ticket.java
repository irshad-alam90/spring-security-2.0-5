package com.sense.sensemodel.model.ticket;

import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.neo4j.ogm.annotation.GeneratedValue;
import org.neo4j.ogm.annotation.Id;
import org.neo4j.ogm.annotation.NodeEntity;
import org.neo4j.ogm.annotation.Properties;
import org.neo4j.ogm.annotation.Relationship;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;

@NodeEntity
public class Ticket {
	@Id
	@GeneratedValue
	@JsonIgnore
	private Long id;

	@ApiModelProperty(hidden = true)
	private String code = UUID.randomUUID().toString();

	private String assetCode;

	@Relationship(type = "TYPE_OF_TICKET")
	private TicketType ticketType;

	@Relationship(type = "TICKET_REPORT")
	private Set<TicketReport> ticketReports = new HashSet<>();

	@Properties
	private Map<String, String> ticketFields = new HashMap<>();

	private String assignedTo;

	private String state;

	private Date stateChangeTime;

	private String stateChangeReason;

	private String stateChangedBy;

	private String generatedBy;

	private Date creationTime;

	private String priority;

	private Date lastAutoHealTime;

	public Ticket() {
	}

	public Ticket(TicketType type, String stateChangedBy, String generatedBy, String priority, String assetCode,
			Map<String, String> ticketFields) {
		this.ticketType = type;
		this.stateChangedBy = stateChangedBy;
		this.generatedBy = generatedBy;
		// initially assigned is mapped to generated to avoid null regex error
		this.assignedTo = generatedBy;
		this.priority = priority;
		this.assetCode = assetCode;
		this.state = TicketState.CREATED.name();
		this.ticketFields = ticketFields;
		this.stateChangeReason = "created";
		Date dt = new Date();
		this.creationTime = dt;
		this.stateChangeTime = dt;
		if (type.isAutoHealable()) {
			this.lastAutoHealTime = dt;
		}
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public TicketType getType() {
		return ticketType;
	}

	public void setType(TicketType type) {
		this.ticketType = type;
	}

	public Set<TicketReport> getTicketReports() {
		return ticketReports;
	}

	public void setTicketReports(Set<TicketReport> ticketReports) {
		this.ticketReports = ticketReports;
	}

	public String getAssignedTo() {
		return assignedTo;
	}

	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Date getStateChangeTime() {
		return stateChangeTime;
	}

	public void setStateChangeTime(Date stateChangeTime) {
		this.stateChangeTime = stateChangeTime;
	}

	public String getStateChangeReason() {
		return stateChangeReason;
	}

	public void setStateChangeReason(String stateChangeReason) {
		this.stateChangeReason = stateChangeReason;
	}

	public String getStateChangedBy() {
		return stateChangedBy;
	}

	public void setStateChangedBy(String stateChangedBy) {
		this.stateChangedBy = stateChangedBy;
	}

	public String getGeneratedBy() {
		return generatedBy;
	}

	public void setGeneratedBy(String generatedBy) {
		this.generatedBy = generatedBy;
	}

	public Date getCreationTime() {
		return creationTime;
	}

	public void setCreationTime(Date creationTime) {
		this.creationTime = creationTime;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getAssetCode() {
		return assetCode;
	}

	public void setAssetCode(String assetCode) {
		this.assetCode = assetCode;
	}

	public Map<String, String> getTicketFields() {
		return ticketFields;
	}

	public void setTicketFields(Map<String, String> ticketFields) {
		this.ticketFields = ticketFields;
	}

	public Date getLastAutoHealTime() {
		return lastAutoHealTime;
	}

	public void setLastAutoHealTime(Date lastAutoHealTime) {
		this.lastAutoHealTime = lastAutoHealTime;
	}
}

package com.sense.sensemodel.repository.organisation;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.data.neo4j.annotation.Depth;
import org.springframework.data.neo4j.annotation.Query;
import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.stereotype.Repository;

import com.sense.sensemodel.model.organisation.Organisation;

@Repository
public interface OrganisationRepository extends Neo4jRepository<Organisation, Long> {
	Optional<Organisation> findByEntityIdAndTypeAndActiveInd(String entityId, String type, boolean activeInd);

	Optional<Organisation> findByEntityIdAndActiveInd(String entityId, boolean activeInd);

	Set<Organisation> findByEntityIdInAndActiveInd(Set<String> entityIds, boolean activeInd);

	@Query("Match (s:Organisation)<-[:SUB_ORG*]-(o:Organisation) "
            + "WHERE s.activeInd = true AND o.entityId = {0} SET s.activeInd = false SET o.activeInd = false")
    public void deleteHierarchy(String entityId);

	//Use sparingly. Could load the whole organization to memory. 
	@Query("Match (s:Organisation)<-[:SUB_ORG*]-(o:Organisation) "
			+ "WHERE s.activeInd = true AND s.type = {0} AND o.entityId = {1} RETURN s")
	public List<Organisation> findActiveSubOrgsByType(String type, String entityId, @Depth int depth);

	@Query("Match (s:Organisation)<-[:SUB_ORG*]-(o:Organisation) "
			+ "WHERE s.activeInd = true AND o.entityId in {0} RETURN s.entityId")
	public Set<String> findActiveSubOrgsIdsByOrgIdIn(Set<String> entityId);
	
	@Query("Match (o:Organisation) WHERE o.activeInd = true AND o.entityId = {0} RETURN o")
	public Optional<Organisation> findActiveEntityWithDepthOne(String entityId);
	
	@Query("Match (p:Organisation)-[:SUB_ORG*]->(o:Organisation) "
			+ "WHERE o.activeInd = true AND p.activeInd = true AND o.entityId = {0} and p.entityId in {1} RETURN o")
	public Optional<Organisation> isOrgAccessible(String orgId, Set<String> userOrgParts);

	@Query("MATCH (u:Organisation {activeInd: true}) where u.entityId in {1} with u "
			+ "MATCH (c:Organisation{activeInd: true})<-[:SUB_ORG]-(p:Organisation {entityId:{0}}) "
			+ "where (c)-[:SUB_ORG]->(u) OR (c)<-[:SUB_ORG]-(u) OR c.entityId in {1} RETURN c")
	public Set<Organisation> getAccessibleChildren(String parentOrgId, Set<String> userOrgParts);
}

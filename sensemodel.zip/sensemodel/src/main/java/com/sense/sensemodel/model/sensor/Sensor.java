package com.sense.sensemodel.model.sensor;

import java.util.Date;
import java.util.UUID;

import org.neo4j.ogm.annotation.GeneratedValue;
import org.neo4j.ogm.annotation.Id;
import org.neo4j.ogm.annotation.NodeEntity;
import org.neo4j.ogm.annotation.Relationship;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;

@NodeEntity
public class Sensor {
	@Id
	@GeneratedValue
	@JsonIgnore
	private Long id;

	@ApiModelProperty(hidden = true)
	private String code = UUID.randomUUID().toString();

	@ApiModelProperty(hidden = true)
	private String assetCode;
	
	@ApiModelProperty(hidden = true)
	private String companyCode;
	
	@ApiModelProperty(hidden = true)
	private boolean activeInd;
	
	@ApiModelProperty(hidden = true)
	private boolean online;
	
	private String macAddress;
	
	private String uuid;
	
	@ApiModelProperty(hidden = true)
	private String hubCode;
	
	@ApiModelProperty(hidden = true)
	private String sensorTypeCode;
	
	@ApiModelProperty(hidden = true)
	private Date creationDate;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAssetCode() {
		return assetCode;
	}

	public void setAssetCode(String assetCode) {
		this.assetCode = assetCode;
	}

	public boolean isActiveInd() {
		return activeInd;
	}

	public void setActiveInd(boolean activeInd) {
		this.activeInd = activeInd;
	}

	public String getMacAddress() {
		return macAddress;
	}

	public void setMacAddress(String macAddress) {
		this.macAddress = macAddress;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public boolean isOnline() {
		return online;
	}

	public void setOnline(boolean online) {
		this.online = online;
	}

	public String getHubCode() {
		return hubCode;
	}

	public void setHubCode(String hubCode) {
		this.hubCode = hubCode;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getSensorTypeCode() {
		return sensorTypeCode;
	}

	public void setSensorTypeCode(String sensorTypeCode) {
		this.sensorTypeCode = sensorTypeCode;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}
}

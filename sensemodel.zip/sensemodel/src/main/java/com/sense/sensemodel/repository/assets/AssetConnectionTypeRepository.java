package com.sense.sensemodel.repository.assets;

import java.util.List;
import java.util.Optional;

import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.stereotype.Repository;

import com.sense.sensemodel.model.assets.AssetConnectionType;

@Repository
public interface AssetConnectionTypeRepository extends Neo4jRepository<AssetConnectionType, Long>{
	
	List<AssetConnectionType> findByCompany(String company);
	
	Optional<AssetConnectionType> findByCompanyAndType(String company, String type);
}

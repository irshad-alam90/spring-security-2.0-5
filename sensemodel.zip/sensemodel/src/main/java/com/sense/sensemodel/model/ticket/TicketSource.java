package com.sense.sensemodel.model.ticket;

public enum TicketSource {
	USER, SENSOR, SERVICE
}

package com.sense.sensemodel.repository.command;

import java.util.Set;

import org.springframework.data.neo4j.annotation.Query;
import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.stereotype.Repository;

import com.sense.sensemodel.model.command.SensorCommand;

@Repository
public interface SensorCommandRepository extends Neo4jRepository<SensorCommand, Long> {

	@Query("MATCH (c:SensorCommand) where c.sensorId={0} and datetime(c.creationTime) > datetime({1}) "
			+ "and c.commandStatus='CREATED' with c.commandName as cname , max(datetime(c.creationTime)) as mtime "
			+ "MATCH (r:SensorCommand) where r.commandName=cname and datetime(r.creationTime)=mtime return r")
	Set<SensorCommand> findLatestBySensorIdAfterTime(String sensorId, String creationTime);
}

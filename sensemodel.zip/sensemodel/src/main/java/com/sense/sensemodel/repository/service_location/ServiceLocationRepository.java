package com.sense.sensemodel.repository.service_location;

import java.util.Optional;
import java.util.Set;

import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.stereotype.Repository;

import com.sense.sensemodel.model.service_location.ServiceLocation;

@Repository
public interface ServiceLocationRepository extends Neo4jRepository<ServiceLocation, Long> {
	Optional<ServiceLocation> findByNameAndVersion(String name, String version);

	Set<ServiceLocation> findByServiceTypeIn(Set<String> serviceTypes);
}

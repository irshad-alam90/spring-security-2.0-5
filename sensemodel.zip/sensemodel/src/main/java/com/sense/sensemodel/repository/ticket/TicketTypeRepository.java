package com.sense.sensemodel.repository.ticket;

import java.util.Optional;
import java.util.Set;

import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.stereotype.Repository;

import com.sense.sensemodel.model.ticket.TicketType;

@Repository
public interface TicketTypeRepository extends Neo4jRepository<TicketType, Long> {
	Optional<TicketType> findByTypeAndCompany(String type, String company);

	Optional<TicketType> findByTypeAndCompanyAndAssetType(String type, String company, String assetType);

	Set<TicketType> findByCompany(String company);

	Set<TicketType> findByCompanyAndAssetType(String company, String assetType);
}

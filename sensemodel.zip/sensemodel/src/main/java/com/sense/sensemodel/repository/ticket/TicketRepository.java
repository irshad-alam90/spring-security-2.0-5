package com.sense.sensemodel.repository.ticket;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.data.neo4j.annotation.Query;
import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.stereotype.Repository;

import com.sense.sensemodel.model.ticket.Ticket;
import com.sense.sensemodel.model.ticket.TicketState;

@Repository
public interface TicketRepository extends Neo4jRepository<Ticket, Long> {
	Optional<Ticket> findByCode(String code);
	
	Set<Ticket> findByCodeIn(Set<String> codes);

	Optional<Ticket> findByTicketTypeTypeAndAssetCodeAndStateNotIn(String type, String company,
			List<TicketState> asList);

	Set<Ticket> findByAssetCodeInAndTicketTypeTypeRegexAndAssignedToRegexAndGeneratedByRegexAndCreationTimeBetween(
			Set<String> assetCodes, String ticketTypeRegex, String assignedToRegex, String generatedByRegex,
			Date creationFromDate, Date creationEndDate);

	@Query("Match(a:Alert) where a.type = 'TICKET_ALERT' and "
			+ "duration.inSeconds(datetime(a.creationTime),datetime()).hours >= toInteger({1}) "
			+ "with collect(a.alertEntityCode) as alist " + "MATCH (t:`Ticket`) WHERE t.`state` = {0} "
			+ "and not t.code in alist return t.code")
	Set<String> getTicketCodesForStateAlerts(String ticketState, int ticketStateDedupeHours);

	@Query("Match (t:Ticket)-[:TYPE_OF_TICKET]->(type:TicketType) "
			+ "where t.state in {0} and type.autoHealable=true "
			+ "and (datetime(t.lastAutoHealTime) + duration({seconds:toInteger(type.autoHealInterval)}))"
			+ " < datetime() return t.code")
	Set<String> getTicketCodesForAutoHeal(Set<String> ticketStates);
}

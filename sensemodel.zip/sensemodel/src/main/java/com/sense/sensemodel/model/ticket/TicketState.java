package com.sense.sensemodel.model.ticket;

public enum TicketState {
	// Note: auto_heal till accepted
	CREATED(1), ASSIGNED(1), ASSIGNED_NOTIFIED(1), ACCEPTED(1),
	REFUSED(1), DISCARDED(1), RESOLVED(1), AUTOHEALED(1),
	CLOSED(1);

	private int dedupeInterval;

	private TicketState(int val) {
		this.dedupeInterval = val;
	}

	public int getDedupeInterval() {
		return this.dedupeInterval;
	}
}

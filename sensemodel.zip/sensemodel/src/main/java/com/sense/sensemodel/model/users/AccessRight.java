package com.sense.sensemodel.model.users;

import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.neo4j.ogm.annotation.GeneratedValue;
import org.neo4j.ogm.annotation.Id;
import org.neo4j.ogm.annotation.NodeEntity;
import org.neo4j.ogm.annotation.Property;

import com.fasterxml.jackson.annotation.JsonIgnore;

@NodeEntity
public class AccessRight {
	@Id
	@GeneratedValue
	@JsonIgnore
	private Long id;

	@Property("accessType")
	private String accessType;
	
	@Property("creationDate")
	@JsonIgnore
	private Date creationDate;
	
	@JsonIgnore
	private String company;

	public static final Set<String> standardAccessRights = new HashSet<>(
			Arrays.asList(AccessType.ASSET_READ.name(), AccessType.ORG_READ.name()));

	public AccessRight() {
	}
	
	public AccessRight(String accessType) {
		this.accessType = accessType;
		this.creationDate = new Date();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((accessType == null) ? 0 : accessType.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AccessRight other = (AccessRight) obj;
		if (accessType == null) {
			if (other.accessType != null)
				return false;
		} else if (!accessType.equals(other.accessType))
			return false;
		return true;
	}

	public String getAccessType() {
		return accessType;
	}

	public void setAccessType(String accessType) {
		this.accessType = accessType;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}
}

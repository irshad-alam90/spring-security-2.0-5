package com.sense.sensemodel.model.assets;

import java.util.HashSet;
import java.util.Set;

import org.neo4j.ogm.annotation.GeneratedValue;
import org.neo4j.ogm.annotation.Id;
import org.neo4j.ogm.annotation.NodeEntity;
import org.neo4j.ogm.annotation.Property;
import org.neo4j.ogm.annotation.Relationship;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sense.sensemodel.model.PropertyType;

@NodeEntity
public class AssetConnectionType {

	@Id
	@GeneratedValue
	@JsonIgnore
	private Long id;

	@Property("type")
	private String type;

	@Property("company")
	private String company;

	@Relationship(type = "ALLOWED_PROPERTY")
	private Set<PropertyType> allowedProperties = new HashSet<>();

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Set<PropertyType> getAllowedProperties() {
		return allowedProperties;
	}

	public void setAllowedProperties(Set<PropertyType> allowedProperties) {
		this.allowedProperties = allowedProperties;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}
}

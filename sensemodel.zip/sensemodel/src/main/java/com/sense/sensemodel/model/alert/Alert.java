package com.sense.sensemodel.model.alert;

import java.util.Date;
import java.util.UUID;

import org.neo4j.ogm.annotation.GeneratedValue;
import org.neo4j.ogm.annotation.Id;
import org.neo4j.ogm.annotation.Property;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;

public class Alert {

    @Id
    @GeneratedValue
    @JsonIgnore
    private Long id;

    @ApiModelProperty(hidden = true)
    private String code = UUID.randomUUID().toString();
    
    @Property("creationTime")
    Date creationTime;
    
    @Property("type")
    String type;

    @Property("alertEntityCode")
    String alertEntityCode;
    
    

    public Alert(String code, Date creationTime, String type, String alertEntityCode) {
        super();
        this.code = code;
        this.creationTime = creationTime;
        this.type = type;
        this.alertEntityCode = alertEntityCode;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Date getCreationTime() {
        return creationTime;
    }

    public void setCreationTime(Date creationTime) {
        this.creationTime = creationTime;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getAlertEntityCode() {
        return alertEntityCode;
    }

    public void setAlertEntityCode(String alertEntityCode) {
        this.alertEntityCode = alertEntityCode;
    }
    
    
}

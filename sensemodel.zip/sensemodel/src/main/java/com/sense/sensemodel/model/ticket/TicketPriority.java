package com.sense.sensemodel.model.ticket;

public enum TicketPriority {
	HIGH, MEDIUM, LOW
}

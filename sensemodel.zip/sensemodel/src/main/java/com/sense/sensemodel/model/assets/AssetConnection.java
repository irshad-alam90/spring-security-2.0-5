package com.sense.sensemodel.model.assets;

import java.util.HashMap;
import java.util.Map;

import org.neo4j.ogm.annotation.EndNode;
import org.neo4j.ogm.annotation.GeneratedValue;
import org.neo4j.ogm.annotation.Id;
import org.neo4j.ogm.annotation.Properties;
import org.neo4j.ogm.annotation.Property;
import org.neo4j.ogm.annotation.RelationshipEntity;
import org.neo4j.ogm.annotation.StartNode;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

@RelationshipEntity(type = "ASSET_CONNECTION")
public class AssetConnection {

	@Id
	@GeneratedValue
	@JsonIgnore
	private Long id;

	@StartNode
	@JsonIgnore
	private Asset startAsset;

	@EndNode
	@JsonIgnore
	private Asset endAsset;

	@Property("type")
	private String type;

	@Properties
	private Map<String, String> properties = new HashMap<>();

	public AssetConnection() {
	}
	
	public AssetConnection(Asset startAsset, Asset endAsset, String type, Map<String, String> properties) {
		this.startAsset = startAsset;
		this.endAsset = endAsset;
		this.type = type;
		this.properties = properties;
	}

	@JsonProperty("endNodeCode")
    public String getEndNodeCode() {
		return endAsset.getCode();
	}
	
	public Asset getStartAsset() {
		return startAsset;
	}

	public void setStartAsset(Asset startAsset) {
		this.startAsset = startAsset;
	}

	public Asset getEndAsset() {
		return endAsset;
	}

	public void setEndAsset(Asset endAsset) {
		this.endAsset = endAsset;
	}

	public Map<String, String> getProperties() {
		return properties;
	}

	public void setProperties(Map<String, String> properties) {
		this.properties = properties;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}

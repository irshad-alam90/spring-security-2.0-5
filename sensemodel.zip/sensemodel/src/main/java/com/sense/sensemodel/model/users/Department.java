package com.sense.sensemodel.model.users;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import org.neo4j.ogm.annotation.GeneratedValue;
import org.neo4j.ogm.annotation.Id;
import org.neo4j.ogm.annotation.NodeEntity;
import org.neo4j.ogm.annotation.Property;
import org.neo4j.ogm.annotation.Relationship;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sense.sensemodel.model.assets.AssetType;

import io.swagger.annotations.ApiModelProperty;

@NodeEntity
public class Department {
	public static enum KnowDepartmentType {
		ADMIN
	};

	@Id
	@GeneratedValue
	@JsonIgnore
	private Long id;

	@Property("name")
	private String name;

	@Property("companyId")
	private String companyId;

	@ApiModelProperty(hidden = true)
	@Property("code")
	private String code = UUID.randomUUID().toString();;

	@Relationship(type = "DEP_ASSET_ACCESS", direction = Relationship.OUTGOING)
	private Set<AssetType> accessibleAssetTypes = new HashSet<>();

	@Relationship(type = "ADMIN_DEP_ROLE", direction = Relationship.OUTGOING)
	private Role adminRole;
	
	// adhoc field
	private Set<Role> subRolesList;

	@Property("creationDate")
	private Date creationDate;

	private boolean activeInd;

	public Department() {
	}

	public Department(String name, String companyId, Role rootRole, Set<AssetType> accessibleAssetTypes) {
		this.name = name;
		this.companyId = companyId;
		this.adminRole = rootRole;
		this.accessibleAssetTypes = accessibleAssetTypes;
		this.creationDate = new Date();
		this.setActiveInd(true);
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<AssetType> getAccessibleAssetTypes() {
		return accessibleAssetTypes;
	}

	public void setAccessibleAssetTypes(Set<AssetType> allowedAssetTypes) {
		this.accessibleAssetTypes = allowedAssetTypes;
	}

	public Role getRootRole() {
		return adminRole;
	}

	public void setRootRole(Role rootRole) {
		this.adminRole = rootRole;
	}

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public boolean isActiveInd() {
		return activeInd;
	}

	public void setActiveInd(boolean activeInd) {
		this.activeInd = activeInd;
	}

	public Set<Role> getSubRolesList() {
		return subRolesList;
	}

	public void setSubRolesList(Set<Role> subRolesList) {
		this.subRolesList = subRolesList;
	}
}

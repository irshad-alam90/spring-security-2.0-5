package com.sense.sensemodel.model.command;

public enum SensorCommandStatus {
	CREATED, RECEIVED, FAILED 
}

package com.sense.sensemodel.repository.users;

import java.util.Optional;
import java.util.Set;

import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.stereotype.Repository;

import com.sense.sensemodel.model.users.AccessRight;

@Repository
public interface AccessRightRepository extends Neo4jRepository<AccessRight, Long> {
	Set<AccessRight> findByAccessTypeInAndCompanyIn(Set<String> accessTypes, Set<String> company);
	
	Optional<AccessRight> findByAccessType(String accessType);
	
	Set<AccessRight> findByCompanyIn(Set<String> companies);
}

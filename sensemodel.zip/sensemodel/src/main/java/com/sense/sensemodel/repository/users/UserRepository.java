package com.sense.sensemodel.repository.users;

import java.util.Optional;
import java.util.Set;

import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.stereotype.Repository;

import com.sense.sensemodel.model.users.User;

@Repository
public interface UserRepository extends Neo4jRepository<User, Long> {
    Optional<User> findByUserIdAndEnabled(String userId, boolean isEnabled);

    Set<User> findByUserIdInAndEnabled(Set<String> userId, boolean isEnabled);

    Set<User> findByNameRegexAndCompanyId(String name, String companyId);
}

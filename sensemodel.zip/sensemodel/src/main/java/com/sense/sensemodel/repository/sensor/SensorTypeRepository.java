package com.sense.sensemodel.repository.sensor;

import java.util.Optional;
import java.util.Set;

import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.stereotype.Repository;

import com.sense.sensemodel.model.sensor.SensorType;

@Repository
public interface SensorTypeRepository extends Neo4jRepository<SensorType, Long> {
	Optional<SensorType> findByTypeName(String typeName);
	
	Set<SensorType> findByCompanyCode(String companyCode);

	Optional<SensorType> findByTypeNameAndCompanyCode(String typeName, String companyCode);
}

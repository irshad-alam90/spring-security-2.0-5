package com.sense.sensemodel.model.ticket;

import java.util.Set;

import org.neo4j.ogm.annotation.GeneratedValue;
import org.neo4j.ogm.annotation.Id;
import org.neo4j.ogm.annotation.NodeEntity;
import org.neo4j.ogm.annotation.Relationship;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sense.sensemodel.model.FieldType;

@NodeEntity
public class TicketReportFormat {

	@Id
	@GeneratedValue
	@JsonIgnore
	private Long id;
	
	private String type;
	
	@Relationship(type = "TICKET_REPORT_FIELD_TYPE")
	private Set<FieldType> fieldTypes;

	public TicketReportFormat() {
	}
	
	public TicketReportFormat(String type, Set<FieldType> fieldTypes) {
		this.type = type;
		this.fieldTypes = fieldTypes;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Set<FieldType> getFieldTypes() {
		return fieldTypes;
	}

	public void setFieldTypes(Set<FieldType> fieldTypes) {
		this.fieldTypes = fieldTypes;
	}
}

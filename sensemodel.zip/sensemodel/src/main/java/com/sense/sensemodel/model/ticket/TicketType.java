package com.sense.sensemodel.model.ticket;

import java.util.Date;
import java.util.Set;

import org.neo4j.ogm.annotation.GeneratedValue;
import org.neo4j.ogm.annotation.Id;
import org.neo4j.ogm.annotation.NodeEntity;
import org.neo4j.ogm.annotation.Relationship;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sense.sensemodel.model.FieldType;

import io.swagger.annotations.ApiModelProperty;

@NodeEntity
public class TicketType {

	@Id
	@GeneratedValue
	@JsonIgnore
	private Long id;

	private String type;

	private String company;

	private String sourceType;

	private boolean autoHealable;

	// seconds
	private long autoHealInterval;

	private String assetType;

	@Relationship(type = "TICKET_FIELD_TYPE")
	private Set<FieldType> fieldTypes;

	@Relationship(type = "TICKET_REPORT_TYPE")
	private Set<TicketReportFormat> reportTypes;

	@ApiModelProperty(hidden = true)
	private Date creationTime;

	public TicketType() {
	}

	public TicketType(String type, String company, String sourceType, boolean autoHealable, long autoHealInterval,
			Set<FieldType> fieldTypes, Set<TicketReportFormat> reportTypes, String assetType) {
		super();
		this.type = type;
		this.company = company;
		this.sourceType = sourceType;
		this.autoHealable = autoHealable;
		this.fieldTypes = fieldTypes;
		this.reportTypes = reportTypes;
		this.assetType = assetType;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getSourceType() {
		return sourceType;
	}

	public void setSourceType(String sourceType) {
		this.sourceType = sourceType;
	}

	public boolean isAutoHealable() {
		return autoHealable;
	}

	public void setAutoHealable(boolean autoHealable) {
		this.autoHealable = autoHealable;
	}

	public Set<FieldType> getFieldTypes() {
		return fieldTypes;
	}

	public void setFieldTypes(Set<FieldType> fieldTypes) {
		this.fieldTypes = fieldTypes;
	}

	public Set<TicketReportFormat> getReportTypes() {
		return reportTypes;
	}

	public void setReportTypes(Set<TicketReportFormat> reportTypes) {
		this.reportTypes = reportTypes;
	}

	public Date getCreationTime() {
		return creationTime;
	}

	public void setCreationTime(Date creationTime) {
		this.creationTime = creationTime;
	}

	public String getAssetType() {
		return assetType;
	}

	public void setAssetType(String assetType) {
		this.assetType = assetType;
	}

	public long getAutoHealInterval() {
		return autoHealInterval;
	}

	public void setAutoHealInterval(long autoHealInterval) {
		this.autoHealInterval = autoHealInterval;
	}
}

package com.sense.sensemodel.model.organisation;

import java.util.HashSet;
import java.util.Set;
import java.util.stream.Stream;

import org.neo4j.ogm.annotation.GeneratedValue;
import org.neo4j.ogm.annotation.Id;
import org.neo4j.ogm.annotation.NodeEntity;
import org.neo4j.ogm.annotation.Property;
import org.neo4j.ogm.annotation.Relationship;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sense.sensemodel.model.PropertyType;

@NodeEntity
public class OrgHierarchy {
	@Id
	@GeneratedValue
	@JsonIgnore
	private Long id;

	@Property("company_entity_id")
	private String companyEntityId;

	@Property("type")
	private String type;

	@Relationship(type = "SUB_ORG_TYPE")
	@com.fasterxml.jackson.annotation.JsonBackReference
	private Set<OrgHierarchy> subOrgTypes;

	@Relationship(type = "SUB_ORG_TYPE", direction = Relationship.INCOMING)
	// @com.fasterxml.jackson.annotation.JsonBackReference
	private OrgHierarchy parentOrgType;

	@Relationship(type = "ALLOWED_PROPERTY")
	private Set<PropertyType> allowedProperties = new HashSet<>();

	public Stream<OrgHierarchy> flattened() {
		return Stream.concat(Stream.of(this),
				(subOrgTypes != null) ? subOrgTypes.stream().flatMap(OrgHierarchy::flattened) : Stream.empty());
	}

	public OrgHierarchy(String companyEntityId, String type, OrgHierarchy parentOrgType) {
		this.companyEntityId = companyEntityId;
		this.type = type;
		this.setParentOrgType(parentOrgType);
	}

	public OrgHierarchy() {
	}

	public String getCompanyEntityId() {
		return companyEntityId;
	}

	public void setCompanyEntityId(String companyEntityId) {
		this.companyEntityId = companyEntityId;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Set<OrgHierarchy> getSubOrgTypes() {
		return subOrgTypes;
	}

	public void setSubOrgTypes(Set<OrgHierarchy> subOrgTypes) {
		this.subOrgTypes = subOrgTypes;
	}

	public OrgHierarchy getParentOrgType() {
		return parentOrgType;
	}

	public void setParentOrgType(OrgHierarchy parentOrgType) {
		this.parentOrgType = parentOrgType;
	}

	public Set<PropertyType> getAllowedProperties() {
		return allowedProperties;
	}

	public void setAllowedProperties(Set<PropertyType> allowedProperties) {
		this.allowedProperties = allowedProperties;
	}
}

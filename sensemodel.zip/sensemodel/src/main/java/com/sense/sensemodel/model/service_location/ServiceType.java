package com.sense.sensemodel.model.service_location;

public enum ServiceType {
	WEB, APP, SENSOR_DATA
}

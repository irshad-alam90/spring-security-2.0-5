package com.sense.sensemodel.model.users;

public enum AccessType {
	CREATE_USER, ASSET_READ, ASSET_ADMIN, ORG_READ, ORG_ADMIN, ADMIN_LOGIN, SENSE_ADMIN;
}

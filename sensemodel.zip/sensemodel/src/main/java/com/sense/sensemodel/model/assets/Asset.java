package com.sense.sensemodel.model.assets;

import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.neo4j.ogm.annotation.GeneratedValue;
import org.neo4j.ogm.annotation.Id;
import org.neo4j.ogm.annotation.NodeEntity;
import org.neo4j.ogm.annotation.Properties;
import org.neo4j.ogm.annotation.Property;
import org.neo4j.ogm.annotation.Relationship;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sense.sensemodel.model.organisation.Organisation;

import io.swagger.annotations.ApiModelProperty;

@NodeEntity
public class Asset {
	@Id
	@GeneratedValue
	@JsonIgnore
	private Long id;

	@Property("name")
	private String name;

	@Property("type")
	private String type;

	@ApiModelProperty(hidden = true)
	@Property("code")
	private String code = UUID.randomUUID().toString();

	@ApiModelProperty(hidden = true)
	@Property("activeInd")
	private boolean activeInd;

	@ApiModelProperty(hidden = true)
	@Relationship(type = "ASSET_CONNECTION")
	private Set<AssetConnection> connnectionOut = new HashSet<>();

	@JsonIgnore
	@Relationship(type = "ASSET_CONNECTION", direction = Relationship.INCOMING)
	private Set<AssetConnection> connnectionIn  = new HashSet<>();

	@JsonIgnore
	@Relationship(type = "ORG_ASSET", direction = Relationship.INCOMING)
	private Organisation parentOrg;

	@Properties
	private Map<String, String> properties = new HashMap<>();
	
	@Property("creationTime")
	private Date creationTime;
	
	@Property("deactivationTime")
	private Date deactivationTime;

	public Asset() {
	}

	public Long getId() {
		return id;
	}

	public Asset(String name, String type, String code, Organisation parentOrg, Map<String, String> properties,
			boolean activeInd) {
		this.name = name;
		this.type = type;
		this.code = code;
		this.activeInd = activeInd;
		this.parentOrg = parentOrg;
		this.properties = properties;
		this.creationTime = new Date();
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public Set<AssetConnection> getConnnectionOut() {
		return connnectionOut;
	}

	public void setConnnectionOut(Set<AssetConnection> connnectionOut) {
		this.connnectionOut = connnectionOut;
	}

	public Map<String, String> getProperties() {
		return properties;
	}

	public void setProperties(Map<String, String> properties) {
		this.properties = properties;
	}

	public Organisation getParentOrg() {
		return parentOrg;
	}

	public void setParentOrg(Organisation parentOrg) {
		this.parentOrg = parentOrg;
	}

	public boolean isActiveInd() {
		return activeInd;
	}

	public void setActiveInd(boolean activeInd) {
		this.activeInd = activeInd;
	}

	public Set<AssetConnection> getConnnectionIn() {
		return connnectionIn;
	}

	public void setConnnectionIn(Set<AssetConnection> connnectionIn) {
		this.connnectionIn = connnectionIn;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Date getCreationTime() {
		return creationTime;
	}

	public void setCreationTime(Date creationTime) {
		this.creationTime = creationTime;
	}

	public Date getDeactivationTime() {
		return deactivationTime;
	}

	public void setDeactivationTime(Date deactivationTime) {
		this.deactivationTime = deactivationTime;
	}
}

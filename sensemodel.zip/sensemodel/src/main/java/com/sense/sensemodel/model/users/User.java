package com.sense.sensemodel.model.users;

import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.neo4j.ogm.annotation.GeneratedValue;
import org.neo4j.ogm.annotation.Id;
import org.neo4j.ogm.annotation.Properties;
import org.neo4j.ogm.annotation.Relationship;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

public class User {

	@Id
	@GeneratedValue
	@JsonIgnore
	private Long id;

	private String userId;

	private String name;

	private String email;

	private String phone;

	@JsonIgnore
	private String pswrd;

	private String designation;

	private String companyId;

	// maps users department code to role code
	@Properties
	private Map<String, String> departmentRoles = new HashMap<>();

	private Set<String> orgParts = new HashSet<>();

	@Relationship(type = "USER_ACCESS_RIGHT", direction = Relationship.OUTGOING)
	private Set<AccessRight> accessRights = new HashSet<>();

	@ApiModelProperty(hidden = true)
	private Date creationDate;

	@ApiModelProperty(hidden = true)
	private Date lastLoginTime;

	@JsonIgnore
	private boolean enabled;

	@JsonIgnore
	private Date lastPasswordResetDate;

	@JsonIgnore
	private String createdBy;

	public User() {
	}

	public User(String userId, String name, String email, String pswrd, String designation,
			Map<String, String> departmentRole, Set<AccessRight> accessRights, Set<String> orgParts, String companyId) {
		this.userId = userId;
		this.name = name;
		this.email = email;
		this.pswrd = pswrd;
		this.designation = designation;
		this.departmentRoles = departmentRole;
		this.accessRights = accessRights;
		this.orgParts = orgParts;
		this.enabled = true;
		this.creationDate = new Date();
		this.companyId = companyId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public Map<String, String> getDepartmentRoles() {
		return departmentRoles;
	}

	public void setDepartmentRoles(Map<String, String> departmentRoles) {
		this.departmentRoles = departmentRoles;
	}

	public Set<AccessRight> getAccessRights() {
		return accessRights;
	}

	public void setAccessRights(Set<AccessRight> accessRights) {
		this.accessRights = accessRights;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public Set<String> getOrgParts() {
		return orgParts;
	}

	public void setOrgParts(Set<String> orgParts) {
		this.orgParts = orgParts;
	}

	@JsonIgnore
	public String getPswrd() {
		return pswrd;
	}

	@JsonProperty
	public void setPswrd(String pswrd) {
		this.pswrd = pswrd;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean isEnabled) {
		this.enabled = isEnabled;
	}

	public Date getLastPasswordResetDate() {
		return lastPasswordResetDate;
	}

	public void setLastPasswordResetDate(Date lastPasswordResetDate) {
		this.lastPasswordResetDate = lastPasswordResetDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public Date getLastLoginTime() {
		return lastLoginTime;
	}

	public void setLastLoginTime(Date lastLoginTime) {
		this.lastLoginTime = lastLoginTime;
	}

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}
}

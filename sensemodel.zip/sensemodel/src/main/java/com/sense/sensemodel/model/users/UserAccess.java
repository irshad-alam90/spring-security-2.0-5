package com.sense.sensemodel.model.users;

import java.util.Set;

public class UserAccess {

	private String userId;

	private Set<String> orgParts;
	
	private Set<String> assetsCodes;
	
	public UserAccess() {
	}

	public UserAccess(String userId, Set<String> orgParts, Set<String> assetsCodes) {
		this.userId = userId;
		this.orgParts = orgParts;
		this.assetsCodes = assetsCodes;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Set<String> getOrgParts() {
		return orgParts;
	}

	public void setOrgParts(Set<String> orgParts) {
		this.orgParts = orgParts;
	}

	public Set<String> getAssetsCodes() {
		return assetsCodes;
	}

	public void setAssetsCodes(Set<String> assetsCodes) {
		this.assetsCodes = assetsCodes;
	}
}

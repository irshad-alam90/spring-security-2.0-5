package com.sense.sensemodel.model.sensor;

import java.util.Set;

public class SensorFieldsInput {

	private Set<SensorFields> inputFields;

	private Set<SensorFields> commandFields;

	public Set<SensorFields> getInputFields() {
		return inputFields;
	}

	public void setInputFields(Set<SensorFields> inputFields) {
		this.inputFields = inputFields;
	}

	public Set<SensorFields> getCommandFields() {
		return commandFields;
	}

	public void setCommandFields(Set<SensorFields> commandFields) {
		this.commandFields = commandFields;
	}
}

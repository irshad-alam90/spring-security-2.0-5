package com.sense.sensemodel.model.sensor;

public enum SensorDataType {
	TEXT, NONC, CONTINOUS
}

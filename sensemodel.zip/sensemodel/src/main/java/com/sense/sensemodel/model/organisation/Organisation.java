package com.sense.sensemodel.model.organisation;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.neo4j.ogm.annotation.GeneratedValue;
import org.neo4j.ogm.annotation.Id;
import org.neo4j.ogm.annotation.NodeEntity;
import org.neo4j.ogm.annotation.Properties;
import org.neo4j.ogm.annotation.Property;
import org.neo4j.ogm.annotation.Relationship;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;

@NodeEntity
public class Organisation implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue
    @JsonIgnore
    private Long id;

    @Property("name")
    private String name;

    @Property("type")
    private String type;

    @ApiModelProperty(hidden = true)
    @Property("entityId")
    private String entityId = UUID.randomUUID().toString();

    @ApiModelProperty(hidden = true)
    @Relationship(type = "SUB_ORG")
    @com.fasterxml.jackson.annotation.JsonBackReference
    private Set<Organisation> subOrgs = new HashSet<>();

    @ApiModelProperty(hidden = true)
    @Relationship(type = "SUB_ORG", direction = Relationship.INCOMING)
    private Organisation parent;

    @ApiModelProperty(hidden = true)
    @Property("activeInd")
    private boolean activeInd;

    @ApiModelProperty(hidden = true)
    private Date creationDate;

    @Properties
    private Map<String, String> properties = new HashMap<>();

    public Organisation() {
    }

    public Organisation(String name, String type, String entityId, Map<String, String> properties, boolean activeInd) {
        this.name = name;
        this.type = type;
        this.entityId = entityId;
        this.activeInd = activeInd;
        this.properties = properties;
        this.creationDate = new Date();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @JsonIgnore
    public Set<Organisation> getActiveChildren() {
        return subOrgs.stream().filter(e -> e.isActiveInd()).collect(Collectors.toSet());
    }

    public boolean isActiveInd() {
        return activeInd;
    }

    public void setActiveInd(boolean activeInd) {
        this.activeInd = activeInd;
    }

    public String getEntityId() {
        return entityId;
    }

    public void setEntityId(String entityId) {
        this.entityId = entityId;
    }

    public Set<Organisation> getSubOrgs() {
        return subOrgs;
    }

    public void setSubOrgs(Set<Organisation> subOrgs) {
        this.subOrgs = subOrgs;
    }

    public Map<String, String> getProperties() {
        return properties;
    }

    public void setProperties(Map<String, String> properties) {
        this.properties = properties;
    }

    public Organisation getParent() {
        return parent;
    }

    public void setParent(Organisation parent) {
        this.parent = parent;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }
}

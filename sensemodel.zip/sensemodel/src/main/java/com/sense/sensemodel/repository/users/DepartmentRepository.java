package com.sense.sensemodel.repository.users;

import java.util.Optional;
import java.util.Set;

import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.stereotype.Repository;

import com.sense.sensemodel.model.users.Department;

@Repository
public interface DepartmentRepository extends Neo4jRepository<Department, Long> {
	Set<Department> findByCompanyIdAndActiveInd(String company, boolean activeInd);
	
	Set<Department> findByCodeInAndActiveInd(Set<String> departmentCodes, boolean activeInd);
	
	Optional<Department> findByCodeAndActiveInd(String departmentCode, boolean activeInd);
}

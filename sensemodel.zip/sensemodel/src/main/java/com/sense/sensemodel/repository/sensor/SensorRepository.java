package com.sense.sensemodel.repository.sensor;

import java.util.Optional;
import java.util.Set;

import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.stereotype.Repository;

import com.sense.sensemodel.model.sensor.Sensor;

@Repository
public interface SensorRepository extends Neo4jRepository<Sensor, Long> {
	Optional<Sensor> findByCode(String code);

	Set<Sensor> findByCodeIn(Set<String> codes);

	Set<Sensor> findByAssetCodeAndActiveInd(String assetCode, boolean activeInd);

	Set<Sensor> findByHubCodeAndActiveInd(String hubCode, boolean activeInd);

	Optional<Sensor> findByUuidAndActiveInd(String macAddress, boolean activeInd);
}

package com.sense.sensemodel.model;

import org.neo4j.ogm.annotation.GeneratedValue;
import org.neo4j.ogm.annotation.Id;
import org.neo4j.ogm.annotation.NodeEntity;
import org.neo4j.ogm.annotation.Property;

import com.fasterxml.jackson.annotation.JsonIgnore;

@NodeEntity
public class PropertyType {
	@Id
	@GeneratedValue
	@JsonIgnore
	private Long id;

	@Property("name")
	private String name;

	@Property("nullable")
	private boolean nullable;

	@Property("upgrade_on_update")
	private boolean upgradeOnUpdate;
	
	public PropertyType() {
		
	}
	
	public PropertyType(String name, Boolean nullable, Boolean upgradeOnUpdate) {
		this.name = name;
		this.nullable = nullable;
		this.upgradeOnUpdate = upgradeOnUpdate;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PropertyType other = (PropertyType) obj;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}

	public Boolean getNullable() {
		return nullable;
	}

	public void setNullable(Boolean nullable) {
		this.nullable = nullable;
	}

	public Boolean getUpgradeOnUpdate() {
		return upgradeOnUpdate;
	}

	public void setUpgradeOnUpdate(Boolean upgradeOnUpdate) {
		this.upgradeOnUpdate = upgradeOnUpdate;
	}

}

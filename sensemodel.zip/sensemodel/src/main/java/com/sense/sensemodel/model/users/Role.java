package com.sense.sensemodel.model.users;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Stream;

import org.neo4j.ogm.annotation.GeneratedValue;
import org.neo4j.ogm.annotation.Id;
import org.neo4j.ogm.annotation.NodeEntity;
import org.neo4j.ogm.annotation.Property;
import org.neo4j.ogm.annotation.Relationship;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;

@NodeEntity
public class Role {
    @Id
    @GeneratedValue
    @JsonIgnore
    private Long id;

    @Property("name")
    private String name;

    @ApiModelProperty(hidden = true)
    @Property("code")
    private String code = UUID.randomUUID().toString();;

    @ApiModelProperty(hidden = true)
    @JsonIgnore
    @Relationship(type = "SUB_ROLE", direction = Relationship.INCOMING)
    private Role parent;

    @ApiModelProperty(hidden = true)
    @Relationship(type = "SUB_ROLE", direction = Relationship.OUTGOING)
    private Set<Role> children;

    @Relationship(type = "ROLE_ACCESS_RIGHT", direction = Relationship.OUTGOING)
    private Set<AccessRight> allowedAccessRights = new HashSet<>();

    @ApiModelProperty(hidden = true)
    @Property("creationDate")
    private Date creationDate;

    @JsonIgnore
    private boolean activeInd;

    public Role() {
    }

    public enum KnownRoleType {
        Admin_Role
    }

    public Role(String name, Role parent, Set<AccessRight> allowedAccessRights) {
        this.name = name;
        this.parent = parent;
        this.allowedAccessRights = allowedAccessRights;
        this.creationDate = new Date();
        this.setActiveInd(true);
    }

    public Stream<Role> flattened() {
        return Stream.concat(Stream.of(this),
                (children != null) ? children.stream().flatMap(Role::flattened) : Stream.empty());
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Role getParent() {
        return parent;
    }

    public void setParent(Role parent) {
        this.parent = parent;
    }

    public Set<AccessRight> getAllowedAccessRights() {
        return allowedAccessRights;
    }

    public void setAllowedAccessRights(Set<AccessRight> allowedAccessRights) {
        this.allowedAccessRights = allowedAccessRights;
    }

    public Set<Role> getChildren() {
        return children;
    }

    public void setChildren(Set<Role> children) {
        this.children = children;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public boolean isActiveInd() {
        return activeInd;
    }

    public void setActiveInd(boolean activeInd) {
        this.activeInd = activeInd;
    }
}

package com.sense.sensemodel.model;

public class BulkUploadException extends RuntimeException {

	private static final long serialVersionUID = -6352847323779028957L;

	private int errorRowNumber;

	public BulkUploadException(int errorRowNumber, Throwable e) {
		super("Error at row number: " + errorRowNumber, e);
		this.setErrorRowNumber(errorRowNumber);
	}

	public int getErrorRowNumber() {
		return errorRowNumber;
	}

	public void setErrorRowNumber(int errorRowNumber) {
		this.errorRowNumber = errorRowNumber;
	}
}

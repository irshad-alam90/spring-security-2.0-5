package com.sense.sensemodel.repository.assets;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.data.neo4j.annotation.Query;
import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.stereotype.Repository;

import com.sense.sensemodel.model.assets.Asset;

@Repository
public interface AssetRepository extends Neo4jRepository<Asset, Long> {

	Optional<Asset> findByCodeAndActiveInd(String code, boolean activeInd);

	@Query("MATCH (n:`Asset`) WHERE n.`activeInd` = true MATCH (m0:`Organisation`) WHERE m0.entityId = {0} "
			+ "MATCH (n)<-[*]-(m0) WITH DISTINCT n " + "RETURN n.code")
	public List<String> getAllDescendantAssetsCodesForOrg(String entityId);

	@Query("MATCH (n:`Asset`) WHERE n.`activeInd` = true MATCH (m0:`Organisation`) WHERE ID(m0) = {0} "
			+ "MATCH (n)<-[:ORG_ASSET]-(m0) WITH DISTINCT n RETURN n.code")
	public List<String> getAllChildrenAssetsCodesForOrg(Long id);

	@Query("MATCH (n:`Asset`) WHERE n.`activeInd` = true AND n.`type` in {1} "
			+ "MATCH (m0:`Organisation`) WHERE m0.entityId in {0} "
			+ "MATCH (n)<-[:ORG_ASSET]-(m0) WITH DISTINCT n RETURN n.code")
	public Set<String> getAllChildrenAssetsCodesForOrgEntityIdInAndAssetTypeIn(Set<String> orgIds,
			Set<String> assetTypes);
	
	@Query("MATCH (n:`Asset`) WHERE n.`activeInd` = true AND n.`type` in {1} "
			+ "MATCH (m0:`Organisation`) WHERE m0.entityId in {0} "
			+ "MATCH (n)<-[:ORG_ASSET]-(m0) WITH DISTINCT n RETURN n")
	public Set<Asset> getAllChildrenAssetsForOrgEntityIdInAndAssetTypeIn(Set<String> orgIds,
			Set<String> assetTypes);
	
	@Query("MATCH (n:`Asset`) WHERE n.`activeInd` = true MATCH (m0:`Organisation`) WHERE m0.entityId = {0} "
            + "MATCH (n)<-[*]-(m0) WITH DISTINCT n SET n.activeInd = false")
    public void deleteAllDescendantAssets(String orgId);

	public List<Asset> findByCodeInAndActiveInd(List<String> assetCode, boolean activeInd);

	@Query("MATCH (n:`Asset`) WHERE n.`activeInd` = true AND n.code = {0} AND n.type in {2} "
			+ "MATCH (m0:`Organisation`) WHERE m0.activeInd = true AND m0.entityId in {1} MATCH (n)<-[*]-(m0) RETURN n")
	public Optional<Asset> isAssetAccessible(String assetCode, Set<String> userOrgParts, Set<String> userAssetTypes);
}

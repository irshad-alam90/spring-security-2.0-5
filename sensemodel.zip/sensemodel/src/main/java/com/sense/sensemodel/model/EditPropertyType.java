package com.sense.sensemodel.model;

public class EditPropertyType {

	public static enum Mode {
		DELETE, ADD, EDIT;
	}

	private String propName;

	private PropertyType newPropertyType;

	private Mode editMode;

	public String getPropName() {
		return propName;
	}

	public void setPropName(String propName) {
		this.propName = propName;
	}

	public PropertyType getNewPropertyType() {
		return newPropertyType;
	}

	public void setNewPropertyType(PropertyType newPropertyType) {
		this.newPropertyType = newPropertyType;
	}

	public Mode getEditMode() {
		return editMode;
	}

	public void setEditMode(Mode editMode) {
		this.editMode = editMode;
	}
}

package com.sense.sensemodel.repository.organisation;

import java.util.List;
import java.util.Optional;

import org.springframework.data.neo4j.annotation.Depth;
import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.stereotype.Repository;

import com.sense.sensemodel.model.organisation.OrgHierarchy;


@Repository
public interface OrgHierarchyRepository extends Neo4jRepository<OrgHierarchy, Long>{
    
    public List<OrgHierarchy> findByCompanyEntityId(String companyEntityId, @Depth int depth);
    
    public Optional<OrgHierarchy> findByCompanyEntityIdAndType(String companyEntityId, String type, @Depth int depth);
    
}

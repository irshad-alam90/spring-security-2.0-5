package com.sense.sensemodel.repository.assets;

import java.util.Optional;
import java.util.Set;

import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.stereotype.Repository;

import com.sense.sensemodel.model.assets.AssetType;

@Repository
public interface AssetTypeRepository extends Neo4jRepository<AssetType, Long>{
	Set<AssetType> findByCompany(String company);
	
	Optional<AssetType> findByCompanyAndType(String company, String type);
	
	Set<AssetType> findByCompanyAndTypeIn(String company, Set<String> types);

}

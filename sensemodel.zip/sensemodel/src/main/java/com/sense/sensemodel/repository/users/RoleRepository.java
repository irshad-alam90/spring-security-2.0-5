package com.sense.sensemodel.repository.users;

import java.util.Optional;
import java.util.Set;

import org.springframework.data.neo4j.annotation.Query;
import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.stereotype.Repository;

import com.sense.sensemodel.model.users.Department;
import com.sense.sensemodel.model.users.Role;

@Repository
public interface RoleRepository extends Neo4jRepository<Role, Long> {

	@Query("Match(r:Role) where r.code = {0} and r.activeInd = true "
			+ "match (r)-[:SUB_ROLE*]->(s:Role) where s.activeInd = true return r,s")
	Set<Role> getRoleAndSubRoles(String rootRole);

	Optional<Role> findByCodeAndActiveInd(String code, boolean activeInd);

	Set<Role> findByCodeInAndActiveInd(Set<String> roleCodes, boolean activeInd);

	@Query("Match(d:Department)-[*]->(r:Role) where d.code = {0} and r.activeInd = true "
			+ "return r ,[(r)-[r_ar:ROLE_ACCESS_RIGHT]->(ar:AccessRight) | [ r_ar, ar ]]")
	Set<Role> findRolesByParentDepartment(String departmentCode);

	@Query("Match(r:Role) where r.code = {0} Match(d:Department)-[*]->(r) return d")
	Optional<Department> findParentDepartment(String roleCode);
}

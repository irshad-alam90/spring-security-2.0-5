package com.sense.sensemodel.model.ticket;

import java.util.Date;
import java.util.Map;

import org.neo4j.ogm.annotation.GeneratedValue;
import org.neo4j.ogm.annotation.Id;
import org.neo4j.ogm.annotation.Properties;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;

public class TicketReport {
	
	@Id
	@GeneratedValue
	@JsonIgnore
	private Long id;

	private String type;
	
	@Properties
	private Map<String, String> fields;
	
	@ApiModelProperty(hidden = true)
	private String createdBy;
	
	@ApiModelProperty(hidden = true)
	private Date creationTime; 
	
	public TicketReport() {		
	}

	public TicketReport(String type, Map<String, String> fields, String createdBy) {
		super();
		this.type = type;
		this.fields = fields;
		this.createdBy = createdBy;
		this.setCreationTime(new Date());
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Map<String, String> getFields() {
		return fields;
	}

	public void setFields(Map<String, String> fields) {
		this.fields = fields;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreationTime() {
		return creationTime;
	}

	public void setCreationTime(Date creationTime) {
		this.creationTime = creationTime;
	}
}

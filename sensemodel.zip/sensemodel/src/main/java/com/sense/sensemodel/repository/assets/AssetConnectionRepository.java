package com.sense.sensemodel.repository.assets;

import org.springframework.data.neo4j.repository.Neo4jRepository;

import com.sense.sensemodel.model.assets.AssetConnection;

public interface AssetConnectionRepository extends Neo4jRepository<AssetConnection, Long>{

}

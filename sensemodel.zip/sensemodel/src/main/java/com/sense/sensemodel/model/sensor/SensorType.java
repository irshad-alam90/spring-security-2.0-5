package com.sense.sensemodel.model.sensor;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.neo4j.ogm.annotation.GeneratedValue;
import org.neo4j.ogm.annotation.Id;
import org.neo4j.ogm.annotation.NodeEntity;
import org.neo4j.ogm.annotation.Properties;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;

@NodeEntity
public class SensorType {
	@Id
	@GeneratedValue
	@JsonIgnore
	private Long id;

	// type name to contain firmware name as well
	private String typeName;

	@ApiModelProperty(hidden = true)
	private String code = UUID.randomUUID().toString();

	private String companyCode;

	@Properties
	private Map<String, Map<String, String>> sensorInputFields = new HashMap<>();

	@Properties
	private Map<String, Map<String, String>> commandFields = new HashMap<>();

	public SensorType() {
	}

	public SensorType(String typeName, String companyCode, Set<SensorFields> inputFields,
			Set<SensorFields> commandFields) {
		this.typeName = typeName;
		this.companyCode = companyCode;
		for (SensorFields f : inputFields) {
			Map<String, String> fieldNameToDataType = new HashMap<>();
			fieldNameToDataType.put(f.getFieldName(), f.getDataType().name());
			this.sensorInputFields.put(f.getIndex(), fieldNameToDataType);
		}
		for (SensorFields f : commandFields) {
			Map<String, String> fieldNameToDataType = new HashMap<>();
			fieldNameToDataType.put(f.getFieldName(), f.getDataType().name());
			this.commandFields.put(f.getIndex(), fieldNameToDataType);
		}
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	public Map<String, Map<String, String>> getSensorTypeFields() {
		return sensorInputFields;
	}

	public void setSensorTypeFields(Map<String, Map<String, String>> sensorTypeFields) {
		this.sensorInputFields = sensorTypeFields;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
}

package com.sense.sensemodel.repository.alert;

import org.springframework.data.neo4j.repository.Neo4jRepository;

import com.sense.sensemodel.model.alert.Alert;

public interface AlertRepository extends Neo4jRepository<Alert, Long>{

}

package com.sense.organisation.controller;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.sense.organisation.service.OrganisationService;
import com.sense.sensemodel.model.EditPropertyType;
import com.sense.sensemodel.model.organisation.Organisation;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;

@RestController
@RequestMapping("/org")
public class OrganisationController {

    @Autowired
    private OrganisationService organisationService;

    private Logger logger = LoggerFactory.getLogger(OrganisationController.class);

    /*
     * Service to get children of an org part.
     */
    @RequestMapping(value = "/children/{entityId}", method = RequestMethod.GET)
    @ResponseBody
    ResponseEntity<?> getChildrenForEntity(@PathVariable("entityId") String entityId) {
        try {
            return new ResponseEntity<>(organisationService.getChildrenForEntity(entityId), HttpStatus.OK);
        } catch (Exception e) {
            logger.error("error getting children for entityId" + entityId, e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @RequestMapping(value = "/accessibleChildren", method = RequestMethod.GET)
    @ResponseBody
    ResponseEntity<?> accessibleChildren(@RequestParam("entityId") String entityId, Authentication authentication) {
        try {
            Set<String> userOrgParts = authentication.getAuthorities().stream()
                    .filter(a -> a.getAuthority().startsWith("ORGPART_"))
                    .map(a -> a.getAuthority().replace("ORGPART_", "")).collect(Collectors.toSet());
            return new ResponseEntity<>(organisationService.getAccessibleChildren(entityId, userOrgParts),
                    HttpStatus.OK);
        } catch (Exception e) {
            logger.error("error getting children for entityId" + entityId, e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @RequestMapping(value = "/accessibleSiblings", method = RequestMethod.GET)
    @ResponseBody
    ResponseEntity<?> accessibleSiblings(@RequestParam("entityId") String entityId, Authentication authentication) {
        try {
            Set<String> userOrgParts = authentication.getAuthorities().stream()
                    .filter(a -> a.getAuthority().startsWith("ORGPART_"))
                    .map(a -> a.getAuthority().replace("ORGPART_", "")).collect(Collectors.toSet());
            return new ResponseEntity<>(organisationService.getAccessibleSiblings(entityId, userOrgParts),
                    HttpStatus.OK);
        } catch (Exception e) {
            logger.error("error getting siblings for entityId" + entityId, e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /*
     * Service to get a list of all hierarchy types for company
     */
    @RequestMapping(value = "/getAllSubTypes/{companyEntityId}", method = RequestMethod.GET)
    @ResponseBody
    ResponseEntity<?> getOrgSubTypesForCompany(@PathVariable("companyEntityId") String companyEntityId) {
        try {
            return new ResponseEntity<>(organisationService.getOrgSubTypesForCompany(companyEntityId), HttpStatus.OK);
        } catch (Exception e) {
            logger.error("error getting types for company: " + companyEntityId, e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /*
     * Service to get all active org parts of a particular type
     */
    @RequestMapping(value = "/getOrgPartsOfType/{companyEntityId}/{type}", method = RequestMethod.GET)
    @ResponseBody
    ResponseEntity<?> getOrgPartsForCompany(@PathVariable("companyEntityId") String companyEntityId,
            @PathVariable("type") String type) {
        try {
            return new ResponseEntity<>(organisationService.getOrgPartsForCompany(companyEntityId, type),
                    HttpStatus.OK);
        } catch (Exception e) {
            logger.error("error getting parts for company: " + companyEntityId, e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /*
     * Service to add a child org part to an existing org part
     */
    @RequestMapping(value = "/createCompany", method = RequestMethod.PUT)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "Authorization token", dataType = "string", paramType = "header") })
    ResponseEntity<String> createCompany(@RequestParam(name = "companyName") String companyName,
            @RequestParam(name = "companyCode") String companyCode,
            @RequestParam(name = "companyAdminEmail") String companyAdminEmail,
            @RequestHeader("Authorization") String authHeader) {
        try {
            organisationService.createCompany(companyCode, companyName, companyAdminEmail, authHeader);
            return new ResponseEntity<>("created", HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error creating company: " + companyName, e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /*
     * Service to add a child org part to an existing org part
     */
    @RequestMapping(value = "/add", method = RequestMethod.PUT)
    ResponseEntity<String> add(@RequestParam(required = false, name = "parent") String parentId,
            @RequestParam(required = false, name = "companyEntityId") String companyEntityId,
            @RequestBody Organisation organisation) {
        try {
            organisationService.addOrgToParent(organisation, parentId, companyEntityId);
            return new ResponseEntity<>("created", HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error creating org", e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /*
     * Service to delete an org part with all its descendants and descendant assets
     */
    @RequestMapping(value = "/delete/{entityId}", method = RequestMethod.DELETE)
    ResponseEntity<String> delete(@PathVariable("entityId") String entityId) {
        try {
            organisationService.deleteOrg(entityId);
            return new ResponseEntity<>("deleted", HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error deleting org", e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /*
     * Service to reassign an org part and all its children to another parent
     */
    @RequestMapping(value = "/reassign", method = RequestMethod.POST)
    ResponseEntity<String> reassign(@RequestParam("newParent") String newParentId,
            @RequestParam("entity") String entityId, @RequestHeader("Authorization") String authHeader) {
        try {
            organisationService.reassignEntity(entityId, newParentId, authHeader);
            return new ResponseEntity<>("reassigned", HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error reassigning org", e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @RequestMapping(value = "/modifyOrgPart", method = RequestMethod.POST)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "Authorization token", dataType = "string", paramType = "header") })
    ResponseEntity<String> modifyOrgPart(@RequestParam("company") String company,
            @RequestParam("entityId") String entityId, @RequestBody Map<String, String> editProperties) {
        try {
            organisationService.checkParamsAndEditOrgPart(company, entityId, editProperties);
            return new ResponseEntity<>("modified", HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error modifying org", e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @RequestMapping(value = "/modifyOrgType", method = RequestMethod.POST)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "Authorization", value = "Authorization token", dataType = "string", paramType = "header") })
    ResponseEntity<String> modifyOrgType(@RequestParam("company") String company,
            @RequestParam("orgTypeName") String orgTypeName, @RequestBody List<EditPropertyType> editProperties) {
        try {
            organisationService.editOrgType(company, orgTypeName, editProperties);
            return new ResponseEntity<>("modified", HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error modifying org", e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
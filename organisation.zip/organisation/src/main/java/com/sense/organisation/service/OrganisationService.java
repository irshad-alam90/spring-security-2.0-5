package com.sense.organisation.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

import org.I0Itec.zkclient.ZkClient;
import org.I0Itec.zkclient.ZkConnection;
import org.neo4j.ogm.session.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.sense.sensemodel.model.EditPropertyType;
import com.sense.sensemodel.model.PropertyType;
import com.sense.sensemodel.model.assets.Asset;
import com.sense.sensemodel.model.assets.AssetConnection;
import com.sense.sensemodel.model.organisation.OrgHierarchy;
import com.sense.sensemodel.model.organisation.Organisation;
import com.sense.sensemodel.model.users.Department;
import com.sense.sensemodel.model.users.Role;
import com.sense.sensemodel.repository.assets.AssetConnectionRepository;
import com.sense.sensemodel.repository.assets.AssetRepository;
import com.sense.sensemodel.repository.organisation.OrgHierarchyRepository;
import com.sense.sensemodel.repository.organisation.OrganisationRepository;
import com.sense.sensemodel.repository.users.DepartmentRepository;
import com.sense.sensemodel.repository.users.RoleRepository;
import com.sense.sensemodel.repository.users.UserRepository;

import kafka.admin.AdminUtils;
import kafka.admin.RackAwareMode;
import kafka.utils.ZKStringSerializer$;
import kafka.utils.ZkUtils;

@Service
public class OrganisationService {
    @Autowired
    private OrganisationRepository organisationRepository;

    @Autowired
    private OrgHierarchyRepository orgHierarchyRepository;

    @Autowired
    private AssetRepository assetRepository;

    @Autowired
    private AssetConnectionRepository assetConnectionRepository;

    @Autowired
    private DepartmentRepository departmentRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository rolesRepository;

    @Autowired
    private Session dbSession;

    @Value("${asetServiceUrl}")
    private String asetServiceUrl;

    @Value("${userServiceUrl}")
    private String userServiceUrl;

    @Value("${kafkaZookeeperHosts}")
    private String kafkaZookeeperHosts;

    private Logger logger = LoggerFactory.getLogger(OrganisationService.class);

    public Set<Organisation> getChildrenForEntity(String entityId) {
        Organisation parent = organisationRepository.findByEntityIdAndActiveInd(entityId, true)
                .orElseThrow(() -> new RuntimeException("no active entity found with entityId: " + entityId));
        return parent.getActiveChildren();
    }

    public Set<Organisation> getAccessibleChildren(String entityId, Set<String> userOrgParts) {
        return organisationRepository.getAccessibleChildren(entityId, userOrgParts);
    }

    // Transaction managed manually because of company requirement in user-service
    public void createCompany(String companyCode, String companyName, String companyAdminEmail, String authHeader) {
        if (organisationRepository.findByEntityIdAndActiveInd(companyCode, true).isPresent()) {
            throw new RuntimeException("company already exists: " + companyCode);
        }
        Organisation company = new Organisation(companyName, "company", companyCode, null, true);
        organisationRepository.save(company);

        try {
            createAdminDepartmentAndRole(authHeader, companyCode, companyAdminEmail);
            createKafkaTopic(companyCode);
        } catch (Exception e) {
            departmentRepository.findByCodeAndActiveInd(Department.KnowDepartmentType.ADMIN.name(), true)
                    .ifPresent(d -> {
                        departmentRepository.delete(d);
                    });
            rolesRepository.findByCodeAndActiveInd(Role.KnownRoleType.Admin_Role.name(), true).ifPresent(r -> {
                rolesRepository.delete(r);
            });
            userRepository.findByUserIdAndEnabled(company + "_admin", true).ifPresent(u -> {
                userRepository.delete(u);
            });
            organisationRepository.findByEntityIdAndActiveInd(companyCode, true).ifPresent(c -> {
                organisationRepository.delete(c);
            });
            throw e;
        }
    }

    void createAdminDepartmentAndRole(String authHeader, Object companyCode, Object companyAdminEmail) {
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders requestHeaders = new HttpHeaders();
        requestHeaders.add(HttpHeaders.AUTHORIZATION, authHeader);
        HttpEntity<Object> requestEntity = new HttpEntity<>(requestHeaders);
        UriComponentsBuilder uriBuilder = UriComponentsBuilder
                .fromHttpUrl(userServiceUrl + "/createAdminDepartmentAndRole").queryParam("company", companyCode)
                .queryParam("companyAdminEmail", companyAdminEmail);
        ResponseEntity<Object> responseEntity = restTemplate.exchange(uriBuilder.toUriString(), HttpMethod.PUT,
                requestEntity, Object.class);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            logger.info("response received ok from user service create company admin");
        } else {
            logger.error("Error response from user service create admin: ", responseEntity.getStatusCode());
            throw new RuntimeException("Error recieved from user service while creating company");
        }
    }

    void createKafkaTopic(String companyCode) {
        final ZkClient zkClient = new ZkClient(kafkaZookeeperHosts, 15 * 1000, 8 * 1000, ZKStringSerializer$.MODULE$);
        ZkUtils zkUtils = new ZkUtils(zkClient, new ZkConnection(kafkaZookeeperHosts), false);
        String topicName = companyCode + "-enriched-sensor-data";
        final int PARTITIONS = 1;
        final int NO_OF_REPLICATION = 1;
        Properties topicConfiguration = new Properties();
        AdminUtils.createTopic(zkUtils, topicName, PARTITIONS, NO_OF_REPLICATION, topicConfiguration,
                RackAwareMode.Disabled$.MODULE$);
    }

    @Transactional
    public void addOrgToParent(Organisation organisation, String parentId, String companyEntityId) {
        if (organisationRepository.findByEntityIdAndActiveInd(organisation.getEntityId(), true).isPresent()) {
            throw new RuntimeException("An active entity already exists with entityId: " + organisation.getEntityId());
        }
        organisation.setActiveInd(true);
        // To create a company leave parent as null
        if (parentId != null && !parentId.equals("")) {
            OrgHierarchy orgHierarchy = orgHierarchyRepository
                    .findByCompanyEntityIdAndType(companyEntityId, organisation.getType(), 0)
                    .orElseThrow(() -> new RuntimeException(
                            "Given org type: " + organisation.getType() + "not found for: " + companyEntityId));
            if (orgHierarchy == null)
                throw new RuntimeException(
                        "given type: " + organisation.getType() + " not allowed for company: " + companyEntityId);
            Organisation parent = organisationRepository.findByEntityIdAndActiveInd(parentId, true)
                    .orElseThrow(() -> new RuntimeException("No active parent found with entityId: " + parentId));
            organisation.setParent(parent);
        }
        if ((parentId == null || parentId.equals("")) && !organisation.getType().equals("company"))
            throw new RuntimeException("invalid params for entityId: " + organisation.getEntityId());

        organisationRepository.save(organisation);
        logger.info("created org: " + organisation.getName() + " under parent: " + parentId);
    }

    // TODO: MAKE TRASACTIONAL
    @Transactional
    public void deleteOrg(String entityId) {
        List<Organisation> entities = new ArrayList<>();
        entities.add(organisationRepository.findByEntityIdAndActiveInd(entityId, true)
                .orElseThrow(() -> new RuntimeException("No active entity found with entityId: " + entityId)));
        deleteHierarchy(entities);
        List<String> descendantAssetsCodes = assetRepository.getAllDescendantAssetsCodesForOrg(entityId);
        List<Asset> descendantAssets = assetRepository.findByCodeInAndActiveInd(descendantAssetsCodes, true);
        descendantAssets.stream().forEach(a -> {
            a.setActiveInd(false);
            a.setDeactivationTime(new Date());
        });
        assetRepository.save(descendantAssets, 0);
        logger.info("deleted org: " + entityId);
    }

    @Transactional
    public void checkParamsAndEditOrgPart(String company, String entityId, Map<String, String> editProperties) {
        checkIfCompanyExists(company);
        Organisation orgPart = organisationRepository.findByEntityIdAndActiveInd(entityId, true)
                .orElseThrow(() -> new RuntimeException("No active org part found with code: " + entityId));
        for (Entry<String, String> newOrgProp : editProperties.entrySet()) {
            orgPart.getProperties().put(newOrgProp.getKey(), newOrgProp.getValue());
        }
        organisationRepository.save(orgPart, 0);
    }

    @Transactional
    public void editOrgType(String company, String orgTypeName, List<EditPropertyType> editProperties) {
        Organisation companyNode = checkIfCompanyExists(company);
        OrgHierarchy orgType = orgHierarchyRepository.findByCompanyEntityIdAndType(company, orgTypeName, 1).orElseThrow(
                () -> new RuntimeException("Given type: " + orgTypeName + "not found for company: " + company));
        for (EditPropertyType editProperty : editProperties) {
            if (editProperty.getEditMode().equals(EditPropertyType.Mode.ADD)) {
                orgType.getAllowedProperties().add(editProperty.getNewPropertyType());
            } else if (editProperty.getEditMode().equals(EditPropertyType.Mode.DELETE)) {
                orgType.getAllowedProperties().removeIf(p -> p.getName().equals(editProperty.getPropName()));
                // Using raw query as spring neo4j won't take property names as parameters
                String removeFromOrgPartsQuery = String.format(
                        "MATCH (n:Organisation) where n.type= '%s' "
                                + "MATCH (m0:`Organisation`) WHERE ID(m0) = %s and m0.type='company' "
                                + "MATCH (n)<-[:SUB_ORG*]-(m0) REMOVE n.`properties.%s`",
                        orgTypeName, companyNode.getId(), editProperty.getPropName());
                dbSession.query(removeFromOrgPartsQuery, Collections.emptyMap());
            } else if (editProperty.getEditMode().equals(EditPropertyType.Mode.EDIT)) {
                PropertyType propType = orgType.getAllowedProperties().stream()
                        .filter(p -> p.getName().equals(editProperty.getPropName())).findFirst()
                        .orElseThrow(() -> new RuntimeException("Given propType: " + editProperty.getPropName()
                                + " not found for type: " + orgTypeName + " company: " + company));
                propType.setName(editProperty.getNewPropertyType().getName());
                propType.setNullable(editProperty.getNewPropertyType().getNullable());
                // Because of a neo4j SET bug need to use WITH in below query
                String updateOrgPartsQuery = String.format(
                        "MATCH (n:Organisation) where n.type= '%s' "
                                + "MATCH (m0:`Organisation`) WHERE ID(m0) = %s and m0.type='company' "
                                + "MATCH (n)<-[:SUB_ORG*]-(m0) with n, n.`properties.%s` as oldProp "
                                + "SET n.`properties.%s` = oldProp REMOVE n.`properties.%s`",
                        orgTypeName, companyNode.getId(), editProperty.getPropName(),
                        editProperty.getNewPropertyType().getName(), editProperty.getPropName(),
                        editProperty.getPropName());
                dbSession.query(updateOrgPartsQuery, Collections.emptyMap());
            }
        }
        orgHierarchyRepository.save(orgType);
    }

    private void deleteHierarchy(List<Organisation> entities) {
        for (Organisation entity : entities) {
            entity.setActiveInd(false);
            Set<Organisation> activeChildren = entity.getActiveChildren();
            activeChildren.stream().forEach(e -> e.setActiveInd(false));
            organisationRepository.save(entity);
            organisationRepository.saveAll(activeChildren);
        }
    }

    public void createAssetConnection(String sourceAssetId, String destinationAssetId, String connectionType,
            Map<String, String> properties, String authHeader) {
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders requestHeaders = new HttpHeaders();
        requestHeaders.setContentType(MediaType.APPLICATION_JSON);
        requestHeaders.add(HttpHeaders.AUTHORIZATION, authHeader);
        HttpEntity<?> requestEntity = new HttpEntity<>(properties, requestHeaders);
        UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(asetServiceUrl + "/createAssetConnection")
                .queryParam("source", sourceAssetId).queryParam("destination", destinationAssetId)
                .queryParam("connectionType", connectionType).queryParam("company", "7a856039-185d-41ca-b51e-6582156c8f8a");
        ResponseEntity<String> responseEntity = restTemplate.exchange(uriBuilder.toUriString(), HttpMethod.PUT,
                requestEntity, String.class);

        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            logger.info("response received ok from asset service create asset connection");
        } else {
            logger.error("Error response from asset service create asset connection: ", responseEntity.getStatusCode());
            throw new RuntimeException("Error recieved from asset service while creating asset connection");
        }
    }

    @Transactional
    public void reassignEntity(String entityId, String newParentId, String authHeader) {
        Organisation newParent = organisationRepository.findByEntityIdAndActiveInd(newParentId, true)
                .orElseThrow(() -> new RuntimeException("No active parent found with entityId: " + newParentId));

        Organisation existingEntity = organisationRepository.findByEntityIdAndActiveInd(entityId, true)
                .orElseThrow(() -> new RuntimeException("No active entity found with entityId: " + entityId));
        List<Asset> oldAssetsToConnect = new LinkedList<>();
        reAssignHierarchy(newParent, existingEntity, oldAssetsToConnect);
        for (Asset oldAsset : oldAssetsToConnect) {
            for (AssetConnection conOut : oldAsset.getConnnectionOut()) {
                createAssetConnection(conOut.getStartAsset().getCode(), conOut.getEndAsset().getCode(),
                        conOut.getType(), conOut.getProperties(), authHeader);
            }
            for (AssetConnection conIn : oldAsset.getConnnectionIn()) {
                createAssetConnection(conIn.getStartAsset().getCode(), conIn.getEndAsset().getCode(), conIn.getType(),
                        conIn.getProperties(), authHeader);
            }
        }
    }

    // To maintain history of leaf node data related to a hierarchy
    // TODO: MAKE TRANSACTIONAL
    private void reAssignHierarchy(Organisation newParent, Organisation existingEntity,
            List<Asset> oldAssetsToConnect) {
        Organisation newEntity = new Organisation(existingEntity.getName(), existingEntity.getType(),
                existingEntity.getEntityId(), existingEntity.getProperties(), true);
        newEntity.setParent(newParent);
        existingEntity.setActiveInd(false);
        organisationRepository.saveAll(Arrays.asList(existingEntity, newEntity));

        List<String> childAssetsCodes = assetRepository.getAllChildrenAssetsCodesForOrg(existingEntity.getId());
        List<Asset> childAssets = assetRepository.findByCodeInAndActiveInd(childAssetsCodes, true);
        List<Asset> assetsTosave = new ArrayList<>();
        for (Asset oldAsset : childAssets) {
            oldAsset.setActiveInd(false);
            oldAsset.setDeactivationTime(new Date());
            oldAssetsToConnect.add(oldAsset);
            Asset newAsset = new Asset(oldAsset.getName(), oldAsset.getType(), oldAsset.getCode(), newEntity,
                    oldAsset.getProperties(), true);
            assetsTosave.add(oldAsset);
            assetsTosave.add(newAsset);
        }
        assetRepository.saveAll(assetsTosave);
        Set<Organisation> children = existingEntity.getActiveChildren();
        for (Organisation child : children) {
            reAssignHierarchy(newEntity, child, oldAssetsToConnect);
        }
    }

    public Set<Organisation> getAccessibleSiblings(String orgPartCode, Set<String> userOrgParts) {
        Organisation orgPart = organisationRepository.findByEntityIdAndActiveInd(orgPartCode, true)
                .orElseThrow(() -> new RuntimeException("No active org part found with entityId: " + orgPartCode));
        Organisation parent = orgPart.getParent();
        if (parent == null)
            return new HashSet<Organisation>();
        return getAccessibleChildren(parent.getEntityId(), userOrgParts);
    }

    public List<OrgHierarchy> getOrgSubTypesForCompany(String companyEntityId) {
        return orgHierarchyRepository.findByCompanyEntityId(companyEntityId, 0);
    }

    public List<Organisation> getOrgPartsForCompany(String companyEntityId, String type) {
        return organisationRepository.findActiveSubOrgsByType(type, companyEntityId, 0);
    }

    private Organisation checkIfCompanyExists(String company) {
        return organisationRepository.findActiveEntityWithDepthOne(company)
                .orElseThrow(() -> new RuntimeException("No active company found with entityId: " + company));
    }
}

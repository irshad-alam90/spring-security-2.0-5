package com.sense.organisation.service;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.sense.organisation.service.OrganisationService;
import com.sense.sensemodel.model.EditPropertyType;
import com.sense.sensemodel.model.PropertyType;
import com.sense.sensemodel.model.assets.Asset;
import com.sense.sensemodel.model.assets.AssetConnection;
import com.sense.sensemodel.model.organisation.OrgHierarchy;
import com.sense.sensemodel.model.organisation.Organisation;
import com.sense.sensemodel.repository.assets.AssetRepository;
import com.sense.sensemodel.repository.organisation.OrgHierarchyRepository;
import com.sense.sensemodel.repository.organisation.OrganisationRepository;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@Transactional
public class OrganisationServiceTest {

    @Autowired
    private OrganisationService organisationService;

    @SpyBean
    private OrganisationService orgServiceSpyBean;

    @Autowired
    private OrganisationRepository organisationRepository;

    @Autowired
    private OrgHierarchyRepository orgHierarchyRepository;

    @Autowired
    private AssetRepository assetRepository;

    @Before
    public void setUp() {
        Organisation organisation = new Organisation("c1", "company", "c001", null, true);
        Set<Organisation> children = new HashSet<>();
        Map<String, String> properties = new HashMap<String, String>();
        properties.put("p1", "property1");
        Organisation child1 = new Organisation("d1", "division", "d001", properties, true);
        Organisation child2 = new Organisation("d2", "division", "d002", null, true);
        children.add(child1);
        children.add(child2);
        organisation.setSubOrgs(children);
        organisationRepository.save(organisation);

        Asset asset = new Asset("a1", "assetType1", "a101", organisation, null, true);
        assetRepository.save(asset);
    }

    @Test(expected = RuntimeException.class)
    public void testGetChildrenForEntityIfEntityNotExist() {
        String entityId = "c003";
        organisationService.getChildrenForEntity(entityId);
    }

    @Test
    public void testGetChildrenForEntity() {
        String entityId = "c001";
        Set<Organisation> childrenForEntity = organisationService.getChildrenForEntity(entityId);
        Organisation child = childrenForEntity.stream().filter(c -> c.getEntityId().equals("d001")).findAny()
                .orElseThrow(() -> new RuntimeException());
        assertEquals("d1", child.getName());
        assertEquals("division", child.getType());
    }

    @Test
    public void testGetAccessibleChildren() {
        String entityId = "c001";
        Set<String> userOrgParts = new HashSet<>();
        userOrgParts.add("d001");
        userOrgParts.add("d002");

        Set<Organisation> accessibleChildren = organisationService.getAccessibleChildren(entityId, userOrgParts);
        Organisation accessibleChild = accessibleChildren.stream().filter(a -> a.getEntityId().equals("d001")).findAny()
                .orElseThrow(() -> new RuntimeException());
        assertEquals("d1", accessibleChild.getName());
    }

    @Test(expected = RuntimeException.class)
    public void testGetAccessibleSiblingsIfOrgPartNotFound() {
        String orgPartCode = "c112";
        Set<String> userOrgParts = new HashSet<>();
        userOrgParts.add("z111");
        organisationService.getAccessibleSiblings(orgPartCode, userOrgParts);
    }

    @Test
    public void testGetAccessibleSiblingsIfParentNull() {
        String orgPartCode = "c111";
        Set<String> userOrgParts = new HashSet<>();
        userOrgParts.add("z111");
        Organisation company = new Organisation("c1", "company", "c111", null, true);
        Organisation zone = new Organisation("z1", "zone", "z111", null, true);
        zone.setParent(company);
        organisationRepository.save(zone);
        Set<Organisation> accessibleSiblings = organisationService.getAccessibleSiblings(orgPartCode, userOrgParts);
        assertEquals(0, accessibleSiblings.size());
    }

    @Test
    public void testGetAccessibleSiblings() {
        String orgPartCode = "z111";
        Set<String> userOrgParts = new HashSet<>();
        userOrgParts.add("z111");
        userOrgParts.add("z112");

        Organisation company = new Organisation("c1", "company", "c101", null, true);
        Organisation zone1 = new Organisation("z1", "zone", "z111", null, true);
        Organisation zone2 = new Organisation("z2", "zone", "z112", null, true);
        Organisation zone3 = new Organisation("z3", "zone", "z113", null, true);
        company.setSubOrgs(new HashSet<>(Arrays.asList(zone1, zone2, zone3)));
        organisationRepository.save(company);

        Set<Organisation> accessibleSiblings = organisationService.getAccessibleSiblings(orgPartCode, userOrgParts);
        Organisation accessibleSibling1 = accessibleSiblings.stream()
                .filter(as -> as.getEntityId().equals(zone1.getEntityId())).findAny()
                .orElseThrow(() -> new RuntimeException());
        assertEquals(zone1.getName(), accessibleSibling1.getName());
        Organisation accessibleSibling2 = accessibleSiblings.stream()
                .filter(as -> as.getEntityId().equals(zone2.getEntityId())).findAny()
                .orElseThrow(() -> new RuntimeException());
        assertEquals(zone2.getName(), accessibleSibling2.getName());
    }

    /* create company */
    @Test(expected = RuntimeException.class)
    public void testCreateCompanyIfCompanyExist() {
        String companyCode = "c001";
        String companyName = "c1";
        String companyAdminEmail = "admin@gmail.com";
        String authHeader = "Bearer kdddks.erdssds834dj.4554fdf";
        orgServiceSpyBean.createCompany(companyCode, companyName, companyAdminEmail, authHeader);
    }

    @Test
    public void testCreateCompany() {
        String companyCode = "c111";
        String companyName = "c11";
        String companyAdminEmail = "admin@gmail.com";
        String authHeader = "Bearer kdddks.erdssds834dj.4554fdf";

        Mockito.doNothing().when(orgServiceSpyBean).createAdminDepartmentAndRole(Mockito.anyString(),
                Mockito.anyString(), Mockito.anyString());
        Mockito.doNothing().when(orgServiceSpyBean).createKafkaTopic(Mockito.anyString());
        orgServiceSpyBean.createCompany(companyCode, companyName, companyAdminEmail, authHeader);
        Organisation company = organisationRepository.findByEntityIdAndActiveInd(companyCode, true).orElse(null);
        assertEquals(companyName, company.getName());
    }

    /* Add Organisation to parent */
    @Test(expected = RuntimeException.class)
    public void testAddOrgToParentIfEntityExist() {
        String parentId = null;
        String companyEntityId = null;
        Organisation organisation = new Organisation("d1", "division", "d001", null, true);
        organisationService.addOrgToParent(organisation, parentId, companyEntityId);
    }

    @Test(expected = RuntimeException.class)
    public void testAddOrgToParentIfOrgHierarchyNotNull() {
        String parentId = "c119";
        String companyEntityId = "c119";
        Organisation organisation = new Organisation("z1", "zone", "z001", null, true);
        organisationService.addOrgToParent(organisation, parentId, companyEntityId);
    }

    @Test(expected = RuntimeException.class)
    public void testAddOrgToParentIfParentNotExist() {
        String parentId = "d9898";
        String companyEntityId = "c001";
        OrgHierarchy parentOrgType = new OrgHierarchy("c001", "company", null);
        OrgHierarchy childOrgType = new OrgHierarchy("c001", "zone", parentOrgType);
        orgHierarchyRepository.save(childOrgType);
        Organisation organisation = new Organisation("z1", "zone", "z001", null, true);

        organisationService.addOrgToParent(organisation, parentId, companyEntityId);
    }

    @Test(expected = RuntimeException.class)
    public void testAddOrgToParentIfOrgTypeCompany() {
        String parentId = "d001";
        String companyEntityId = "c001";
        OrgHierarchy parentOrgType = new OrgHierarchy("c001", "company", null);
        OrgHierarchy childOrgType = new OrgHierarchy("c001", "zone", parentOrgType);
        orgHierarchyRepository.save(childOrgType);
        Organisation organisation = new Organisation("c1", "company", "c001", null, true);
        organisationService.addOrgToParent(organisation, parentId, companyEntityId);
    }

    @Test(expected = RuntimeException.class)
    public void testAddOrgToParentIfParentIdNull() {
        String parentId = null;
        String companyEntityId = "c001";

        OrgHierarchy inputOrgHierarchy = new OrgHierarchy("c001", "zone", null);
        orgHierarchyRepository.save(inputOrgHierarchy);
        Organisation organisation = new Organisation("z1", "zone", "z001", null, true);
        organisationService.addOrgToParent(organisation, parentId, companyEntityId);
    }

    @Test
    public void testAddOrgToParentSuccessfully() {
        String parentId = "d001";
        String companyEntityId = "c001";

        OrgHierarchy inputOrgHierarchy = new OrgHierarchy("c001", "zone", null);
        orgHierarchyRepository.save(inputOrgHierarchy);
        Organisation organisation = new Organisation("z1", "zone", "z001", null, true);
        organisationService.addOrgToParent(organisation, parentId, companyEntityId);
        Organisation parent = organisationRepository.findByEntityIdAndActiveInd("d001", true).orElse(null);
        Organisation child = parent.getActiveChildren().stream()
                .filter(ac -> ac.getEntityId().equals(organisation.getEntityId())).findAny()
                .orElseThrow(() -> new RuntimeException());
        assertEquals(organisation.getName(), child.getName());
    }

    /* Get orgsubTypes for company */
    @Test
    public void testGetOrgSubTypesForCompany() {
        String companyEntityId = "c001";
        OrgHierarchy orgSubType1 = new OrgHierarchy("c001", "company", null);
        OrgHierarchy orgSubType2 = new OrgHierarchy("c001", "division", null);
        OrgHierarchy orgSubType3 = new OrgHierarchy("c001", "zone", null);
        orgHierarchyRepository.saveAll(Arrays.asList(orgSubType1, orgSubType2, orgSubType3));
        List<OrgHierarchy> orgSubTypes = organisationService.getOrgSubTypesForCompany(companyEntityId);
        OrgHierarchy orgSubType = orgSubTypes.stream().filter(o -> o.getType().equals("division")).findAny()
                .orElseThrow(() -> new RuntimeException());
        assertEquals("division", orgSubType.getType());
    }

    /* Get orgParts for company */
    @Test
    public void testGetOrgPartsForCompany() {
        String companyEntityId = "c001";
        String type = "division";

        List<Organisation> orgPartsForComp = organisationService.getOrgPartsForCompany(companyEntityId, type);
        Organisation orgPart = orgPartsForComp.stream().filter(op -> op.getEntityId().equals("d001")).findAny()
                .orElseThrow(() -> new RuntimeException());
        assertEquals("d1", orgPart.getName());
    }

    /* Delete Organisation */
    @Test(expected = RuntimeException.class)
    public void testDeleteOrgIfEntitiesNotExist() {
        String entityId = "d003";
        organisationService.deleteOrg(entityId);
    }

    @Test
    public void testDeleteOrgSuccessfully() {
        String entityId = "c001";
        OrgHierarchy orgHierarchy = new OrgHierarchy("c001", "division", null);
        orgHierarchyRepository.save(orgHierarchy);

        organisationService.deleteOrg(entityId);

        Organisation entity = organisationRepository.findByEntityIdAndActiveInd(entityId, false).orElse(null);
        assertEquals(false, entity.isActiveInd());

        Organisation subOrg1 = entity.getSubOrgs().stream().filter(so -> so.getEntityId().equals("d001")).findAny()
                .orElseThrow(() -> new RuntimeException());
        assertEquals(false, subOrg1.isActiveInd());

        Organisation subOrg2 = entity.getSubOrgs().stream().filter(so -> so.getEntityId().equals("d002")).findAny()
                .orElseThrow(() -> new RuntimeException());
        assertEquals(false, subOrg2.isActiveInd());
        Asset asset = assetRepository.findByCodeAndActiveInd("a101", false).orElse(null);
        assertEquals(false, asset.isActiveInd());
    }

    /* Reassign Entity */
    @Test(expected = RuntimeException.class)
    public void testReassignEntityIfNewParentNotExist() {
        String newParentId = "c121";
        String entityId = "z001";
        String authHeader = "Bearer acbdd34e.ksdf434fkkd.jdfddfdf";
        orgServiceSpyBean.reassignEntity(entityId, newParentId, authHeader);
    }

    @Test(expected = RuntimeException.class)
    public void testReassignEntityIfEntityNotExist() {
        String newParentId = "c002";
        String entityId = "z001";
        String authHeader = "Bearer acbdd34e.ksdf434fkkd.jdfddfdf";
        Organisation company = new Organisation("c2", "company", "c002", null, true);
        organisationRepository.save(company);

        orgServiceSpyBean.reassignEntity(entityId, newParentId, authHeader);
    }

    @Test
    public void testReassignEntitySuccessfully() {
        String newParentId = "c002";
        String entityId = "z002";
        String authHeader = "Bearer acbdd34e.ksdf434fkkd.jdfddfdf";
        getSavedOrgData();

        Mockito.doNothing().when(orgServiceSpyBean).createAssetConnection(Mockito.anyString(), Mockito.anyString(),
                Mockito.anyString(), Mockito.any(), Mockito.anyString());

        orgServiceSpyBean.reassignEntity(entityId, newParentId, authHeader);
        Organisation newParent = organisationRepository.findByEntityIdAndActiveInd(newParentId, true).orElse(null);
        Organisation reAssignedEntity = newParent.getActiveChildren().stream()
                .filter(ac -> ac.getEntityId().equals(entityId)).findAny().orElseThrow(() -> new RuntimeException());
        assertEquals("z2", reAssignedEntity.getName());
    }

    @Test(expected = RuntimeException.class)
    public void testCheckParamsAndEditOrgPartIfCompanyNotFound() {
        String company = "c002";
        String entityId = "d002";
        Map<String, String> editProperties = new HashMap<String, String>();
        editProperties.put("p2", "property2");

        organisationService.checkParamsAndEditOrgPart(company, entityId, editProperties);
    }

    @Test(expected = RuntimeException.class)
    public void testCheckParamsAndEditOrgPartIfOrgPartNotFound() {
        String company = "c001";
        String entityId = "d002";
        Map<String, String> editProperties = new HashMap<String, String>();
        editProperties.put("p2", "property2");

        organisationService.checkParamsAndEditOrgPart(company, entityId, editProperties);
    }

    @Test
    public void testCheckParamsAndEditOrgPart() {
        String company = "c001";
        String entityId = "d001";
        Map<String, String> editProperties = new HashMap<String, String>();
        editProperties.put("p2", "property2");

        organisationService.checkParamsAndEditOrgPart(company, entityId, editProperties);
        Organisation updatedOrgPart = organisationRepository.findByEntityIdAndActiveInd(entityId, true).orElse(null);

        String property = updatedOrgPart.getProperties().entrySet().stream().filter(p -> p.getKey().equals("p2"))
                .map(Map.Entry::getValue).findAny().orElseThrow(() -> new RuntimeException());
        assertEquals("property2", property);
    }

    @Test(expected = RuntimeException.class)
    public void testEditOrgTypeIfCompanyNotFound() {
        String company = "c002";
        String orgTypeName = "zone";
        List<EditPropertyType> editProperties = new ArrayList<>();
        organisationService.editOrgType(company, orgTypeName, editProperties);
    }

    @Test(expected = RuntimeException.class)
    public void testEditOrgTypeIfOrgTypeNotFound() {
        String company = "c001";
        String orgTypeName = "zone";
        List<EditPropertyType> editProperties = new ArrayList<>();
        organisationService.editOrgType(company, orgTypeName, editProperties);
    }

    @Test
    public void testEditOrgTypeIfEditModeAdd() {
        String company = "c001";
        String orgTypeName = "division";
        EditPropertyType editPropertyType = new EditPropertyType();
        editPropertyType.setPropName("property1");
        editPropertyType.setEditMode(EditPropertyType.Mode.ADD);
        editPropertyType.setNewPropertyType(new PropertyType("property2", true, true));
        List<EditPropertyType> editProperties = new ArrayList<>(Arrays.asList(editPropertyType));

        Set<PropertyType> allowedProperties = new HashSet<>(Arrays.asList(new PropertyType("property1", true, true)));
        OrgHierarchy companyType = new OrgHierarchy("c001", "company", null);
        OrgHierarchy divsionType = new OrgHierarchy("c001", "division", companyType);
        divsionType.setAllowedProperties(allowedProperties);
        orgHierarchyRepository.save(divsionType);

        organisationService.editOrgType(company, orgTypeName, editProperties);
        OrgHierarchy updatedType = orgHierarchyRepository
                .findByCompanyEntityIdAndType(company, divsionType.getType(), 0).orElse(null);
        PropertyType property = updatedType.getAllowedProperties().stream()
                .filter(p -> p.getName().equals(editPropertyType.getNewPropertyType().getName())).findAny()
                .orElseThrow(() -> new RuntimeException());
        assertEquals(editPropertyType.getNewPropertyType().getName(), property.getName());
    }

    @Test
    public void testEditOrgTypeIfEditModeDelete() {
        String company = "c001";
        String orgTypeName = "division";
        EditPropertyType editPropertyType = new EditPropertyType();
        editPropertyType.setPropName("property1");

        editPropertyType.setEditMode(EditPropertyType.Mode.DELETE);
        editPropertyType.setNewPropertyType(new PropertyType("property2", true, true));
        List<EditPropertyType> editProperties = new ArrayList<>(Arrays.asList(editPropertyType));

        Set<PropertyType> allowedProperties = new HashSet<>(Arrays.asList(new PropertyType("property1", true, true)));
        OrgHierarchy companyType = new OrgHierarchy("c001", "company", null);
        OrgHierarchy divsionType = new OrgHierarchy("c001", "division", companyType);
        divsionType.setAllowedProperties(allowedProperties);
        orgHierarchyRepository.save(divsionType);

        organisationService.editOrgType(company, orgTypeName, editProperties);
        OrgHierarchy updatedType = orgHierarchyRepository
                .findByCompanyEntityIdAndType(company, divsionType.getType(), 0).orElse(null);
        PropertyType property = updatedType.getAllowedProperties().stream()
                .filter(p -> p.getName().equals(editPropertyType.getNewPropertyType().getName())).findAny()
                .orElse(null);
        boolean deletedProperty;
        if (property == null) {
            deletedProperty = true;
            assertEquals(true, deletedProperty);
        }
    }

    @Test(expected = RuntimeException.class)
    public void testEditOrgTypeIfEditModeEditAndProperTypeNotFound() {
        String company = "c001";
        String orgTypeName = "division";
        EditPropertyType editPropertyType = new EditPropertyType();
        editPropertyType.setPropName("property1");
        editPropertyType.setEditMode(EditPropertyType.Mode.EDIT);
        editPropertyType.setNewPropertyType(new PropertyType("property2", true, true));
        List<EditPropertyType> editProperties = new ArrayList<>(Arrays.asList(editPropertyType));

        Set<PropertyType> allowedProperties = new HashSet<>(Arrays.asList(new PropertyType("property3", true, true)));
        OrgHierarchy companyType = new OrgHierarchy("c001", "company", null);
        OrgHierarchy divsionType = new OrgHierarchy("c001", "division", companyType);
        divsionType.setAllowedProperties(allowedProperties);
        orgHierarchyRepository.save(divsionType);

        organisationService.editOrgType(company, orgTypeName, editProperties);
    }

    @Test
    public void testEditOrgTypeIfEditModeEdit() {
        String company = "c001";
        String orgTypeName = "division";
        EditPropertyType editPropertyType = new EditPropertyType();
        editPropertyType.setPropName("property1");
        editPropertyType.setEditMode(EditPropertyType.Mode.EDIT);
        editPropertyType.setNewPropertyType(new PropertyType("property2", true, true));
        List<EditPropertyType> editProperties = new ArrayList<>(Arrays.asList(editPropertyType));

        Set<PropertyType> allowedProperties = new HashSet<>(Arrays.asList(new PropertyType("property1", true, true)));
        OrgHierarchy companyType = new OrgHierarchy("c001", "company", null);
        OrgHierarchy divsionType = new OrgHierarchy("c001", "division", companyType);
        divsionType.setAllowedProperties(allowedProperties);
        orgHierarchyRepository.save(divsionType);

        organisationService.editOrgType(company, orgTypeName, editProperties);
        OrgHierarchy updatedType = orgHierarchyRepository
                .findByCompanyEntityIdAndType(company, divsionType.getType(), 0).orElse(null);
        PropertyType property = updatedType.getAllowedProperties().stream()
                .filter(p -> p.getName().equals(editPropertyType.getNewPropertyType().getName())).findAny()
                .orElseThrow(() -> new RuntimeException());
        assertEquals(editPropertyType.getNewPropertyType().getName(), property.getName());
    }

    private void getSavedOrgData() {
        Organisation company1 = new Organisation("c1", "company", "c001", null, true);
        Organisation child1 = new Organisation("d2", "division", "d002", null, true);
        child1.setParent(company1);
        organisationRepository.save(child1);
        Organisation company2 = new Organisation("c2", "company", "c002", null, true);
        organisationRepository.save(company2);
        OrgHierarchy orgHierarchy = new OrgHierarchy("c001", "zone", null);
        orgHierarchyRepository.save(orgHierarchy);

        Organisation zone = new Organisation("z2", "zone", "z002", null, true);
        Asset asset1 = new Asset("a1", "assetType1", "a101", zone, null, true);
        Asset asset2 = new Asset("a2", "assetType1", "a102", zone, null, true);
        assetRepository.saveAll(Arrays.asList(asset1, asset2));

        AssetConnection conOut = new AssetConnection(asset1, asset2, "assetConnectionType1", null);
        Set<AssetConnection> connectionOut = new HashSet<>();
        connectionOut.add(conOut);
        asset1.setConnnectionOut(connectionOut);

        AssetConnection conIn = new AssetConnection(asset2, asset1, "assetConnectionType1", null);
        Set<AssetConnection> connectionIn = new HashSet<>();
        connectionIn.add(conIn);
        asset2.setConnnectionIn(connectionIn);
    }
}

package com.sense.organisation.controller;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers;
import org.springframework.security.web.FilterChainProxy;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sense.organisation.controller.OrganisationController;
import com.sense.organisation.service.OrganisationService;
import com.sense.security.model.JwtUserDetails;
import com.sense.security.util.JwtTokenUtil;
import com.sense.sensemodel.model.EditPropertyType;
import com.sense.sensemodel.model.PropertyType;
import com.sense.sensemodel.model.organisation.OrgHierarchy;
import com.sense.sensemodel.model.organisation.Organisation;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.verify;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.mockito.Mockito.times;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

@RunWith(SpringRunner.class)
@SpringBootTest
public class OrganisationControllerTest {

    private MockMvc mockMvc;
    private MockMvc mockMvc2;
    @Mock
    OrganisationService organisationService;

    @InjectMocks
    OrganisationController organisationController;

    @Autowired
    private FilterChainProxy springSecurityFilterChain;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Before
    public void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(organisationController).build();
        mockMvc2 = MockMvcBuilders.standaloneSetup(organisationController)
                .apply(SecurityMockMvcConfigurers.springSecurity(springSecurityFilterChain)).build();
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetChildrenForEntity() throws Exception {
        Organisation child1 = new Organisation("cr1", "circle", "cr001", null, true);
        Organisation child2 = new Organisation("cr2", "circle", "cr002", null, true);
        Set<Organisation> children = new HashSet<Organisation>(Arrays.asList(child1, child2));
        String URI = "/org/children/c001";

        Mockito.when(organisationService.getChildrenForEntity(Mockito.anyString())).thenReturn(children);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.get(URI).accept(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        String expectedJson = this.mapToJson(children);
        String outputInJson = result.getResponse().getContentAsString();
        assertEquals(HttpStatus.OK.value(), result.getResponse().getStatus());
        assertEquals(expectedJson, outputInJson);
        verify(organisationService, times(1)).getChildrenForEntity(Mockito.anyString());
    }

    @Test
    public void testCreateCompany() throws Exception {
        String URI = "/org/createCompany";
        String accessToken = generateToken();

        Mockito.doNothing().when(organisationService).createCompany(Mockito.anyString(), Mockito.anyString(),
                Mockito.anyString(), Mockito.anyString());
        RequestBuilder requestBuilder = MockMvcRequestBuilders.put(URI).param("companyCode", "c001")
                .param("companyName", "c1").param("companyAdminEmail", "admin@gmail.com")
                .param("Authorization", accessToken).header("Authorization", "Bearer " + accessToken)
                .accept(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc2.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
        verify(organisationService, times(1)).createCompany(Mockito.anyString(), Mockito.anyString(),
                Mockito.anyString(), Mockito.anyString());
    }

    @Test
    public void testAddChildToParent() throws Exception {
        String URI = "/org/add";
        Organisation organisation = new Organisation("d1", "division", "d001", null, true);
        String inputInJson = this.mapToJson(organisation);

        Mockito.doNothing().when(organisationService).addOrgToParent(Mockito.any(Organisation.class),
                Mockito.anyString(), Mockito.anyString());
        RequestBuilder requestBuilder = MockMvcRequestBuilders.put(URI).param("parent", "c001")
                .param("companyEntityId", "BRPL").accept(MediaType.APPLICATION_JSON).content(inputInJson)
                .contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
        verify(organisationService, times(1)).addOrgToParent(Mockito.any(Organisation.class), Mockito.anyString(),
                Mockito.anyString());
    }

    @Test
    public void testAccessibleChildren() throws Exception {
        String accessToken = generateToken();
        Organisation accessibleChild1 = new Organisation("d1", "division", "d101", null, true);
        Organisation accessibleChild2 = new Organisation("d2", "division", "d102", null, true);
        Set<Organisation> organisations = new HashSet<>(Arrays.asList(accessibleChild1, accessibleChild2));

        String URI = "/org/accessibleChildren";
        Mockito.when(organisationService.getAccessibleChildren(Mockito.anyString(), Mockito.anySet()))
                .thenReturn(organisations);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.get(URI).accept(MediaType.APPLICATION_JSON)
                .param("entityId", "c101").header("Authorization", "Bearer " + accessToken);
        MvcResult result = mockMvc2.perform(requestBuilder).andReturn();
        String expectedJson = this.mapToJson(organisations);
        String outputInJson = result.getResponse().getContentAsString();
        assertEquals(HttpStatus.OK.value(), result.getResponse().getStatus());
        assertEquals(expectedJson, outputInJson);
        verify(organisationService, times(1)).getAccessibleChildren(Mockito.anyString(), Mockito.anySet());
    }

    @Test
    public void testAccessibleSiblings() throws Exception {
        String accessToken = generateToken();
        Organisation accessibleSibling1 = new Organisation("z1", "zone", "z101", null, true);
        Organisation accessibleSibling2 = new Organisation("z2", "zone", "z102", null, true);
        Set<Organisation> accessibleSiblings = new HashSet<>(Arrays.asList(accessibleSibling1, accessibleSibling2));
        String URI = "/org/accessibleSiblings";
        Mockito.when(organisationService.getAccessibleSiblings(Mockito.anyString(), Mockito.anySet()))
                .thenReturn(accessibleSiblings);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.get(URI).accept(MediaType.APPLICATION_JSON)
                .param("entityId", "z101").header("Authorization", "Bearer " + accessToken);
        MvcResult result = mockMvc2.perform(requestBuilder).andReturn();
        String expectedJson = this.mapToJson(accessibleSiblings);
        String outputInJson = result.getResponse().getContentAsString();
        assertEquals(HttpStatus.OK.value(), result.getResponse().getStatus());
        assertEquals(expectedJson, outputInJson);
        verify(organisationService, times(1)).getAccessibleSiblings(Mockito.anyString(), Mockito.anySet());
    }

    @Test
    public void testGetOrgSubTypesForCompany() throws Exception {
        OrgHierarchy orgSubType1 = new OrgHierarchy();
        orgSubType1.setCompanyEntityId("BRPL");
        orgSubType1.setType("divisoin");
        OrgHierarchy orgSubType2 = new OrgHierarchy();
        orgSubType2.setCompanyEntityId("BRPL");
        orgSubType2.setType("zone");
        List<OrgHierarchy> compOrgSubTypes = new ArrayList<OrgHierarchy>(Arrays.asList(orgSubType1, orgSubType2));

        String URI = "/org/getAllSubTypes/BRPL";
        Mockito.when(organisationService.getOrgSubTypesForCompany(Mockito.anyString())).thenReturn(compOrgSubTypes);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.get(URI).accept(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        String expectedJson = this.mapToJson(compOrgSubTypes);
        String outputInJson = result.getResponse().getContentAsString();
        assertEquals(HttpStatus.OK.value(), result.getResponse().getStatus());
        assertEquals(expectedJson, outputInJson);
        verify(organisationService, times(1)).getOrgSubTypesForCompany(Mockito.anyString());
    }

    @Test
    public void testGetOrgPartsOfType() throws Exception {
        Organisation orgPart1 = new Organisation("z1", "zone", "z001", null, true);
        Organisation orgPart2 = new Organisation("z2", "zone", "z002", null, true);
        List<Organisation> orgPartForCompany = new ArrayList<Organisation>(Arrays.asList(orgPart1, orgPart2));

        String URI = "/org/getOrgPartsOfType/c001/zone";
        Mockito.when(organisationService.getOrgPartsForCompany(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(orgPartForCompany);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.get(URI).accept(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        String expectedJson = this.mapToJson(orgPartForCompany);
        String outputJson = result.getResponse().getContentAsString();
        assertEquals(HttpStatus.OK.value(), result.getResponse().getStatus());
        assertEquals(expectedJson, outputJson);
        verify(organisationService, times(1)).getOrgPartsForCompany(Mockito.anyString(), Mockito.anyString());
    }

    @Test
    public void testDelete() throws Exception {
        String URI = "/org/delete/z001";
        Mockito.doNothing().when(organisationService).deleteOrg(Mockito.anyString());
        RequestBuilder requestBuilder = MockMvcRequestBuilders.delete(URI).accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        assertEquals(HttpStatus.OK.value(), result.getResponse().getStatus());
        verify(organisationService, times(1)).deleteOrg(Mockito.anyString());
    }

    @Test
    public void testReassign() throws Exception {
        String URI = "/org/reassign";
        String accessToken = generateToken();
        Mockito.doNothing().when(organisationService).reassignEntity(Mockito.anyString(), Mockito.anyString(),
                Mockito.anyString());
        RequestBuilder requestBuilder = MockMvcRequestBuilders.post(URI).param("newParent", "d001")
                .param("entity", "z001").contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
                .header("Authorization", "Bearer " + accessToken).accept(MediaType.APPLICATION_JSON);
        ;
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        assertEquals(HttpStatus.OK.value(), result.getResponse().getStatus());
        verify(organisationService, times(1)).reassignEntity(Mockito.anyString(), Mockito.anyString(),
                Mockito.anyString());
    }

    @Test
    public void testModifyOrgPart() throws Exception {
        String accessToken = generateToken();
        Map<String, String> editProperties = new HashMap<String, String>();
        editProperties.put("p1", "property1");
        String editPropertiesInJson = this.mapToJson(editProperties);

        Mockito.doNothing().when(organisationService).checkParamsAndEditOrgPart(Mockito.anyString(),
                Mockito.anyString(), Mockito.anyMap());
        mockMvc2.perform(MockMvcRequestBuilders.post("/org/modifyOrgPart").param("company", "c101")
                .param("entityId", "d101").accept(MediaType.APPLICATION_JSON).content(editPropertiesInJson)
                .contentType(MediaType.APPLICATION_JSON).header("Authorization", "Bearer " + accessToken))
                .andExpect(status().isOk());
        verify(organisationService, times(1)).checkParamsAndEditOrgPart(Mockito.anyString(), Mockito.anyString(),
                Mockito.anyMap());
    }

    @Test
    public void testModifyOrgType() throws Exception {
        String accessToken = generateToken();
        EditPropertyType editPropertyType = new EditPropertyType();
        editPropertyType.setPropName("property1");
        editPropertyType.setNewPropertyType(new PropertyType("property2", true, true));
        List<EditPropertyType> editProperties = new ArrayList<>(Arrays.asList(editPropertyType));
        String editPropertiesInJson = this.mapToJson(editProperties);

        Mockito.doNothing().when(organisationService).editOrgType(Mockito.anyString(), Mockito.anyString(),
                Mockito.anyList());
        mockMvc2.perform(MockMvcRequestBuilders.post("/org/modifyOrgType").param("company", "c101")
                .param("orgTypeName", "divisoin").accept(MediaType.APPLICATION_JSON).content(editPropertiesInJson)
                .contentType(MediaType.APPLICATION_JSON).header("Authorization", "Bearer " + accessToken))
                .andExpect(status().isOk());
        verify(organisationService, times(1)).editOrgType(Mockito.anyString(), Mockito.anyString(), Mockito.anyList());
    }

    public String mapToJson(Object object) throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.writeValueAsString(object);
    }

    public String generateToken() {
        List<SimpleGrantedAuthority> authorities = new ArrayList<SimpleGrantedAuthority>(
                Arrays.asList(new SimpleGrantedAuthority("CREATE_USER"), new SimpleGrantedAuthority("SENSE_ADMIN"),
                        new SimpleGrantedAuthority("ORGPART_d101"), new SimpleGrantedAuthority("ORGPART_d102"),
                        new SimpleGrantedAuthority("ORGPART_z101"), new SimpleGrantedAuthority("ORGPART_z101")));
        JwtUserDetails userDetails = new JwtUserDetails("admin", "user1", "user1@gmail.com", "password", authorities,
                true, new Date(), "c102");
        final String token = jwtTokenUtil.generateToken(userDetails);
        return token;
    }
}

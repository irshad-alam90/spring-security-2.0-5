package com.sense.organisation.controller;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMultipartHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.request.RequestPostProcessor;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.multipart.MultipartFile;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sense.organisation.controller.BulkUploadContoller;
import com.sense.organisation.service.BulkUploadService;
import com.sense.sensemodel.model.organisation.Organisation;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.times;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;

@RunWith(SpringRunner.class)
public class BulkUploadControllerTest {

	private MockMvc mockMvc;

	@Mock
	BulkUploadService bulkUploadService;
	@InjectMocks
	BulkUploadContoller bulkUploadContoller;
	@Rule
	public TemporaryFolder tempFolder = new TemporaryFolder();

	@Before
	public void setUp() throws Exception {

		mockMvc = MockMvcBuilders.standaloneSetup(bulkUploadContoller).build();
	}

	@Test
	public void testBulkUpload() throws Exception {
		Organisation company = new Organisation("c1", "company", "c101", null, true);
		final File tempFile = tempFolder.newFile("test.xlsx");
		FileInputStream fis = new FileInputStream(tempFile);
		MockMultipartFile multipartFile = new MockMultipartFile("file", fis);
		Mockito.doNothing().when(bulkUploadService).bulkUpload(Mockito.any(Organisation.class),
				Mockito.any(MultipartFile.class));

		MockMultipartHttpServletRequestBuilder builder = MockMvcRequestBuilders.multipart("/org/bulk/upload");
		builder.with(new RequestPostProcessor() {
			@Override
			public MockHttpServletRequest postProcessRequest(MockHttpServletRequest request) {
				request.setMethod("PUT");
				return request;
			}
		});
		mockMvc.perform(builder.file(multipartFile).param("companyEntityId", "c101").param("companyName", "c1")
				.accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk());

		verify(bulkUploadService, times(1)).bulkUpload(Mockito.any(Organisation.class),
				Mockito.any(MultipartFile.class));
	}

	@Test
	public void testbulkAddUpdateProperties() throws Exception {
		final File tempFile = tempFolder.newFile("test.xlsx");
		FileInputStream fis = new FileInputStream(tempFile);
		MockMultipartFile multipartFile = new MockMultipartFile("file", fis);
		Mockito.doNothing().when(bulkUploadService).bulkUpdate(Mockito.anyString(), Mockito.any(MultipartFile.class));

		MockMultipartHttpServletRequestBuilder builder = MockMvcRequestBuilders.multipart("/org/bulk/update");
		builder.with(new RequestPostProcessor() {
			@Override
			public MockHttpServletRequest postProcessRequest(MockHttpServletRequest request) {
				request.setMethod("POST");
				return request;
			}
		});
		mockMvc.perform(builder.file(multipartFile).param("companyEntityId", "companyEntityId")
				.accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk());

		verify(bulkUploadService, times(1)).bulkUpdate(Mockito.anyString(), Mockito.any(MultipartFile.class));
	}

	@Test
	public void testGetSampleFile() throws Exception {
		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		Mockito.when(bulkUploadService.createSampleFile(Mockito.anyString())).thenReturn(byteArrayOutputStream);

		mockMvc.perform(MockMvcRequestBuilders.get("/org/bulk/getSample").param("companyEntityId", "c121")
				.accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk());

		verify(bulkUploadService, times(1)).createSampleFile(Mockito.anyString());
	}

	public String mapToJson(Object object) throws JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper();
		return objectMapper.writeValueAsString(object);
	}
}

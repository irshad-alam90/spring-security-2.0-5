package com.sense.organisation.service;

import static org.junit.Assert.assertEquals;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.sense.sensemodel.model.organisation.OrgHierarchy;
import com.sense.sensemodel.model.organisation.Organisation;
import com.sense.sensemodel.repository.organisation.OrgHierarchyRepository;
import com.sense.sensemodel.repository.organisation.OrganisationRepository;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@Transactional
public class BulkUploadServiceTest {

	@Autowired
	BulkUploadService bulkUploadService;
	
	@Autowired
	OrganisationRepository organisationRepository;
	
	@Autowired
	OrgHierarchyRepository orgHierarchyRepository;
	
	@Rule
	public TemporaryFolder tempFolder = new TemporaryFolder();

	DataFormatter formatter = new DataFormatter();
	
	@Before
	public void setUp() {
	    Organisation company = new Organisation("c1", "company", "c001", null, true);
	    organisationRepository.save(company);
	}

	/* Bulk upload */
	@Test(expected = RuntimeException.class)
	public void testBulkUploadIfSheetBlank() throws Exception {
		final File file = tempFolder.newFile("test.xlsx");

		// Blank workbook
		XSSFWorkbook workbook = new XSSFWorkbook();
		// Create a blank sheet
		XSSFSheet sheet = workbook.createSheet("blank sheet");
		FileOutputStream fout = new FileOutputStream(file);
		workbook.write(fout);

		Organisation company = new Organisation("c11", "company", "c0011", null, true);
		FileInputStream fis = new FileInputStream(file);
		MockMultipartFile uploadfile = new MockMultipartFile("file", fis);

		bulkUploadService.bulkUpload(company, uploadfile);
	}
	
	@Test(expected = RuntimeException.class)
    public void testBulkUploadIfOrgTypeNotFound() throws Exception {
        Organisation company = new Organisation("c1", "company", "c001", null, true);
        
        final File file = tempFolder.newFile("upload_org_data.xlsx");
        // Blank workbook
        XSSFWorkbook workbook = new XSSFWorkbook();

        // Create a blank sheet
        XSSFSheet sheet = workbook.createSheet("upload org data");

        // This data needs to be written (Object[])
        Map<String, Object[]> data = new TreeMap<String, Object[]>();
        data.put("1",
                new Object[] { "circle_code", "circle", "#", "Div_code", "division", "Division_Short_name", "#",
                        "ZONE_CD", "zone", "#", "SAP_FUNC_CD", "substation", "sap_func_last_six_alphabet",
                        "SAP_FUNC_DET", "LANDMARKS" });
        data.put("2",
                new Object[] { "South-3", "South-3", "#", "2510", "ALAKNANDA", "ALN", "#", "ALNZN03", "GK 2", "#",
                        "1S-DL-RP-STC-DALN-2001-GK2116", "", "GK2116", "MKT NO 1 C R  PARK   PACKAGE S/STN",
                        "MARKET NO-1  CR PARK" });
        data.put("3",
                new Object[] { "South-3", "South-3", "#", "2510", "ALAKNANDA", "ALN", "#", "ALNZN01",
                        "DDA FLATS KALKAJI", "#", "1S-DL-RP-STC-DALN-2002-OKH040", "", "OKH040",
                        "A-14 KALKA JI EXT.:ID", "FLAT NO-43,48 POCKET A-14, KALKAJI EXTN." });

        // Iterate over data and write to sheet
        Set<String> keyset = data.keySet();
        int rownum = 0;
        for (String key : keyset) {
            // this creates a new row in the sheet
            Row row = sheet.createRow(rownum++);
            Object[] objArr = data.get(key);
            int cellnum = 0;
            for (Object obj : objArr) {
                // this line creates a cell in the next column of that row
                Cell cell = row.createCell(cellnum++);
                if (obj instanceof String)
                    cell.setCellValue((String) obj);
                else if (obj instanceof Integer)
                    cell.setCellValue((Integer) obj);
            }
        }
        try {
            FileOutputStream out = new FileOutputStream(file);
            workbook.write(out);
            out.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        FileInputStream fis = new FileInputStream(file);
        MockMultipartFile uploadfile = new MockMultipartFile("file", fis);

        bulkUploadService.bulkUpload(company, uploadfile);
    }

	@Test
	public void testBulkUploadSuccessfully() throws Exception {
		Organisation company = new Organisation("c1", "company", "c001", null, true);
		
		OrgHierarchy companyType = new OrgHierarchy("c001", "company", null);
        orgHierarchyRepository.save(companyType);
		final File file = tempFolder.newFile("upload_org_data.xlsx");
		// Blank workbook
		XSSFWorkbook workbook = new XSSFWorkbook();

		// Create a blank sheet
		XSSFSheet sheet = workbook.createSheet("upload org data");

		// This data needs to be written (Object[])
		Map<String, Object[]> data = new TreeMap<String, Object[]>();
		data.put("1",
				new Object[] { "circle_code", "circle", "#", "Div_code", "division", "Division_Short_name", "#",
						"ZONE_CD", "zone", "#", "SAP_FUNC_CD", "substation", "sap_func_last_six_alphabet",
						"SAP_FUNC_DET", "LANDMARKS" });
		data.put("2",
				new Object[] { "South-3", "South-3", "#", "2510", "ALAKNANDA", "ALN", "#", "ALNZN03", "GK 2", "#",
						"1S-DL-RP-STC-DALN-2001-GK2116", "", "GK2116", "MKT NO 1 C R  PARK   PACKAGE S/STN",
						"MARKET NO-1  CR PARK" });
		data.put("3",
				new Object[] { "South-3", "South-3", "#", "2510", "ALAKNANDA", "ALN", "#", "ALNZN01",
						"DDA FLATS KALKAJI", "#", "1S-DL-RP-STC-DALN-2002-OKH040", "", "OKH040",
						"A-14 KALKA JI EXT.:ID", "FLAT NO-43,48 POCKET A-14, KALKAJI EXTN." });

		// Iterate over data and write to sheet
		Set<String> keyset = data.keySet();
		int rownum = 0;
		for (String key : keyset) {
			// this creates a new row in the sheet
			Row row = sheet.createRow(rownum++);
			Object[] objArr = data.get(key);
			int cellnum = 0;
			for (Object obj : objArr) {
				// this line creates a cell in the next column of that row
				Cell cell = row.createCell(cellnum++);
				if (obj instanceof String)
					cell.setCellValue((String) obj);
				else if (obj instanceof Integer)
					cell.setCellValue((Integer) obj);
			}
		}
		try {
			FileOutputStream out = new FileOutputStream(file);
			workbook.write(out);
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		FileInputStream fis = new FileInputStream(file);
		MockMultipartFile uploadfile = new MockMultipartFile("file", fis);

		bulkUploadService.bulkUpload(company, uploadfile);

		// test for company's child
		Organisation parent = organisationRepository.findByEntityIdAndActiveInd(company.getEntityId(), true)
				.orElse(null);
		Organisation companyChild = parent.getActiveChildren().stream().filter(ac -> ac.getEntityId().equals("South-3"))
				.findAny().orElseThrow(() -> new RuntimeException());
		assertEquals("South-3", companyChild.getName());
		assertEquals("circle", companyChild.getType());

		// test for circle's child
		Organisation circle = organisationRepository.findByEntityIdAndActiveInd(companyChild.getEntityId(), true)
				.orElseThrow(() -> new RuntimeException());
		Organisation circleChild = circle.getActiveChildren().stream().filter(ac -> ac.getEntityId().equals("2510"))
				.findAny().orElseThrow(() -> new RuntimeException());
		assertEquals("ALAKNANDA", circleChild.getName());
		assertEquals("division", circleChild.getType());

		// test for division's child
		Organisation division = organisationRepository.findByEntityIdAndActiveInd(circleChild.getEntityId(), true)
				.orElseThrow(() -> new RuntimeException());
		Organisation divisionChild = division.getActiveChildren().stream()
				.filter(ac -> ac.getEntityId().equals("ALNZN03")).findAny().orElseThrow(() -> new RuntimeException());
		assertEquals("GK 2", divisionChild.getName());
		assertEquals("zone", divisionChild.getType());

		// test for zone's child
		Organisation zone = organisationRepository.findByEntityIdAndActiveInd(divisionChild.getEntityId(), true)
				.orElseThrow(() -> new RuntimeException());
		;
		Organisation zoneChild = zone.getActiveChildren().stream()
				.filter(ac -> ac.getEntityId().equals("1S-DL-RP-STC-DALN-2001-GK2116")).findAny()
				.orElseThrow(() -> new RuntimeException());

		Map<String, String> properties = zoneChild.getProperties();
		String property = properties.entrySet().stream().filter(p -> p.getValue().equals("GK2116"))
				.map(Map.Entry::getValue).findAny().orElseThrow(() -> new RuntimeException());
		assertEquals("GK2116", property);

	}

	/* Bulk update */
	@Test(expected = RuntimeException.class)
	public void testBulkUpdateIfCompanyNotExist() throws Exception {
		String companyEntityId = "c00333";
		final File file = tempFolder.newFile("test.xlsx");
		FileInputStream fis = new FileInputStream(file);
		MockMultipartFile uploadfile = new MockMultipartFile("file", fis);
		bulkUploadService.bulkUpdate(companyEntityId, uploadfile);
	}

	@Test(expected = RuntimeException.class)
	public void testBulkUpdateIfSheetBlank() throws Exception {
		String companyEntityId = "c001";
		Organisation organisation = new Organisation("c1", "company", "c001", null, true);
		organisationRepository.save(organisation);
		final File file = tempFolder.newFile("test.xlsx");
		// Blank workbook
		XSSFWorkbook workbook = new XSSFWorkbook();
		// Create a blank sheet
		XSSFSheet sheet = workbook.createSheet("blank sheet");
		FileOutputStream fout = new FileOutputStream(file);
		workbook.write(fout);
		FileInputStream fis = new FileInputStream(file);
		MockMultipartFile uploadfile = new MockMultipartFile("file", fis);

		bulkUploadService.bulkUpdate(companyEntityId, uploadfile);
	}

	@Test(expected = RuntimeException.class)
	public void testBulkUpdateIfNoEntityFound() throws Exception {
		String companyEntityId = "c001";
		final File file = tempFolder.newFile("update_org_data.xlsx");
		Organisation organisation = new Organisation("c1", "company", "c001", null, true);
		organisationRepository.save(organisation);

		OrgHierarchy compType = new OrgHierarchy("c001", "company", null);
		orgHierarchyRepository.save(compType);
		OrgHierarchy circleType = new OrgHierarchy("c001", "circle", null);
		circleType.setParentOrgType(compType);
		orgHierarchyRepository.save(circleType);
		OrgHierarchy substationType = new OrgHierarchy("c001", "substation", null);
		substationType.setParentOrgType(circleType);
		orgHierarchyRepository.save(substationType);
		// Blank workbook
		XSSFWorkbook workbook = new XSSFWorkbook();

		// Create a blank sheet
		XSSFSheet sheet = workbook.createSheet("upload org data");

		// This data needs to be written (Object[])
		Map<String, Object[]> data = new TreeMap<String, Object[]>();
		data.put("1", new Object[] { "SAP_FUNC_CD", "Prop Name", "Prop Value" });
		data.put("2", new Object[] { "1S-DL-RP-STC-DALN-2001-GK2116111", "LONGITUDE", "77.248929" });

		// Iterate over data and write to sheet
		Set<String> keyset = data.keySet();
		int rownum = 0;
		for (String key : keyset) {
			// this creates a new row in the sheet
			Row row = sheet.createRow(rownum++);
			Object[] objArr = data.get(key);
			int cellnum = 0;
			for (Object obj : objArr) {
				// this line creates a cell in the next column of that row
				Cell cell = row.createCell(cellnum++);
				if (obj instanceof String)
					cell.setCellValue((String) obj);
				else if (obj instanceof Integer)
					cell.setCellValue((Integer) obj);
			}
		}
		try {
			FileOutputStream out = new FileOutputStream(file);
			workbook.write(out);
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		FileInputStream fis = new FileInputStream(file);
		MockMultipartFile uploadfile = new MockMultipartFile("file", fis);

		bulkUploadService.bulkUpdate(companyEntityId, uploadfile);
	}

	@Test(expected = RuntimeException.class)
    public void testBulkUpdateIfOrgTypeCompanyNotFound() throws Exception {
        final File file = tempFolder.newFile("update_org_data.xlsx");
        Organisation organisation = new Organisation("c1", "company", "c001", null, true);
        organisationRepository.save(organisation);

        Map<String, String> properties = new HashMap<String, String>();
        properties.put("LONGITUDE", "77.248929");
        Organisation childOrg = new Organisation("substation", "substation", "1S-DL-RP-STC-DALN-2001-GK2116",
                properties, true);
        organisationRepository.save(childOrg);

        // Blank workbook
        XSSFWorkbook workbook = new XSSFWorkbook();

        // Create a blank sheet
        XSSFSheet sheet = workbook.createSheet("upload org data");

        // This data needs to be written (Object[])
        Map<String, Object[]> data = new TreeMap<String, Object[]>();
        data.put("1", new Object[] { "SAP_FUNC_CD", "Prop Name", "Prop Value" });
        data.put("2",
                new Object[] { "1S-DL-RP-STC-DALN-2001-GK2116", "LONGITUDE", "77.248929", "LATITTUDE", "28.5400665" });

        // Iterate over data and write to sheet
        Set<String> keyset = data.keySet();
        int rownum = 0;
        for (String key : keyset) {
            // this creates a new row in the sheet
            Row row = sheet.createRow(rownum++);
            Object[] objArr = data.get(key);
            int cellnum = 0;
            for (Object obj : objArr) {
                // this line creates a cell in the next column of that row
                Cell cell = row.createCell(cellnum++);
                if (obj instanceof String)
                    cell.setCellValue((String) obj);
                else if (obj instanceof Integer)
                    cell.setCellValue((Integer) obj);
            }
        }
        try {
            FileOutputStream out = new FileOutputStream(file);
            workbook.write(out);
            out.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        FileInputStream fis = new FileInputStream(file);
        MockMultipartFile uploadfile = new MockMultipartFile("file", fis);
        String companyEntityId = "c001";

        bulkUploadService.bulkUpdate(companyEntityId, uploadfile);
    }
	
	@Test(expected = RuntimeException.class)
	public void testBulkUpdateIfOrgHierarchyNotFound() throws Exception {
		final File file = tempFolder.newFile("update_org_data.xlsx");
		Organisation organisation = new Organisation("c1", "company", "c001", null, true);
		organisationRepository.save(organisation);

		OrgHierarchy compType = new OrgHierarchy("c001", "company", null);
		orgHierarchyRepository.save(compType);

		Map<String, String> properties = new HashMap<String, String>();
		properties.put("LONGITUDE", "77.248929");
		Organisation childOrg = new Organisation("substation", "substation", "1S-DL-RP-STC-DALN-2001-GK2116",
				properties, true);
		organisationRepository.save(childOrg);

		// Blank workbook
		XSSFWorkbook workbook = new XSSFWorkbook();

		// Create a blank sheet
		XSSFSheet sheet = workbook.createSheet("upload org data");

		// This data needs to be written (Object[])
		Map<String, Object[]> data = new TreeMap<String, Object[]>();
		data.put("1", new Object[] { "SAP_FUNC_CD", "Prop Name", "Prop Value" });
		data.put("2",
				new Object[] { "1S-DL-RP-STC-DALN-2001-GK2116", "LONGITUDE", "77.248929", "LATITTUDE", "28.5400665" });

		// Iterate over data and write to sheet
		Set<String> keyset = data.keySet();
		int rownum = 0;
		for (String key : keyset) {
			// this creates a new row in the sheet
			Row row = sheet.createRow(rownum++);
			Object[] objArr = data.get(key);
			int cellnum = 0;
			for (Object obj : objArr) {
				// this line creates a cell in the next column of that row
				Cell cell = row.createCell(cellnum++);
				if (obj instanceof String)
					cell.setCellValue((String) obj);
				else if (obj instanceof Integer)
					cell.setCellValue((Integer) obj);
			}
		}
		try {
			FileOutputStream out = new FileOutputStream(file);
			workbook.write(out);
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		FileInputStream fis = new FileInputStream(file);
		MockMultipartFile uploadfile = new MockMultipartFile("file", fis);
		String companyEntityId = "c001";

		bulkUploadService.bulkUpdate(companyEntityId, uploadfile);
	}

	@Test
	public void testBulkUpdateSuccessfully() throws Exception {
		String companyEntityId = "c0011";
		final File file = tempFolder.newFile("update_org_data.xlsx");

		Map<String, String> properties = new HashMap<String, String>();
		properties.put("prop1", "p1");
		properties.put("prop2", "p2");
		Organisation parentOrg = new Organisation("c1", "company", "c0011", null, true);
		Organisation childOrg = new Organisation("substation", "substation", "1S-DL-RP-STC-DALN-2001-GK2116",
				properties, true);

		childOrg.setParent(parentOrg);
		organisationRepository.save(childOrg);

		OrgHierarchy compType = new OrgHierarchy("c0011", "company", null);
		OrgHierarchy substationType = new OrgHierarchy("c0011", "substation", null);
		substationType.setParentOrgType(compType);
		orgHierarchyRepository.save(substationType);

		// Blank workbook
		XSSFWorkbook workbook = new XSSFWorkbook();

		// Create a blank sheet
		XSSFSheet sheet = workbook.createSheet("update org data");

		// This data needs to be written (Object[])
		Map<String, Object[]> data = new TreeMap<String, Object[]>();
		data.put("1", new Object[] { "SAP_FUNC_CD", "Prop Name", "Prop Value" });
		data.put("2", new Object[] { "1S-DL-RP-STC-DALN-2001-GK2116", "LONGITUDE", "77.2489295" });

		// Iterate over data and write to sheet
		Set<String> keyset = data.keySet();
		int rownum = 0;
		for (String key : keyset) {
			// this creates a new row in the sheet
			Row row = sheet.createRow(rownum++);
			Object[] objArr = data.get(key);
			int cellnum = 0;
			for (Object obj : objArr) {
				// this line creates a cell in the next column of that row
				Cell cell = row.createCell(cellnum++);
				if (obj instanceof String)
					cell.setCellValue((String) obj);
				else if (obj instanceof Integer)
					cell.setCellValue((Integer) obj);
			}
		}
		try {
			FileOutputStream out = new FileOutputStream(file);
			workbook.write(out);
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		FileInputStream fis = new FileInputStream(file);
		MockMultipartFile uploadfile = new MockMultipartFile("file", fis);

		bulkUploadService.bulkUpdate(companyEntityId, uploadfile);

		Organisation zone = organisationRepository.findByEntityIdAndActiveInd(parentOrg.getEntityId(), true)
				.orElseThrow(() -> new RuntimeException());
		;
		Organisation zoneChild = zone.getActiveChildren().stream()
				.filter(ac -> ac.getEntityId().equals("1S-DL-RP-STC-DALN-2001-GK2116")).findAny()
				.orElseThrow(() -> new RuntimeException());
		assertEquals("substation", zoneChild.getName());
		assertEquals("substation", zoneChild.getType());

		Map<String, String> getProperties = zoneChild.getProperties();
		String property = getProperties.entrySet().stream().filter(p -> p.getKey().equals("LONGITUDE"))
				.map(Map.Entry::getValue).findAny().orElseThrow(() -> new RuntimeException());
		assertEquals("77.2489295", property);
	}
	
	@Test(expected = RuntimeException.class)
    public void createSampleFileIfOrgTypeNotFound() throws Exception {
        String companyEntityId = "c001";
        bulkUploadService.createSampleFile(companyEntityId);
    }

	@Test
	public void createSampleFile() throws Exception {
		String companyEntityId = "c001";
		OrgHierarchy companyType = new OrgHierarchy("c001", "company", null);
        orgHierarchyRepository.save(companyType);
        uploadbulkFile();
		ByteArrayOutputStream bos = bulkUploadService.createSampleFile(companyEntityId);
		byte[] bytes = bos.toByteArray();
		File file = tempFolder.newFile("sampleFile.xlsx");
		FileOutputStream fos = new FileOutputStream(file);
		fos.write(bytes);
		fos.flush();
		fos.close();

		FileInputStream sampleFile = new FileInputStream(file);
		XSSFWorkbook workbook = new XSSFWorkbook(sampleFile);
		XSSFSheet sheet = workbook.getSheetAt(0);
		sheet.getRow(0);
		Iterator<Row> rowIterator = sheet.iterator();
		List<String> list = new ArrayList<>();
		while (rowIterator.hasNext()) {

			Row row = rowIterator.next();

			Iterator<Cell> cellIterator = row.cellIterator();

			while (cellIterator.hasNext()) {
				Cell entityIdCell = cellIterator.next();
				String entityId = formatter.formatCellValue(entityIdCell);
				Cell entityNameCell = cellIterator.next();
				String entityName = formatter.formatCellValue(entityNameCell);
				list.add(entityId);
				list.add(entityName);
			}
		}
		String entity_no = list.stream().filter(l -> l.equals("circle_no")).findAny()
				.orElseThrow(() -> new RuntimeException());
		assertEquals("circle_no", entity_no);
		String entityName = list.stream().filter(l -> l.equals("circle_name")).findAny()
				.orElseThrow(() -> new RuntimeException());
		assertEquals("circle_name", entityName);
	}

	private void uploadbulkFile() throws Exception {
		Organisation company = new Organisation("c1", "company", "c001", null, true);
		final File file = tempFolder.newFile("upload_org_data.xlsx");
		// Blank workbook
		XSSFWorkbook workbook = new XSSFWorkbook();

		// Create a blank sheet
		XSSFSheet sheet = workbook.createSheet("upload org data");

		// This data needs to be written (Object[])
		Map<String, Object[]> data = new TreeMap<String, Object[]>();
		data.put("1", new Object[] { "circle", "circle", "#", "division", "division", "Division_Short_name", "#" });
		data.put("2", new Object[] { "South-3", "South-3", "#", "2510", "ALAKNANDA", "ALN", "#" });

		// Iterate over data and write to sheet
		Set<String> keyset = data.keySet();
		int rownum = 0;
		for (String key : keyset) {
			// this creates a new row in the sheet
			Row row = sheet.createRow(rownum++);
			Object[] objArr = data.get(key);
			int cellnum = 0;
			for (Object obj : objArr) {
				// this line creates a cell in the next column of that row
				Cell cell = row.createCell(cellnum++);
				if (obj instanceof String)
					cell.setCellValue((String) obj);
				else if (obj instanceof Integer)
					cell.setCellValue((Integer) obj);
			}
		}
		try {
			FileOutputStream out = new FileOutputStream(file);
			workbook.write(out);
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		FileInputStream fis = new FileInputStream(file);
		MockMultipartFile uploadfile = new MockMultipartFile("file", fis);

		bulkUploadService.bulkUpload(company, uploadfile);
	}

}

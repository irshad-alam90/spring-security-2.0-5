package com.sense.users.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.sense.sensemodel.model.assets.Asset;
import com.sense.sensemodel.model.assets.AssetType;
import com.sense.sensemodel.model.organisation.Organisation;
import com.sense.sensemodel.model.users.AccessRight;
import com.sense.sensemodel.model.users.AccessType;
import com.sense.sensemodel.model.users.Department;
import com.sense.sensemodel.model.users.Role;
import com.sense.sensemodel.model.users.User;
import com.sense.sensemodel.model.users.UserAccess;
import com.sense.sensemodel.repository.assets.AssetRepository;
import com.sense.sensemodel.repository.assets.AssetTypeRepository;
import com.sense.sensemodel.repository.organisation.OrganisationRepository;
import com.sense.sensemodel.repository.users.AccessRightRepository;
import com.sense.sensemodel.repository.users.DepartmentRepository;
import com.sense.sensemodel.repository.users.RoleRepository;
import com.sense.sensemodel.repository.users.UserRepository;
import com.sense.users.model.ModifyDepartmentRequest;
import com.sense.users.model.UpdateUserRequest;
import com.sense.users.model.ModifyDepartmentRequest.RequestType;
import com.sense.users.model.UpdateUserRequest.DepartmentRoleRequest;
import com.sense.users.model.UpdateUserRequest.UpdateDepMode;
import com.sense.users.model.UpdateUserRequest.UpdateRightsMode;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@Transactional
public class UserServiceTest {

    @Autowired
    private UserService userService;

    @SpyBean
    private UserService userServiceSpyBean;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private DepartmentRepository departmentRepository;

    @Autowired
    private OrganisationRepository organisationRepository;

    @Autowired
    private AccessRightRepository accessRightRepository;

    @Autowired
    private AssetTypeRepository assetTypeRepository;

    @Autowired
    private AssetRepository assetRepository;

    @Test(expected = RuntimeException.class)
    public void testCreateAdminDepartmentAndRoleIfDepartmentExist() throws Exception {
        String company = "c101";
        String companyAdminEmail = "abc@gmail.com";
        Department department = new Department("ADMIN", "c101", null, null);
        departmentRepository.save(department);
        userService.createAdminDepartmentAndRoleAndUser(company, companyAdminEmail);
    }

    @Test(expected = RuntimeException.class)
    public void createAdminDepartmentAndRoleIfAccessRightNotFound() throws Exception {
        String company = "c101";
        String companyAdminEmail = "abc@gmail.com";
        userService.createAdminDepartmentAndRoleAndUser(company, companyAdminEmail);
    }

    @Test(expected = RuntimeException.class)
    public void createAdminDepartmentAndRoleIfUserAlreadyExist() throws Exception {
        String company = "c101";
        String companyAdminEmail = "abc@gmail.com";
        AccessRight accessRight = new AccessRight(AccessType.CREATE_USER.name());
        accessRightRepository.save(accessRight);
        AccessRight adminAccessRight = new AccessRight(AccessType.ADMIN_LOGIN.name());
        accessRightRepository.save(adminAccessRight);

        User user = new User(company + "_admin", company + "_admin", companyAdminEmail, "admin", "Admin", null, null,
                new HashSet<String>(Arrays.asList(company)), "c101");
        userRepository.save(user);
        userService.createAdminDepartmentAndRoleAndUser(company, companyAdminEmail);
    }

    @Test
    public void createAdminDepartmentAndRoleSuccessfully() throws Exception {
        String company = "c101";
        String companyAdminEmail = "admin@gmail.com";
        AccessRight accessRight1 = new AccessRight();
        accessRight1.setAccessType("CREATE_USER");
        accessRight1.setCompany("c101");
        AccessRight accessRight2 = new AccessRight();
        accessRight2.setAccessType("ADMIN_LOGIN");
        accessRight2.setCompany("c101");
        AccessRight accessRight3 = new AccessRight();
        accessRight3.setAccessType("ASSET_ADMIN");
        accessRight3.setCompany("c101");
        AccessRight accessRight4 = new AccessRight();
        accessRight4.setAccessType("ORG_ADMIN");
        accessRight4.setCompany("c101");

        Set<AccessRight> accessRights = new HashSet<>(
                Arrays.asList(accessRight1, accessRight2, accessRight3, accessRight4));
        accessRightRepository.saveAll(accessRights);

        Organisation organisation = new Organisation("c1", "company", "c101", null, true);
        organisationRepository.save(organisation);

        Mockito.doNothing().when(userServiceSpyBean).sendUserCreationEmail(Mockito.anyString());
        userService.createAdminDepartmentAndRoleAndUser(company, companyAdminEmail);
        Set<Department> departments = departmentRepository.findByCompanyIdAndActiveInd(company, true);
        Department department = departments.stream().filter(d -> d.getCompanyId().equals(company)).findAny()
                .orElseThrow(() -> new RuntimeException());
        assertEquals("ADMIN", department.getName());
        assertEquals("Admin_Role", department.getRootRole().getName());
        User user = userRepository.findByUserIdAndEnabled(company + "_admin", true).orElse(null);
        assertEquals(companyAdminEmail, user.getEmail());
    }

    @Test(expected = RuntimeException.class)
    public void testAddDepartmentToCompanyIfAssetTypeNotFound() {
        String departmentName = "dep1";
        String company = "c101";
        Set<String> assetTypeNames = new HashSet<>();
        assetTypeNames.add("assetType1");

        userService.addDepartmentToCompany(departmentName, company, assetTypeNames);
    }

    @Test
    public void testAddDepartmentToCompanySuccessfully() {
        String departmentName = "dep1";
        String company = "c101";
        Set<String> assetTypeNames = new HashSet<>();
        assetTypeNames.add("assetType1");

        AssetType assetType = new AssetType();
        assetType.setType("assetType1");
        assetType.setCompany("c101");
        assetTypeRepository.save(assetType);
        userService.addDepartmentToCompany(departmentName, company, assetTypeNames);

        Set<Department> departments = departmentRepository.findByCompanyIdAndActiveInd(company, true);
        Department department = departments.stream().filter(d -> d.getName().equals(departmentName)).findAny()
                .orElseThrow(() -> new RuntimeException());
        assertEquals(departmentName, department.getName());
        AssetType astType = department.getAccessibleAssetTypes().stream()
                .filter(at -> at.getType().equals(assetType.getType())).findAny()
                .orElseThrow(() -> new RuntimeException());
        assertEquals(assetType.getType(), astType.getType());
    }

    @Test
    public void testGetDepartmentsForCompany() {
        String company = "c101";
        getSaveDepartment();

        Set<Department> departments = userService.getDepartmentsForCompany(company);
        Department dep = departments.stream().filter(d -> d.getCode().equals("dep101")).findAny()
                .orElseThrow(() -> new RuntimeException());
        assertEquals("dep1", dep.getName());
        Set<Role> roles = dep.getSubRolesList();
        assertEquals(3, roles.size());
    }

    @Test(expected = RuntimeException.class)
    public void testModifyDepartmentIfDeprtmentNotFound() {
        ModifyDepartmentRequest mdRequest = new ModifyDepartmentRequest();
        mdRequest.setDepartmentCode("dep102");
        userService.modifyDepartment(mdRequest);
    }

    @Test(expected = RuntimeException.class)
    public void testModifyDepartmentIfAssetTypeNotFound() {
        getSaveDepartment();
        ModifyDepartmentRequest mdRequest = new ModifyDepartmentRequest();
        mdRequest.setDepartmentCode("dep101");
        Map<String, RequestType> modifyAssetsTypes = new HashMap<>();
        modifyAssetsTypes.put("assetType2", RequestType.ADD);
        mdRequest.setModifyAssetsTypes(modifyAssetsTypes);
        userService.modifyDepartment(mdRequest);
    }

    @Test
    public void testModifyDepartmentIfRequestTypeAdd() {
        getSaveDepartment();
        ModifyDepartmentRequest mdRequest = new ModifyDepartmentRequest();
        mdRequest.setDepartmentCode("dep101");
        Map<String, RequestType> modifyAssetsTypes = new HashMap<>();
        modifyAssetsTypes.put("assetType2", RequestType.ADD);
        mdRequest.setModifyAssetsTypes(modifyAssetsTypes);

        AssetType at = new AssetType();
        at.setType("assetType2");
        at.setCompany("c101");
        assetTypeRepository.save(at);

        userService.modifyDepartment(mdRequest);
        Department dep = departmentRepository.findByCodeAndActiveInd("dep101", true)
                .orElseThrow(() -> new RuntimeException());
        boolean astType = dep.getAccessibleAssetTypes().stream().anyMatch(a -> a.getType().equals("assetType2"));
        assertTrue(astType);
    }

    @Test
    public void testModifyDepartmentIfRequestTypeDelete() {
        getSaveDepartment();
        ModifyDepartmentRequest mdRequest = new ModifyDepartmentRequest();
        mdRequest.setDepartmentCode("dep101");
        Map<String, RequestType> modifyAssetsTypes = new HashMap<>();
        modifyAssetsTypes.put("assetTyp2", RequestType.DELETE);
        mdRequest.setModifyAssetsTypes(modifyAssetsTypes);

        AssetType at = new AssetType();
        at.setType("assetType2");
        at.setCompany("c101");
        assetTypeRepository.save(at);

        userService.modifyDepartment(mdRequest);
        Department dep = departmentRepository.findByCodeAndActiveInd("dep101", true)
                .orElseThrow(() -> new RuntimeException());
        boolean astType = dep.getAccessibleAssetTypes().stream().anyMatch(a -> a.getType().equals("assetType2"));
        assertFalse(astType);
    }

    @Test
    public void testGetDepartmentsByCode() {
        getSaveDepartment();
        Set<String> depCodes = new HashSet<>();
        depCodes.add("dep101");
        Set<Department> departmnts = userService.getDepartmentsByCode(depCodes);
        Department department = departmnts.stream().filter(d -> d.getCode().equals("dep101")).findAny()
                .orElseThrow(() -> new RuntimeException());
        assertEquals("dep1", department.getName());
    }

    @Test(expected = RuntimeException.class)
    public void testDeleteDepartmentIfDepartmentNotFound() {
        String departmentCode = "dep102";
        userService.deleteDepartment(departmentCode);
    }

    @Test
    @Transactional(propagation = Propagation.NEVER)
    public void testDeleteDepartmentSuccessfully() {
        String departmentCode = "dep101";
        AssetType assetType = new AssetType();
        assetType.setType("assetType11");
        assetType.setCompany("c101");
        Department department = new Department("dep1", "c101", null, new HashSet<>(Arrays.asList(assetType)));
        department.setCode("dep101");
        department.setActiveInd(true);
        departmentRepository.save(department);

        Map<String, String> departmentRoles = new HashMap<>();
        departmentRoles.put("dep101", "r101");
        Set<String> orgParts = new HashSet<>();
        orgParts.add("d101");
        User user = new User("user111", "user1", "user1@gmail.com", "123", "SE", departmentRoles, null, orgParts,
                "c101");
        userRepository.save(user);

        userService.deleteDepartment(departmentCode);
        Set<Department> departments = departmentRepository.findByCompanyIdAndActiveInd("c101", true);
        boolean dep = departments.stream().anyMatch(d -> d.getCode().equals("dep101"));
        assertFalse(dep);
        User u = userRepository.findByUserIdAndEnabled("user111", true).orElse(null);
        boolean depRole = u.getDepartmentRoles().entrySet().stream().anyMatch(r -> r.getKey().equals(departmentCode));
        assertFalse(depRole);
    }

    @Test(expected = RuntimeException.class)
    public void testAddRoleIfParentRoleNotFound() {
        String parentDepRoleId = "r101";
        String company = "c101";
        Role newRole = new Role();
        userService.addRole(newRole, parentDepRoleId, company);
    }

    @Test(expected = RuntimeException.class)
    public void testAddRoleIfSubRoleNotSubsetOfParent() {
        String parentDepRoleId = "r101";
        String company = "c101";
        Role parent = new Role("Head", null, new HashSet<>(Arrays.asList(new AccessRight("CREATE_USER"))));
        parent.setCode("r101");
        roleRepository.save(parent);

        Set<AccessRight> accessRights = new HashSet<>();
        accessRights.addAll(Arrays.asList(new AccessRight("CREATE_USER"), new AccessRight("ORG_READ")));
        Role newRole = new Role("Manager", null, accessRights);
        newRole.setCode("r102");
        userService.addRole(newRole, parentDepRoleId, company);
    }

    @Test
    public void testAddRoleSuccessfully() {
        String parentDepRoleId = "r101";
        String company = "c101";
        Set<AccessRight> accessRights = new HashSet<>();
        accessRights.addAll(Arrays.asList(new AccessRight("CREATE_USER"), new AccessRight("ORG_READ")));
        Role parent = new Role("Head", null, accessRights);
        parent.setCode("r101");
        roleRepository.save(parent);

        Role newRole = new Role("Manager", null, new HashSet<>(Arrays.asList(new AccessRight("CREATE_USER"))));
        Role role = userService.addRole(newRole, parentDepRoleId, company);
        assertEquals(newRole.getName(), role.getName());
    }

    @Test(expected = RuntimeException.class)
    public void testDeleteRoleIfRootDepartmentNotFound() {
        String roleCode = "r102";
        Role rootRole = new Role("Admin_Role", null, new HashSet<>(Arrays.asList(new AccessRight("CREATE_USER"))));
        rootRole.setCode("r102");
        roleRepository.save(rootRole);
        userService.deleteRole(roleCode);
    }

    @Test
    public void tesGetRolesByCode() {
        getSaveRole();
        Set<String> roleCodes = new HashSet<>();
        roleCodes.add("r101");
        roleCodes.add("r111");
        Set<Role> roles = userService.getRolesByCode(roleCodes);
        Role role1 = roles.stream().filter(r1 -> r1.getCode().equals("r101")).findAny()
                .orElseThrow(() -> new RuntimeException());
        assertEquals("Manager", role1.getName());
        Role role2 = roles.stream().filter(r1 -> r1.getCode().equals("r111")).findAny()
                .orElseThrow(() -> new RuntimeException());
        assertEquals("Admin", role2.getName());
    }

    @Test
    @Transactional(propagation = Propagation.NEVER)
    public void testDeleteRoleSuccessfully() {
        String roleCode = "r101";
        Role rootRole = new Role("Admin_Role", null, new HashSet<>(Arrays.asList(new AccessRight("CREATE_USER"))));
        rootRole.setCode("r101");
        rootRole.setActiveInd(true);

        Role subRole = new Role("Manager", rootRole, new HashSet<>(Arrays.asList(new AccessRight("ORG_READ"))));
        subRole.setCode("sr101");
        subRole.setActiveInd(true);
        rootRole.setChildren(new HashSet<>(Arrays.asList(subRole)));
        rootRole = roleRepository.save(rootRole);

        Role subRole2 = new Role("sub_role_2", subRole, new HashSet<>(Arrays.asList(new AccessRight("ORG_READ"))));
        subRole2.setCode("sr102");
        subRole2.setActiveInd(true);
        subRole = roleRepository.save(subRole);
        subRole2 = roleRepository.save(subRole2);

        Role subRole3 = new Role("sub_role_3", subRole, new HashSet<>(Arrays.asList(new AccessRight("ORG_READ"))));
        subRole3.setCode("sr103");
        subRole3.setActiveInd(true);
        subRole.setChildren(new HashSet<>(Arrays.asList(subRole2, subRole3)));
        roleRepository.save(subRole);

        Department department = new Department("dep1", "c101", null, null);
        department.setCode("dep121");
        department.setRootRole(rootRole);
        departmentRepository.save(department);

        User user = new User();
        user.setUserId("u123");
        Map<String, String> departmentRoles = new HashMap<>();
        departmentRoles.put("dep121", "r101");
        user.setDepartmentRoles(departmentRoles);
        userRepository.save(user);

        userService.deleteRole(roleCode);
        Set<Role> roleAndSubroles = roleRepository.findByCodeInAndActiveInd(
                new HashSet<>(
                        Arrays.asList(rootRole.getCode(), subRole.getCode(), subRole2.getCode(), subRole3.getCode())),
                false);

        boolean deletedRootRole = roleAndSubroles.stream().anyMatch(r -> r.getCode().equals("r101"));
        assertTrue(deletedRootRole);
        boolean deletedSubRole = roleAndSubroles.stream().anyMatch(r -> r.getCode().equals("sr101"));
        assertTrue(deletedSubRole);
        boolean deletedSubRole2 = roleAndSubroles.stream().anyMatch(r -> r.getCode().equals("sr102"));
        assertTrue(deletedSubRole2);
        boolean deletedSubRole3 = roleAndSubroles.stream().anyMatch(r -> r.getCode().equals("sr103"));
        assertTrue(deletedSubRole3);

        User u = userRepository.findByUserIdAndEnabled(user.getUserId(), true).orElse(null);
        boolean departmentRole = u.getDepartmentRoles().entrySet().stream()
                .anyMatch(dr -> dr.getKey().equals("dep101"));
        assertFalse(departmentRole);
    }

    @Test(expected = RuntimeException.class)
    public void testCreateUserIfUserIdBlank() throws Exception {
        User user = new User();
        user.setUserId("");
        userService.createUser(user);
    }

    @Test(expected = RuntimeException.class)
    public void testCreateUserIfPassworBlank() throws Exception {
        User user = new User();
        user.setUserId("userid1");
        user.setPswrd("");
        userService.createUser(user);
    }

    @Test(expected = RuntimeException.class)
    public void testCreateUserIfUserExist() throws Exception {
        User user = new User();
        user.setUserId("userid1");
        user.setPswrd("password");
        userRepository.save(user);
        userService.createUser(user);
    }

    @Test(expected = RuntimeException.class)
    public void testCreateUserIfDepartmentNotFound() throws Exception {

        Map<String, String> departmentRole = new HashMap<>();
        departmentRole.put("dep101", "r101");
        User user = new User("user101", "user1", "user1@gmail.com", "password", "Manager", departmentRole, null, null,
                "c101");
        userService.createUser(user);
    }

    @Test(expected = RuntimeException.class)
    public void testCreateUserIfRoleNotFound() throws Exception {
        getSaveDepartment();
        Map<String, String> departmentRole = new HashMap<>();
        departmentRole.put("dep101", "r101");
        User user = new User("user101", "user1", "user1@gmail.com", "password", "Manager", departmentRole, null, null,
                "c101");
        userService.createUser(user);
    }

    @Test(expected = RuntimeException.class)
    public void testCreateUserIfOrgPartsNotFound() throws Exception {
        getSaveDepartment();
        Set<AccessRight> accessRights = new HashSet<>();
        AccessRight accessRight = new AccessRight("CREATE_USER");
        accessRights.add(accessRight);

        Map<String, String> departmentRole = new HashMap<>();
        departmentRole.put("dep101", "r101");
        Set<String> orgParts = new HashSet<>();
        orgParts.add("d101");

        User user = new User("user101", "user1", "user1@gmail.com", "password", "Manager", departmentRole, accessRights,
                orgParts, "c101");
        userService.createUser(user);
    }

    @Test(expected = RuntimeException.class)
    public void testCreateUserIfAccessRightsNotFound() throws Exception {
        getSaveDepartment();
        Set<AccessRight> accessRights = new HashSet<>();
        AccessRight accessRight = new AccessRight("ADMIN");
        accessRights.add(accessRight);

        Map<String, String> departmentRole = new HashMap<>();
        departmentRole.put("dep101", "r101");
        Set<String> orgParts = new HashSet<>();
        orgParts.add("d101");
        Organisation org = new Organisation("d1", "division", "d101", null, true);
        organisationRepository.save(org);

        User user = new User("user101", "user1", "user1@gmail.com", "password", "Manager", departmentRole, accessRights,
                orgParts, "c101");
        userService.createUser(user);
    }

    @Test
    public void testCreateUserSuccessfully() throws Exception {
        getSaveDepartment();
        Set<AccessRight> accessRights = new HashSet<>();
        AccessRight accessRight = new AccessRight("CREATE_USER");
        accessRight.setCompany("c101");
        accessRights.add(accessRight);
        accessRightRepository.save(accessRight);

        Map<String, String> departmentRole = new HashMap<>();
        departmentRole.put("dep101", "r101");
        Set<String> orgParts = new HashSet<>();
        orgParts.add("d101");

        Organisation org = new Organisation("d1", "division", "d101", null, true);
        organisationRepository.save(org);

        User user = new User("user101", "user1", "user1@gmail.com", "password", "Manager", departmentRole, accessRights,
                orgParts, "c101");
        user.setCreationDate(new Date());
        user.setEnabled(true);

        Mockito.doNothing().when(userServiceSpyBean).sendUserCreationEmail(Mockito.anyString());
        userService.createUser(user);

        User u = userRepository.findByUserIdAndEnabled("user101", true).orElseThrow(() -> new RuntimeException());
        assertEquals("user1", u.getName());
        assertEquals("user1@gmail.com", u.getEmail());
    }

    @Test
    public void searchUser() {
        getUserSave();
        String name = "use";
        String companyId = "c101";
        Set<User> users = userService.searchUser(name, companyId);
        User user = users.stream().filter(u -> u.getName().equals("user1")).findAny()
                .orElseThrow(() -> new RuntimeException());
        assertEquals("user1", user.getName());
    }

    @Test(expected = RuntimeException.class)
    public void testUpdateUserIfUserNotFound() {
        UpdateUserRequest updateUserRequest = new UpdateUserRequest();
        String userId = "userid2";
        userService.updateUser(updateUserRequest, userId);
    }

    @Test(expected = RuntimeException.class)
    public void testUpdateUserIfDepartmentNotFound() {
        String userId = "userid1";
        getUserSave();
        UpdateUserRequest updateUserRequest = new UpdateUserRequest();
        updateUserRequest.setUserId("user111");
        updateUserRequest.setNewEmail("user11@gmail.com");
        updateUserRequest.setNewName("user1");
        updateUserRequest.setNewDesignation("GM");
        updateUserRequest.setNewPhone("9383883840");
        Map<UpdateRightsMode, Set<String>> updateAccessRights = new HashMap<>();
        updateAccessRights.put(UpdateRightsMode.ADD, new HashSet<>(Arrays.asList("SENSE_ADMIN")));
        updateAccessRights.put(UpdateRightsMode.DELETE, new HashSet<>(Arrays.asList("CREATE_USER")));
        updateUserRequest.setUpdateAccessRights(updateAccessRights);

        DepartmentRoleRequest d1 = new DepartmentRoleRequest();
        d1.setDepartment("dep101");
        d1.setRole("r111");
        d1.setMode(UpdateDepMode.ADD);
        updateUserRequest.setUpdateDepartmentRoles(new HashSet<>(Arrays.asList(d1)));
        userService.updateUser(updateUserRequest, userId);
    }

    @Test(expected = RuntimeException.class)
    public void testUpdateUserIfRoleNotFound() {
        String userId = "userid1";
        getUserSave();
        getSaveDepartment();

        UpdateUserRequest updateUserRequest = new UpdateUserRequest();
        updateUserRequest.setUserId("user111");
        updateUserRequest.setNewEmail("user11@gmail.com");
        updateUserRequest.setNewName("user1");
        updateUserRequest.setNewDesignation("GM");
        updateUserRequest.setNewPhone("9383883840");
        Map<UpdateRightsMode, Set<String>> updateAccessRights = new HashMap<>();
        updateAccessRights.put(UpdateRightsMode.ADD, new HashSet<>(Arrays.asList("SENSE_ADMIN")));
        updateAccessRights.put(UpdateRightsMode.DELETE, new HashSet<>(Arrays.asList("CREATE_USER")));
        updateUserRequest.setUpdateAccessRights(updateAccessRights);

        DepartmentRoleRequest d1 = new DepartmentRoleRequest();
        d1.setDepartment("dep101");
        d1.setRole("r111");
        d1.setMode(UpdateDepMode.ADD);
        updateUserRequest.setUpdateDepartmentRoles(new HashSet<>(Arrays.asList(d1)));
        userService.updateUser(updateUserRequest, userId);
    }

    @Test
    public void testUpdateUserIfUpdDepRoleModeAddAndUpdate() {
        String userId = "userid1";
        getUserSave();
        getSaveDepartment();
        getSaveRole();

        UpdateUserRequest updateUserRequest = new UpdateUserRequest();
        updateUserRequest.setUserId("user111");
        updateUserRequest.setNewEmail("user11@gmail.com");
        updateUserRequest.setNewName("user1");
        updateUserRequest.setNewDesignation("GM");
        updateUserRequest.setNewPhone("9383883840");
        Map<UpdateRightsMode, Set<String>> updateAccessRights = new HashMap<>();
        updateAccessRights.put(UpdateRightsMode.ADD, new HashSet<>(Arrays.asList("SENSE_ADMIN")));
        updateAccessRights.put(UpdateRightsMode.DELETE, new HashSet<>(Arrays.asList("CREATE_USER")));
        updateUserRequest.setUpdateAccessRights(updateAccessRights);
        DepartmentRoleRequest d1 = new DepartmentRoleRequest();
        d1.setDepartment("dep101");
        d1.setRole("r111");
        d1.setMode(UpdateDepMode.ADD);
        updateUserRequest.setUpdateDepartmentRoles(new HashSet<>(Arrays.asList(d1)));

        userService.updateUser(updateUserRequest, userId);
        User updatedUser = userRepository.findByUserIdAndEnabled(userId, true).orElse(null);
        assertEquals(updateUserRequest.getNewEmail(), updatedUser.getEmail());

        boolean updatedRole = updatedUser.getDepartmentRoles().entrySet().stream()
                .anyMatch(r -> r.getValue().equals("r111"));
        assertTrue(updatedRole);
    }

    @Test
    public void testUpdateUserIfUpdDepRoleModeDelete() {
        String userId = "userid1";
        getUserSave();
        getSaveDepartment();
        getSaveRole();

        UpdateUserRequest updateUserRequest = new UpdateUserRequest();
        updateUserRequest.setUserId("user111");
        updateUserRequest.setNewEmail("user11@gmail.com");
        updateUserRequest.setNewName("user1");
        updateUserRequest.setNewDesignation("GM");
        updateUserRequest.setNewPhone("9383883840");
        Map<UpdateRightsMode, Set<String>> updateAccessRights = new HashMap<>();
        updateAccessRights.put(UpdateRightsMode.ADD, new HashSet<>(Arrays.asList("SENSE_ADMIN")));
        updateAccessRights.put(UpdateRightsMode.DELETE, new HashSet<>(Arrays.asList("CREATE_USER")));
        updateUserRequest.setUpdateAccessRights(updateAccessRights);

        DepartmentRoleRequest d1 = new DepartmentRoleRequest();
        d1.setDepartment("dep101");
        d1.setRole("r111");
        d1.setMode(UpdateDepMode.DELETE);
        updateUserRequest.setUpdateDepartmentRoles(new HashSet<>(Arrays.asList(d1)));

        userService.updateUser(updateUserRequest, userId);
        User updatedUser = userRepository.findByUserIdAndEnabled(userId, true).orElse(null);
        assertEquals(updateUserRequest.getNewEmail(), updatedUser.getEmail());
        boolean updatedRole = updatedUser.getDepartmentRoles().entrySet().stream()
                .anyMatch(r -> r.getValue().equals("r111"));
        assertFalse(updatedRole);
    }

    @Test(expected = RuntimeException.class)
    public void testDisableUserIfUserNotFound() {
        String userId = "userid2";
        userService.disableUser(userId);
    }

    @Test(expected = RuntimeException.class)
    public void testDisableUser() {
        String userId = "userid1";
        userService.disableUser(userId);
        User user = userRepository.findByUserIdAndEnabled(userId, true).orElse(null);
        assertEquals(false, user.isEnabled());
    }

    @Test(expected = RuntimeException.class)
    public void testSetLastLoginIfUserNotFound() {
        String userId = "userid2";
        Date loginTime = new Date();
        userService.setLastLogin(userId, loginTime);
    }

    @Test
    public void testSetLastLoginSuccessfully() {
        getUserSave();
        String userId = "userid1";
        Date loginTime = new Date();
        userService.setLastLogin(userId, loginTime);
        User user = userRepository.findByUserIdAndEnabled(userId, true).orElse(null);
        assertEquals(loginTime, user.getLastLoginTime());
    }

    @Test
    public void testDisableUserSuccessfully() {
        getUserSave();
        String userId = "userid1";
        userService.disableUser(userId);
        User user = userRepository.findByUserIdAndEnabled(userId, true).orElse(null);
        assertEquals(false, user.isEnabled());
    }

    @Test(expected = RuntimeException.class)
    public void getUserAccessIfUserNotFound() {
        String userId = "user101";
        userService.getUseraccess(userId, true, true, true);
    }

    @Test
    public void testGetUserAccess() {
        getUserSave();
        String userId = "userid1";
        AssetType assetType = new AssetType();
        assetType.setType("assetType1");
        Department department = new Department("dep1", "c101", null, new HashSet<>(Arrays.asList(assetType)));
        department.setCode("dep101");
        departmentRepository.save(department);

        UserAccess userAccess = userService.getUseraccess(userId, true, true, true);
        String orgPart = userAccess.getOrgParts().stream().filter(o -> o.equals("d101")).findAny()
                .orElseThrow(() -> new RuntimeException());
        assertEquals("d101", orgPart);
    }

    @Test(expected = RuntimeException.class)
    public void testChangePasswordIfUserNotFound() {
        String userId = "userid2";
        String newPassword = "newpassword";
        userService.changePassword(userId, newPassword);
    }

    @Test
    public void changePasswordSuccessfully() {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        getUserSave();
        String userId = "userid1";
        String newPassword = "newpassword";
        userService.changePassword(userId, newPassword);
        User user = userRepository.findByUserIdAndEnabled(userId, true).orElse(null);
        boolean passwordMatch = encoder.matches(newPassword, user.getPswrd());
        assertTrue(passwordMatch);
    }

    @Test
    public void testIsOrgAccessibleIfuserOrgPartContainsOrgId() {
        String orgId = "d101";
        Set<String> userOrgParts = new HashSet<>();
        userOrgParts.add("d101");
        boolean isOrgParts = userService.isOrgAccessible(orgId, userOrgParts);
        assertTrue(isOrgParts);
    }

    @Test
    public void testIsOrgAccessibleIfAccessibleOrgNotPresent() {
        String orgId = "d102";
        Set<String> userOrgParts = new HashSet<>();
        userOrgParts.add("c101");
        Organisation parentOrg = new Organisation("c1", "company", "c101", null, true);
        Organisation org = new Organisation("d1", "division", "d101", null, true);
        org.setParent(parentOrg);
        organisationRepository.save(org);
        boolean isOrgAccessible = userService.isOrgAccessible(orgId, userOrgParts);
        assertFalse(isOrgAccessible);
    }

    @Test
    public void testIsOrgAccessible() {
        String orgId = "d101";
        Set<String> userOrgParts = new HashSet<>();
        userOrgParts.add("c101");
        userOrgParts.add("cr101");
        Organisation parentOrg = new Organisation("c1", "company", "c101", null, true);
        Organisation childOrg = new Organisation("cr1", "circle", "cr101", null, true);
        Organisation subChildOrg = new Organisation("d1", "division", "d101", null, true);
        childOrg.setParent(parentOrg);
        organisationRepository.save(childOrg);
        subChildOrg.setParent(childOrg);
        organisationRepository.save(subChildOrg);
        boolean isOrgAccessible = userService.isOrgAccessible(orgId, userOrgParts);
        assertTrue(isOrgAccessible);
    }

    @Test
    public void tetsIsAssetAccessibleIfAccessibleAssetNotPresent() {
        String assetCode = "a102";
        Set<String> userOrgParts = new HashSet<>();
        userOrgParts.add("c101");
        Set<String> userAssetTypes = new HashSet<>();
        userAssetTypes.add("assetType1");
        Organisation parentOrg = new Organisation("c1", "company", "c101", null, true);
        Asset asset = new Asset("a1", "assetType1", "a101", parentOrg, null, true);
        assetRepository.save(asset);
        boolean isAssetAccessible = userService.isAssetAccessible(assetCode, userOrgParts, userAssetTypes);
        assertFalse(isAssetAccessible);
    }

    @Test
    public void testIsAssetAccessible() {
        String assetCode = "a101";
        Set<String> userOrgParts = new HashSet<>();
        userOrgParts.add("c101");
        Set<String> userAssetTypes = new HashSet<>();
        userAssetTypes.add("assetType1");
        Organisation parentOrg = new Organisation("c1", "company", "c101", null, true);
        Asset asset = new Asset("a1", "assetType1", "a101", parentOrg, null, true);
        assetRepository.save(asset);
        boolean isAssetAccessible = userService.isAssetAccessible(assetCode, userOrgParts, userAssetTypes);
        assertTrue(isAssetAccessible);
    }

    @Test
    public void testGetAccessRights() {
        String company = "c111";
        AccessRight accessRight1 = new AccessRight();
        accessRight1.setCompany("c111");
        accessRight1.setAccessType("ORG_READ");
        accessRight1.setCreationDate(new Date());
        accessRightRepository.save(accessRight1);
        AccessRight accessRight2 = new AccessRight();
        accessRight2.setCompany("ALL");
        accessRight2.setAccessType("ASSET_READ");
        accessRight2.setCreationDate(new Date());
        accessRightRepository.saveAll(Arrays.asList(accessRight1, accessRight2));
        Set<AccessRight> accessRights = userService.getAccessRights(company);
        AccessRight ar1 = accessRights.stream().filter(a -> a.getCompany().equals(accessRight1.getCompany())).findAny()
                .orElseThrow(() -> new RuntimeException());
        assertEquals(accessRight1.getAccessType(), ar1.getAccessType());
        AccessRight ar2 = accessRights.stream().filter(a -> a.getCompany().equals(accessRight2.getCompany())).findAny()
                .orElseThrow(() -> new RuntimeException());
        assertEquals(accessRight2.getAccessType(), ar2.getAccessType());
    }

    @Test(expected = RuntimeException.class)
    public void testGetMyDetailsIfUserNotFound() {
        String userId = "userid2";
        userService.getMyDetails(userId);
    }

    @Test
    public void testGetMyDetails() {
        User user = getUserSave();
        String userId = "userid1";
        User userDetails = userService.getMyDetails(userId);
        assertEquals(user.getName(), userDetails.getName());
    }

    private User getUserSave() {
        Set<AccessRight> accessRights = new HashSet<>();
        AccessRight accessRight = new AccessRight("CREATE_USER");
        accessRights.add(accessRight);
        Map<String, String> departmentRole = new HashMap<>();
        departmentRole.put("dep101", "r101");
        Set<String> orgParts = new HashSet<>();
        orgParts.add("d101");
        User user = new User("userid1", "user1", "user1@gmail.com", "password", "Manager", departmentRole, accessRights,
                orgParts, "c101");
        userRepository.save(user);
        return user;
    }

    private void getSaveDepartment() {
        Set<AccessRight> accessRights = new HashSet<>();
        AccessRight accessRight = new AccessRight("CREATE_USER");
        accessRights.add(accessRight);
        Role role = new Role("Role1", null, accessRights);
        role.setCode("r101");
        role.setActiveInd(true);
        Role subRole1 = new Role("SubRole1", role, accessRights);
        subRole1.setCode("sr101");
        subRole1.setActiveInd(true);
        Role subRole2 = new Role("SubRole2", role, accessRights);
        subRole2.setCode("sr102");
        subRole2.setActiveInd(true);

        AssetType assetType = new AssetType();
        assetType.setType("assetType1");
        assetType.setCompany("c101");

        role.setChildren(new HashSet<>(Arrays.asList(subRole1, subRole2)));
        Department department = new Department("dep1", "c101", role, new HashSet<>(Arrays.asList(assetType)));
        department.setCode("dep101");
        departmentRepository.save(department);
    }

    private void getSaveRole() {
        Role role = new Role("Manager", null, null);
        role.setCode("r101");
        roleRepository.save(role);
        Role role2 = new Role("Admin", null, new HashSet<>(Arrays.asList(new AccessRight("CREATE_USER"))));
        role2.setCode("r111");
        roleRepository.save(role2);
    }
}

package com.sense.users.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers;
import org.springframework.security.web.FilterChainProxy;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sense.security.model.JwtUserDetails;
import com.sense.security.util.JwtTokenUtil;
import com.sense.sensemodel.model.assets.AssetType;
import com.sense.sensemodel.model.users.AccessRight;
import com.sense.sensemodel.model.users.Department;
import com.sense.sensemodel.model.users.Role;
import com.sense.sensemodel.model.users.User;
import com.sense.sensemodel.model.users.UserAccess;
import com.sense.users.model.ModifyDepartmentRequest;
import com.sense.users.model.ModifyDepartmentRequest.RequestType;
import com.sense.users.model.UpdateUserRequest;
import com.sense.users.service.UserService;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@RunWith(SpringRunner.class)
@SpringBootTest
public class UserControllerTest {

    private MockMvc mockMvc;
    private MockMvc mockMvc2;
    @InjectMocks
    private UserController userController;

    @Mock
    private UserService userService;

    @Autowired
    private FilterChainProxy springSecurityFilterChain;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Mock
    private JwtTokenUtil jtu;

    @Before
    public void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(userController).build();
        
        mockMvc2 = MockMvcBuilders.standaloneSetup(userController)
                .apply(SecurityMockMvcConfigurers.springSecurity(springSecurityFilterChain)).build();
        MockitoAnnotations.initMocks(this);
    }
    
    @Test
    public void testCreateUserIfNotSenseAdmin() throws Exception {
        List<SimpleGrantedAuthority> authorities = new ArrayList<SimpleGrantedAuthority>(
                Arrays.asList(new SimpleGrantedAuthority("CREATE_USER")));
        JwtUserDetails userDetails = new JwtUserDetails("admin", "user1", "user1@gmail.com", "password", authorities,
                true, new Date(), "c102");
        final String accessToken = jwtTokenUtil.generateToken(userDetails);

        Set<AccessRight> accessRights = new HashSet<>();
        AccessRight accessRight = new AccessRight("CREATE_USER");
        accessRights.add(accessRight);
        Set<String> orgParts = new HashSet<>();
        orgParts.add("d101");
        orgParts.add("d102");
        User user = new User("user101", "user1", "user1@gmail.com", "password", "manager", null, accessRights,
                orgParts, "c102");
        String userInJson = this.mapToJson(user);

        Mockito.when(jtu.getUserCompanyFromToken(Mockito.anyString())).thenReturn("c101");
        Mockito.doNothing().when(userService).createUser(Mockito.any());
        mockMvc2.perform(
                MockMvcRequestBuilders.put("/user/createUser").accept(MediaType.APPLICATION_JSON).content(userInJson)
                        .contentType(MediaType.APPLICATION_JSON).header("Authorization", "Bearer " + accessToken))
                .andExpect(status().isInternalServerError());
    }

    @Test
    public void testCreateUser() throws Exception {
        String accessToken = generateToken();
        Set<AccessRight> accessRights = new HashSet<>();
        AccessRight accessRight = new AccessRight("CREATE_USER");
        accessRights.add(accessRight);
        Set<String> orgParts = new HashSet<>();
        orgParts.add("d101");
        orgParts.add("d102");
        User user = new User("user101", "user1", "user1@gmail.com", "password", "manager", null, accessRights,
                orgParts, "c102");
        String userInJson = this.mapToJson(user);

        Mockito.when(jtu.getUserCompanyFromToken(Mockito.anyString())).thenReturn("c101");
        Mockito.doNothing().when(userService).createUser(Mockito.any());
        mockMvc2.perform(
                MockMvcRequestBuilders.put("/user/createUser").accept(MediaType.APPLICATION_JSON).content(userInJson)
                        .contentType(MediaType.APPLICATION_JSON).header("Authorization", "Bearer " + accessToken))
                .andExpect(status().isOk());
        verify(userService, times(1)).createUser(Mockito.any());
    }

    @Test
    public void searchUser() throws Exception {
        String accessToken = generateToken();
        Set<User> users = new HashSet<>();
        User user = new User("user123", "user1", "user123@gmail.com", "password", "manager", null, null, null, "c101");
        users.add(user);

        Mockito.when(jtu.getUserCompanyFromToken(Mockito.anyString())).thenReturn("c101");
        Mockito.when(userService.searchUser(Mockito.anyString(), Mockito.anyString())).thenReturn(users);

        RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/user/searchUser").param("name", "user101")
                .param("companyId", "c101").accept(MediaType.APPLICATION_JSON)
                .header("Authorization", "Bearer " + accessToken);

        MvcResult mvcResult = mockMvc2.perform(requestBuilder).andReturn();
        String expectedJson = this.mapToJson(users);
        String outputInJson = mvcResult.getResponse().getContentAsString();
        assertEquals(expectedJson, outputInJson);
        assertEquals(HttpStatus.OK.value(), mvcResult.getResponse().getStatus());
        verify(userService, times(1)).searchUser(Mockito.anyString(), Mockito.anyString());
    }

    @Test
    public void testUpdateUserIfNotSenseAdmin() throws Exception {
        List<SimpleGrantedAuthority> authorities = new ArrayList<SimpleGrantedAuthority>(
                Arrays.asList(new SimpleGrantedAuthority("CREATE_USER")));
        JwtUserDetails userDetails = new JwtUserDetails("admin", "user1", "user1@gmail.com", "password", authorities,
                true, new Date(), "c102");
        final String accessToken = jwtTokenUtil.generateToken(userDetails);

        UpdateUserRequest updateUserRequest = new UpdateUserRequest();
        updateUserRequest.setUserId("user111");
        updateUserRequest.setNewEmail("user11@gmail.com");
        updateUserRequest.setNewName("user1");
        updateUserRequest.setNewDesignation("GM");
        String updatUserInJson = this.mapToJson(updateUserRequest);
        User user = new User("user111", "user1", "user11@gmail.com", "password", "GM", null, null, null, "c101");

        Mockito.when(userService.updateUser(Mockito.any(UpdateUserRequest.class), Mockito.anyString())).thenReturn(user);
        mockMvc2.perform(MockMvcRequestBuilders.post("/user/updateUser").accept(MediaType.APPLICATION_JSON)
                .content(updatUserInJson).contentType(MediaType.APPLICATION_JSON)
                .header("Authorization", "Bearer " + accessToken)).andExpect(status().isInternalServerError());
    }

    @Test
    public void testUpdateUser() throws Exception {
        String accessToken = generateToken();
        UpdateUserRequest updateUserRequest = new UpdateUserRequest();
        updateUserRequest.setUserId("user111");
        updateUserRequest.setNewEmail("user11@gmail.com");
        updateUserRequest.setNewName("user1");
        updateUserRequest.setNewDesignation("GM");
        String updatUserInJson = this.mapToJson(updateUserRequest);
        User user = new User("user111", "user1", "user11@gmail.com", "password", "GM", null, null, null, "c101");

        Mockito.when(userService.updateUser(Mockito.any(UpdateUserRequest.class), Mockito.anyString())).thenReturn(user);
        mockMvc2.perform(MockMvcRequestBuilders.post("/user/updateUser").accept(MediaType.APPLICATION_JSON)
                .content(updatUserInJson).contentType(MediaType.APPLICATION_JSON)
                .header("Authorization", "Bearer " + accessToken)).andExpect(status().isOk());

        verify(userService, times(1)).updateUser(Mockito.any(UpdateUserRequest.class), Mockito.anyString());
    }

    @Test
    public void testCreateDepartment() throws Exception {

        Mockito.doNothing().when(userService).addDepartmentToCompany(Mockito.anyString(), Mockito.anyString(),
                Mockito.anySet());
        mockMvc.perform(MockMvcRequestBuilders.put("/user/createDepartment").param("departmentName", "dep1")
                .param("company", "c101").param("assetTypeNames", "assetType1").accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());

        verify(userService, times(1)).addDepartmentToCompany(Mockito.anyString(), Mockito.anyString(),
                Mockito.anySet());
    }

    @Test
    public void testGetDepartments() throws Exception {
        Set<AccessRight> accessRights = new HashSet<>();
        AccessRight accessRight = new AccessRight("CREATE_USER");
        accessRights.add(accessRight);

        Set<AssetType> assetTypes = new HashSet<>();
        AssetType assetType = new AssetType();
        assetType.setType("assetType1");
        assetType.setCompany("c101");
        assetTypes.add(assetType);

        Set<Department> departments = new HashSet<>();
        Department department = new Department("dep1", "c101", new Role("Manager", null, accessRights), assetTypes);
        departments.add(department);
        Mockito.when(userService.getDepartmentsForCompany(Mockito.anyString())).thenReturn(departments);

        RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/user/getDepartments").param("company", "c101")
                .accept(MediaType.APPLICATION_JSON);
        MvcResult mvcResult = mockMvc.perform(requestBuilder).andReturn();
        String expectedJson = this.mapToJson(departments);
        String outputInJson = mvcResult.getResponse().getContentAsString();
        assertEquals(expectedJson, outputInJson);
        assertEquals(HttpStatus.OK.value(), mvcResult.getResponse().getStatus());

        verify(userService, times(1)).getDepartmentsForCompany(Mockito.anyString());
    }
    
    @Test
    public void testGetDepartmentsByCode() throws Exception {
        Set<Department> departments = new HashSet<>();
        Department department1 = new Department("dep1", "c101", null, null);
        department1.setCode("dep101");
        Department department2 = new Department("dep2", "c101", null, null);
        department2.setCode("dep102");
        departments.addAll(Arrays.asList(department1,department2));
        Mockito.when(userService.getDepartmentsByCode(Mockito.anySet())).thenReturn(departments);

        RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/user/getDepartmentsByCode").param("codes", "dep101").param("codes", "dep102")
                .accept(MediaType.APPLICATION_JSON);
        MvcResult mvcResult = mockMvc.perform(requestBuilder).andReturn();
        String expectedJson = this.mapToJson(departments);
        String outputInJson = mvcResult.getResponse().getContentAsString();
        assertEquals(expectedJson, outputInJson);
        assertEquals(HttpStatus.OK.value(), mvcResult.getResponse().getStatus());

        verify(userService, times(1)).getDepartmentsByCode(Mockito.anySet());
    }

    @Test
    public void testModifyDepartment() throws Exception {
        ModifyDepartmentRequest mdRequest = new ModifyDepartmentRequest();
        mdRequest.setDepartmentCode("dep101");
        Map<String, RequestType> modifyAssetsTypes = new HashMap<>();
        modifyAssetsTypes.put("requestType", RequestType.ADD);
        mdRequest.setModifyAssetsTypes(new HashMap<String, ModifyDepartmentRequest.RequestType>());
        mdRequest.setModifyAssetsTypes(modifyAssetsTypes);
        String mdRequestInJson = this.mapToJson(mdRequest);

        Mockito.doNothing().when(userService).modifyDepartment(Mockito.any(ModifyDepartmentRequest.class));
        mockMvc.perform(MockMvcRequestBuilders.post("/user/modifyDepartment").accept(MediaType.APPLICATION_JSON)
                .content(mdRequestInJson).contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());

        verify(userService, times(1)).modifyDepartment(Mockito.any(ModifyDepartmentRequest.class));
    }

    @Test
    public void testDeleteDepartment() throws Exception {

        Mockito.doNothing().when(userService).deleteDepartment(Mockito.anyString());
        mockMvc.perform(MockMvcRequestBuilders.delete("/user/deleteDepartment").param("department", "dep101")
                .accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk());

        verify(userService, times(1)).deleteDepartment(Mockito.anyString());
    }

    @Test
    public void testCreateAdminDepartmentAndRole() throws Exception {

        Mockito.doNothing().when(userService).createAdminDepartmentAndRoleAndUser(Mockito.anyString(), Mockito.anyString());
        mockMvc.perform(MockMvcRequestBuilders.put("/user/createAdminDepartmentAndRole").param("company", "c101").param("companyAdminEmail", "abc@gmail.com")
                .accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk());

        verify(userService, times(1)).createAdminDepartmentAndRoleAndUser(Mockito.anyString(), Mockito.anyString());
    }

    @Test
    public void testCreateRole() throws Exception {
        Set<AccessRight> accessRights = new HashSet<>();
        AccessRight accessRight = new AccessRight("CREATE_USER");
        accessRights.add(accessRight);
        Role newRole = new Role("Manager", null, accessRights);
        String newRoleInJson = this.mapToJson(newRole);

        Mockito.when(userService.addRole(Mockito.any(Role.class), Mockito.anyString(), Mockito.anyString())).thenReturn(newRole);
        mockMvc.perform(MockMvcRequestBuilders.put("/user/createRole").param("parent", "dep101").param("company", "c101")
                .accept(MediaType.APPLICATION_JSON).content(newRoleInJson).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());

        verify(userService, times(1)).addRole(Mockito.any(Role.class), Mockito.anyString(), Mockito.anyString());
    }

    @Test
    public void testDeleteRole() throws Exception {
        Mockito.doNothing().when(userService).deleteRole(Mockito.anyString());

        mockMvc.perform(MockMvcRequestBuilders.delete("/user/deleteRole").param("roleCode", "r101")
                .accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk());

        verify(userService, times(1)).deleteRole(Mockito.anyString());
    }
    
    @Test
    public void testGetRolesByCode() throws Exception {
        Set<AccessRight> accessRights = new HashSet<>();
        AccessRight accessRight = new AccessRight("CREATE_USER");
        accessRights.add(accessRight);
        Set<Role> subRoles = new HashSet<>();
        Role subRole1 = new Role("sub_role1", null, accessRights);
        subRole1.setCode("r101");
        Role subRole2 = new Role("sub_role2", null, accessRights);
        subRole1.setCode("r101");
        subRoles.addAll(Arrays.asList(subRole1, subRole2));
        Mockito.when(userService.getRolesByCode(Mockito.anySet())).thenReturn(subRoles);

        RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/user/getRolesByCode").param("codes", "r101").param("codes", "r102")
                .accept(MediaType.APPLICATION_JSON);
        MvcResult mvcResult = mockMvc.perform(requestBuilder).andReturn();
        String expectedJson = this.mapToJson(subRoles);
        String outputInJson = mvcResult.getResponse().getContentAsString();
        assertEquals(expectedJson, outputInJson);
        assertEquals(HttpStatus.OK.value(), mvcResult.getResponse().getStatus());

        verify(userService, times(1)).getRolesByCode(Mockito.anySet());
    }

    @Test
    public void testGetUserAccess() throws Exception {
        String accessToken = generateToken();
        String userId = "userId1";
        Set<String> orgParts = new HashSet<>();
        orgParts.addAll(Arrays.asList("d101", "z101"));
        Set<String> assetsCodes = new HashSet<>();
        assetsCodes.addAll(Arrays.asList("a101", "a102"));
        UserAccess userAccess = new UserAccess(userId, orgParts, assetsCodes);

        Mockito.when(userService.getUseraccess(Mockito.anyString(), Mockito.anyBoolean(), Mockito.anyBoolean(),
                Mockito.anyBoolean())).thenReturn(userAccess);

        RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/user/getUserAccess")
                .header("Authorization", "Bearer " + accessToken).param("userId", "userId1").param("orgs", "true")
                .param("assets", "true").param("departments", "true").accept(MediaType.APPLICATION_JSON);

        MvcResult mvcResult = mockMvc2.perform(requestBuilder).andReturn();
        String expectedJson = this.mapToJson(userAccess);
        String outputInJson = mvcResult.getResponse().getContentAsString();
        assertEquals(expectedJson, outputInJson);
        assertEquals(HttpStatus.OK.value(), mvcResult.getResponse().getStatus());

        verify(userService, times(1)).getUseraccess(Mockito.anyString(), Mockito.anyBoolean(), Mockito.anyBoolean(),
                Mockito.anyBoolean());
    }

    @Test
    public void testGetAccessRights() throws Exception {
        AccessRight accessRight1 = new AccessRight();
        accessRight1.setCompany("c111");
        accessRight1.setAccessType("ORG_READ");
        accessRight1.setCreationDate(new Date());
        Set<AccessRight> accessRights = new HashSet<>();
        accessRights.add(accessRight1);
        
        Mockito.when(userService.getAccessRights(Mockito.anyString())).thenReturn(accessRights);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/user/getAccessRights").param("company", "c101")
                .accept(MediaType.APPLICATION_JSON);
        MvcResult mvcResult = mockMvc.perform(requestBuilder).andReturn();
        String expectedJson = this.mapToJson(accessRights);
        String outputInJson = mvcResult.getResponse().getContentAsString();
        assertEquals(expectedJson, outputInJson);
        assertEquals(HttpStatus.OK.value(), mvcResult.getResponse().getStatus());

        verify(userService, times(1)).getAccessRights(Mockito.anyString());
    }

    @Test
    public void testIsOrgAccessible() throws Exception {
        String accessToken = generateToken();
        Mockito.when(userService.isOrgAccessible(Mockito.anyString(), Mockito.anySet())).thenReturn(true);
        mockMvc2.perform(MockMvcRequestBuilders.get("/user/isOrgAccessible").param("orgId", "d101")
                .accept(MediaType.APPLICATION_JSON).header("Authorization", "Bearer " + accessToken))
                .andExpect(status().isOk());
        verify(userService, times(1)).isOrgAccessible(Mockito.anyString(), Mockito.anySet());
    }

    @Test
    public void testIsAssetAccessible() throws Exception {
        String accessToken = generateToken();
        Mockito.when(userService.isAssetAccessible(Mockito.anyString(), Mockito.anySet(), Mockito.anySet()))
                .thenReturn(true);
        mockMvc2.perform(MockMvcRequestBuilders.get("/user/isAssetAccessible").param("assetCode", "a101")
                .accept(MediaType.APPLICATION_JSON).header("Authorization", "Bearer " + accessToken))
                .andExpect(status().isOk());
        verify(userService, times(1)).isAssetAccessible(Mockito.anyString(), Mockito.anySet(), Mockito.anySet());
    }

    @Test
    public void disableUser() throws Exception {
        String accessToken = generateToken();
        Mockito.doNothing().when(userService).disableUser(Mockito.anyString());

        mockMvc2.perform(MockMvcRequestBuilders.post("/user/disableUser").param("userId", "user101")
                .header("Authorization", "Bearer " + accessToken).accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());

        verify(userService, times(1)).disableUser(Mockito.anyString());
    }

    @Test
    public void testGetMyDetails() throws Exception {
        String accessToken = generateToken();
        User user = new User("admin", "user1", "user1@gmail.com", "password", "Manager", null, null, null, "c101");

        Mockito.when(userService.getMyDetails(Mockito.anyString())).thenReturn(user);

        RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/user/getMyDetails")
                .header("Authorization", "Bearer " + accessToken).accept(MediaType.APPLICATION_JSON);
        MvcResult mvcResult = mockMvc2.perform(requestBuilder).andReturn();
        String expectedJson = this.mapToJson(user);
        String outputInJson = mvcResult.getResponse().getContentAsString();
        assertEquals(expectedJson, outputInJson);
        assertEquals(HttpStatus.OK.value(), mvcResult.getResponse().getStatus());

        verify(userService, times(1)).getMyDetails(Mockito.anyString());
    }

    private String mapToJson(Object object) throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.writeValueAsString(object);
    }

    public String generateToken() {
        List<SimpleGrantedAuthority> authorities = new ArrayList<SimpleGrantedAuthority>(Arrays.asList(
                new SimpleGrantedAuthority("CREATE_USER"), new SimpleGrantedAuthority("SENSE_ADMIN"),
                new SimpleGrantedAuthority("ORGPART_d101")));
        JwtUserDetails userDetails = new JwtUserDetails("admin", "user1", "user1@gmail.com", "password", authorities,
                true, new Date(), "c102");
        final String token = jwtTokenUtil.generateToken(userDetails);
        return token;
    }
}

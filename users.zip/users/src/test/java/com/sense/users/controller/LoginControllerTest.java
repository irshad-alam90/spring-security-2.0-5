package com.sense.users.controller;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers;
import org.springframework.security.web.FilterChainProxy;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sense.security.model.JwtAuthenticationRequest;
import com.sense.security.model.JwtUserDetails;
import com.sense.security.service.JwtUserDetailsService;
import com.sense.security.util.JwtTokenUtil;
import com.sense.users.service.UserService;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.times;

@RunWith(SpringRunner.class)
@SpringBootTest
public class LoginControllerTest {

    private MockMvc mockMvc;
    private MockMvc mockMvc2;
    @InjectMocks
    private LoginController loginController;

    @Mock
    private UserService userService;

    @Mock
    private JwtUserDetailsService userDetailsService;

    @Mock
    private AuthenticationManager authenticationManager;

    @Mock
    private JwtTokenUtil jtu;

    @Autowired
    private FilterChainProxy springSecurityFilterChain;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Before
    public void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(loginController).build();
    }

    @Before
    public void startMocks() {
        mockMvc2 = MockMvcBuilders.standaloneSetup(loginController)
                .apply(SecurityMockMvcConfigurers.springSecurity(springSecurityFilterChain)).build();

        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testCreateAuthenticationTokenIfUserNotAuthorized() throws Exception {
        JwtAuthenticationRequest authRequest = new JwtAuthenticationRequest();
        authRequest.setUserId("user101");
        authRequest.setPassword("password");
        String authRequestInJson = this.mapToJson(authRequest);

        SimpleGrantedAuthority authority = new SimpleGrantedAuthority("CREATE_USER");
        List<SimpleGrantedAuthority> authorities = new ArrayList<SimpleGrantedAuthority>();
        authorities.add(authority);

        JwtUserDetails userDetails = new JwtUserDetails("user101", "user1", "user1@gmail.com", "password", authorities,
                true, new Date(), "c101");
        Mockito.when(userDetailsService.loadUserByUsername(authRequest.getUserId())).thenReturn(userDetails);

        Authentication authentication = new UsernamePasswordAuthenticationToken(authRequest.getUserId(),
                authRequest.getPassword());
        Mockito.when(authenticationManager.authenticate(Mockito.anyObject())).thenReturn(authentication);

        mockMvc.perform(MockMvcRequestBuilders.post("/user/auth/login").param("loginMode", "ADMIN")
                .accept(MediaType.APPLICATION_JSON).content(authRequestInJson).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isUnauthorized());
    }

    @Test
    public void testCreateAuthenticationToken() throws Exception {
        String token = "kerrioere.5u4ojroerrgeg.klkjdfkdf";
        JwtAuthenticationRequest authRequest = new JwtAuthenticationRequest();
        authRequest.setUserId("user101");
        authRequest.setPassword("password");
        String authRequestInJson = this.mapToJson(authRequest);

        SimpleGrantedAuthority authority = new SimpleGrantedAuthority("CREATE_USER");
        List<SimpleGrantedAuthority> authorities = new ArrayList<SimpleGrantedAuthority>();
        authorities.add(authority);

        JwtUserDetails userDetails = new JwtUserDetails("user101", "user1", "user1@gmail.com", "password", authorities,
                true, new Date(), "c101");
        Mockito.when(userDetailsService.loadUserByUsername(authRequest.getUserId())).thenReturn(userDetails);

        Authentication authentication = new UsernamePasswordAuthenticationToken(authRequest.getUserId(),
                authRequest.getPassword());
        Mockito.when(authenticationManager.authenticate(Mockito.anyObject())).thenReturn(authentication);
        Mockito.when(jtu.generateToken(userDetails)).thenReturn(token);
        Mockito.doNothing().when(userService).setLastLogin(Mockito.anyString(), Mockito.any(Date.class));

        mockMvc.perform(MockMvcRequestBuilders.post("/user/auth/login").param("loginMode", "USER")
                .accept(MediaType.APPLICATION_JSON).content(authRequestInJson).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
        verify(userService, times(1)).setLastLogin(Mockito.anyString(), Mockito.any(Date.class));
    }

    @Test
    public void testRefreshAndGetAuthenticationToken() throws Exception {
        String accessToken = generateToken();
        String refreshedToken = "kjsdkre.errrkjr.rjwker.fsdseerre";
        JwtUserDetails userDetails = new JwtUserDetails("user101", "user1", "user1@gmail.com", "password", null, true,
                new Date(), "c101");

        Mockito.when(jtu.getUserNameFromToken(Mockito.anyString())).thenReturn("user101");
        Mockito.when(userDetailsService.loadUserByUsername(Mockito.anyString())).thenReturn(userDetails);
        Mockito.when(jtu.refreshToken(Mockito.anyString())).thenReturn(refreshedToken);
        Mockito.doNothing().when(userService).setLastLogin(Mockito.anyString(), Mockito.any(Date.class));
        mockMvc2.perform(MockMvcRequestBuilders.get("/user/auth/refresh").accept(MediaType.APPLICATION_JSON)
                .header("Authorization", "Bearer " + accessToken)).andExpect(status().isOk());
    }

    @Test
    public void changePassword() throws Exception {
        JwtAuthenticationRequest authRequest = new JwtAuthenticationRequest();
        authRequest.setUserId("user101");
        authRequest.setPassword("password");
        authRequest.setNewPassword("newPassword");
        String authRequestInJson = this.mapToJson(authRequest);

        Mockito.doNothing().when(userService).changePassword(Mockito.anyString(), Mockito.anyString());
        mockMvc.perform(MockMvcRequestBuilders.put("/user/auth/changePassword").accept(MediaType.APPLICATION_JSON)
                .content(authRequestInJson).contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
        verify(userService, times(1)).changePassword(Mockito.anyString(), Mockito.anyString());
    }

    @Test
    public void logout() throws Exception {

        mockMvc.perform(MockMvcRequestBuilders.get("/user/auth/logout").accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    private String mapToJson(Object object) throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.writeValueAsString(object);
    }

    public String generateToken() {
        List<SimpleGrantedAuthority> authorities = new ArrayList<SimpleGrantedAuthority>(
                Arrays.asList(new SimpleGrantedAuthority("ADMIN_LOGIN")));
        JwtUserDetails userDetails = new JwtUserDetails("user101", "user1", "user1@gmail.com", "password", authorities,
                true, new Date(), "c101");
        final String token = jwtTokenUtil.generateToken(userDetails);
        return token;
    }
}

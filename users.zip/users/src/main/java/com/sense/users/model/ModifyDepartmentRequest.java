package com.sense.users.model;

import java.util.Map;

public class ModifyDepartmentRequest {

	public enum RequestType {
		ADD, DELETE
	}

	private String departmentCode;

	private Map<String, RequestType> modifyAssetsTypes;

	public Map<String, RequestType> getModifyAssetsTypes() {
		return modifyAssetsTypes;
	}

	public void setModifyAssetsTypes(Map<String, RequestType> modifyAssetsTypes) {
		this.modifyAssetsTypes = modifyAssetsTypes;
	}

	public String getDepartmentCode() {
		return departmentCode;
	}

	public void setDepartmentCode(String departmentCode) {
		this.departmentCode = departmentCode;
	}
}

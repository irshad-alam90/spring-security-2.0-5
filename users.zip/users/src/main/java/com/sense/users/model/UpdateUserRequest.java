package com.sense.users.model;

import java.util.Map;
import java.util.Set;

public class UpdateUserRequest {

	public enum UpdateDepMode {
		ADD, DELETE, UPDATE
	}

	public enum UpdateRightsMode {
		ADD, DELETE
	}

	private String userId;
	
	private String newEmail;

	private String newName;

	private String newDesignation;

	private String newPhone;

	private Set<DepartmentRoleRequest> updateDepartmentRoles;

	private Map<UpdateRightsMode, Set<String>> updateAccessRights;
	
	public static class DepartmentRoleRequest {
		private String department;
		private String role;
		private UpdateDepMode mode;

		public String getDepartment() {
			return department;
		}

		public void setDepartment(String department) {
			this.department = department;
		}

		public String getRole() {
			return role;
		}

		public void setRole(String role) {
			this.role = role;
		}

		public UpdateDepMode getMode() {
			return mode;
		}

		public void setMode(UpdateDepMode mode) {
			this.mode = mode;
		}
	}

	public String getNewEmail() {
		return newEmail;
	}

	public void setNewEmail(String newEmail) {
		this.newEmail = newEmail;
	}

	public String getNewName() {
		return newName;
	}

	public void setNewName(String newName) {
		this.newName = newName;
	}

	public String getNewDesignation() {
		return newDesignation;
	}

	public void setNewDesignation(String newDesignation) {
		this.newDesignation = newDesignation;
	}

	public Set<DepartmentRoleRequest> getUpdateDepartmentRoles() {
		return updateDepartmentRoles;
	}

	public void setUpdateDepartmentRoles(Set<DepartmentRoleRequest> updateDepartmentRoles) {
		this.updateDepartmentRoles = updateDepartmentRoles;
	}

	public Map<UpdateRightsMode, Set<String>> getUpdateAccessRights() {
		return updateAccessRights;
	}

	public void setUpdateAccessRights(Map<UpdateRightsMode, Set<String>> updateAccessRights) {
		this.updateAccessRights = updateAccessRights;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getNewPhone() {
		return newPhone;
	}

	public void setNewPhone(String newPhone) {
		this.newPhone = newPhone;
	}
}

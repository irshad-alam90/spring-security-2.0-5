package com.sense.users.controller;

import java.util.Date;
import java.util.Objects;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sense.security.model.AuthenticationException;
import com.sense.security.model.JwtAuthenticationRequest;
import com.sense.security.model.JwtAuthenticationResponse;
import com.sense.security.model.JwtUserDetails;
import com.sense.security.service.JwtUserDetailsService;
import com.sense.security.util.JwtTokenUtil;
import com.sense.sensemodel.model.users.AccessType;
import com.sense.users.service.UserService;

@RestController
@RequestMapping("user/auth")
public class LoginController {

    private Logger logger = LoggerFactory.getLogger(LoginController.class);

    @Autowired
    private JwtUserDetailsService userDetailsService;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private UserService userService;

    /*
     * Enables the user to login and create an accessToken that contains all the
     * user access rights and list of accessible assets and org parts.
     */
    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public ResponseEntity<?> createAuthenticationToken(@RequestBody JwtAuthenticationRequest authenticationRequest,
            @RequestParam(name = "loginMode") UserLoginMode loginMode) throws AuthenticationException {
        authenticate(authenticationRequest.getUserId(), authenticationRequest.getPassword());
        final JwtUserDetails userDetails = userDetailsService.loadUserByUsername(authenticationRequest.getUserId());
        if (loginMode.equals(UserLoginMode.ADMIN) && !userDetails.getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals(AccessType.ADMIN_LOGIN.name()))) {
            logger.error("Login mode " + loginMode + " not allowed for user " + userDetails.getUsername());
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body("Login mode " + loginMode + " not allowed for user " + userDetails.getUsername());
        }
        final String token = jwtTokenUtil.generateToken(userDetails);
        userService.setLastLogin(authenticationRequest.getUserId(), new Date());
        return ResponseEntity.ok(new JwtAuthenticationResponse(token, userDetails.getCompany()));
    }

    private void authenticate(String userId, String password) {
        Objects.requireNonNull(userId);
        Objects.requireNonNull(password);

        try {
            authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(userId, password));
        } catch (DisabledException e) {
            throw new AuthenticationException("User is disabled!", e);
        } catch (BadCredentialsException e) {
            throw new AuthenticationException("Bad credentials!", e);
        }
    }

    @RequestMapping(value = "/refresh", method = RequestMethod.GET)
    public ResponseEntity<?> refreshAndGetAuthenticationToken(HttpServletRequest request) {
        String authToken = request.getHeader("Authorization");
        final String token = authToken.substring(7);
        String username = jwtTokenUtil.getUserNameFromToken(token);
        JwtUserDetails user = userDetailsService.loadUserByUsername(username);

        // TODO //if (jwtTokenUtil.canTokenBeRefreshed(token,
        // user.getLastPasswordResetDate())) {
        String refreshedToken = jwtTokenUtil.refreshToken(token);
        userService.setLastLogin(username, new Date());
        return ResponseEntity.ok(new JwtAuthenticationResponse(refreshedToken, user.getCompany()));

        // } else { return ResponseEntity.badRequest().body(null); }

    }

    @ExceptionHandler({ AuthenticationException.class })
    public ResponseEntity<String> handleAuthenticationException(AuthenticationException e) {
        logger.error("Authentication error: " + e);
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(e.getMessage());
    }

    @ExceptionHandler({ Exception.class })
    public ResponseEntity<String> handleUncaughtException(Exception e) {
        logger.error("Uncaught error: " + e);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
    }

    @RequestMapping(value = "/logout", method = RequestMethod.GET)
    ResponseEntity<?> logout(HttpSession session) {
        if (session != null)
            session.invalidate();
        return new ResponseEntity<>("logged out", HttpStatus.OK);
    }

    @RequestMapping(value = "/changePassword", method = RequestMethod.PUT)
    ResponseEntity<?> changePassword(@RequestBody JwtAuthenticationRequest authenticationRequest) {
        authenticate(authenticationRequest.getUserId(), authenticationRequest.getPassword());
        userService.changePassword(authenticationRequest.getUserId(), authenticationRequest.getNewPassword());
        return new ResponseEntity<>("password changed successfully", HttpStatus.OK);
    }

    enum UserLoginMode {
        ADMIN, USER
    }
}

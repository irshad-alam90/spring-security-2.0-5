package com.sense.users.controller;

import java.util.Set;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sense.security.util.JwtTokenUtil;
import com.sense.sensemodel.model.users.AccessType;
import com.sense.sensemodel.model.users.Role;
import com.sense.sensemodel.model.users.User;
import com.sense.users.model.ModifyDepartmentRequest;
import com.sense.users.model.UpdateUserRequest;
import com.sense.users.service.UserService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;

@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
	private UserService userService;

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	private Logger logger = LoggerFactory.getLogger(UserController.class);

	/*
	 * Creates admin department and role for admin rights like create_user
	 */
	@RequestMapping(value = "/createAdminDepartmentAndRole", method = RequestMethod.PUT)
	@PreAuthorize("hasAuthority('SENSE_ADMIN')")
	ResponseEntity<?> createAdminDepartmentAndRole(@RequestParam("company") String company,
			@RequestParam("companyAdminEmail") String companyAdminEmail) {
		try {
			userService.createAdminDepartmentAndRoleAndUser(company, companyAdminEmail);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error creating admin department for company" + company, e);
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@RequestMapping(value = "/createDepartment", method = RequestMethod.PUT)
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization token", dataType = "string", paramType = "header") })
	ResponseEntity<?> createDepartment(@RequestParam("departmentName") String departmentName,
			@RequestParam("company") String company, @RequestParam("assetTypeNames") Set<String> assetTypeNames) {
		try {
			userService.addDepartmentToCompany(departmentName, company, assetTypeNames);
			return new ResponseEntity<>("created", HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error creating department: " + departmentName + " for company" + company, e);
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/*
	 * Get departments with all its roles
	 */
	@RequestMapping(value = "/getDepartments", method = RequestMethod.GET)
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization token", dataType = "string", paramType = "header") })
	ResponseEntity<?> getDepartments(@RequestParam("company") String company) {
		try {
			return new ResponseEntity<>(userService.getDepartmentsForCompany(company), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error getting departments for: " + company, e);
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@RequestMapping(value = "/getDepartmentsByCode", method = RequestMethod.GET)
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization token", dataType = "string", paramType = "header") })
	ResponseEntity<?> getDepartmentsByCode(@RequestParam("codes") Set<String> departmentCodes) {
		try {
			return new ResponseEntity<>(userService.getDepartmentsByCode(departmentCodes), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error getting departments by codes ", e);
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@RequestMapping(value = "/modifyDepartment", method = RequestMethod.POST)
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization token", dataType = "string", paramType = "header") })
	ResponseEntity<?> modifyDepartment(@RequestBody ModifyDepartmentRequest modifyDepartmentRequest) {
		try {
			userService.modifyDepartment(modifyDepartmentRequest);
			return new ResponseEntity<>("modified", HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error modifying department: " + modifyDepartmentRequest.getDepartmentCode(), e);
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@RequestMapping(value = "/deleteDepartment", method = RequestMethod.DELETE)
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization token", dataType = "string", paramType = "header") })
	ResponseEntity<?> deleteDepartment(@RequestParam("department") String departmentCode) {
		try {
			userService.deleteDepartment(departmentCode);
			return new ResponseEntity<>("deleted", HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error deleting department: " + departmentCode, e);
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/*
	 * Create a role and attach it to a parent role in the company hierarchy Root
	 * role is always admin
	 */
	@RequestMapping(value = "/createRole", method = RequestMethod.PUT)
	ResponseEntity<?> createRole(@RequestParam("parent") String parentDepRoleId, @RequestBody Role newRole,
			@RequestParam("company") String company) {
		try {
			userService.addRole(newRole, parentDepRoleId, company);
			return new ResponseEntity<>("created", HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error adding department role under: " + parentDepRoleId, e);
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@RequestMapping(value = "/deleteRole", method = RequestMethod.DELETE)
	ResponseEntity<?> deleteRole(@RequestParam("roleCode") String roleCode) {
		try {
			userService.deleteRole(roleCode);
			return new ResponseEntity<>("deleted", HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error deleting role: " + roleCode, e);
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@RequestMapping(value = "/getRolesByCode", method = RequestMethod.GET)
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization token", dataType = "string", paramType = "header") })
	ResponseEntity<?> getRolesByCode(@RequestParam("codes") Set<String> roleCodes) {
		try {
			return new ResponseEntity<>(userService.getRolesByCode(roleCodes), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error getting roles by codes ", e);
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@RequestMapping(value = "/createUser", method = RequestMethod.PUT)
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization token", dataType = "string", paramType = "header") })
	@PreAuthorize("hasAuthority('CREATE_USER') or hasAuthority('SENSE_ADMIN')")
	ResponseEntity<?> createUser(@RequestBody User newUser, HttpServletRequest req, Authentication authentication) {
		try {
			String bearerToken = resolveToken(req);
			String userCompany = jwtTokenUtil.getUserCompanyFromToken(bearerToken);
			boolean isSenseAdmin = isSenseAdmin(authentication);
			if (!isSenseAdmin && !newUser.getCompanyId().equals(userCompany)) {
				return new ResponseEntity<>("Can't create user for another company: " + newUser.getCompanyId(),
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
			newUser.setCreatedBy(authentication.getName());
			userService.createUser(newUser);
			return new ResponseEntity<>("created", HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error adding user: " + newUser.getUserId(), e);
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@RequestMapping(value = "/updateUser", method = RequestMethod.POST)
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization token", dataType = "string", paramType = "header") })
	ResponseEntity<?> updateUser(@RequestBody UpdateUserRequest updateUserRequest, Authentication authentication) {
		try {
			String userId;
			if (isSenseAdmin(authentication)) {
				userId = updateUserRequest.getUserId();
			} else {
				userId = authentication.getName();
				if (!userId.equals(updateUserRequest.getUserId())) {
					return new ResponseEntity<>(
							"Can't update details for another user: " + updateUserRequest.getUserId(),
							HttpStatus.INTERNAL_SERVER_ERROR);
				}
			}
			return new ResponseEntity<>(userService.updateUser(updateUserRequest, userId), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error updating user: " + authentication.getName(), e);
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@RequestMapping(value = "/disableUser", method = RequestMethod.POST)
	@PreAuthorize("hasAuthority('ADMIN_LOGIN') or hasAuthority('SENSE_ADMIN')")
	ResponseEntity<?> disableUser(@RequestParam("userId") String userId) {
		try {
			userService.disableUser(userId);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error disabling user: " + userId, e);
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@RequestMapping(value = "/searchUser", method = RequestMethod.GET)
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization token", dataType = "string", paramType = "header") })
	ResponseEntity<?> searchUser(@RequestParam("name") String name, @RequestParam("companyId") String companyId,
			HttpServletRequest req, Authentication authentication) {
		try {
			String bearerToken = resolveToken(req);
			String userCompany = jwtTokenUtil.getUserCompanyFromToken(bearerToken);
			boolean isSenseAdmin = isSenseAdmin(authentication);
			if (!isSenseAdmin && companyId.equals(userCompany)) {
				return new ResponseEntity<>("Can't search for user for another company: " + companyId,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
			return new ResponseEntity<>(userService.searchUser(name, companyId), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error searching user: " + name + " in company: " + companyId, e);
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/*
	 * Get user access object with accessible assets, org parts and access rights
	 */
	@RequestMapping(value = "/getUserAccess", method = RequestMethod.GET)
	ResponseEntity<?> getUserAccess(@RequestParam("orgs") boolean orgs, @RequestParam("assets") boolean assets,
			@RequestParam("departments") boolean departments, Authentication authentication) {
		try {
			return new ResponseEntity<>(userService.getUseraccess(authentication.getName(), orgs, assets, departments),
					HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error getting access for: " + authentication.getName(), e);
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@RequestMapping(value = "/getAccessRights", method = RequestMethod.GET)
	ResponseEntity<?> getAccessRights(@RequestParam("company") String company) {
		try {
			return new ResponseEntity<>(userService.getAccessRights(company), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error getting access rights for: " + company, e);
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@RequestMapping(value = "/isOrgAccessible", method = RequestMethod.GET)
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization token", dataType = "string", paramType = "header") })
	ResponseEntity<?> isOrgAccessible(@RequestParam("orgId") String orgId, Authentication authentication) {
		try {
			Set<String> userOrgParts = authentication.getAuthorities().stream()
					.filter(a -> a.getAuthority().startsWith("ORGPART_"))
					.map(a -> a.getAuthority().replace("ORGPART_", "")).collect(Collectors.toSet());
			return new ResponseEntity<>(userService.isOrgAccessible(orgId, userOrgParts), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error checking access for org: " + orgId, e);
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@RequestMapping(value = "/isAssetAccessible", method = RequestMethod.GET)
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization token", dataType = "string", paramType = "header") })
	ResponseEntity<?> isAssetAccessible(@RequestParam("assetCode") String assetCode, Authentication authentication) {
		try {
			Set<String> userOrgParts = authentication.getAuthorities().stream()
					.filter(a -> a.getAuthority().startsWith("ORGPART_"))
					.map(a -> a.getAuthority().replace("ORGPART_", "")).collect(Collectors.toSet());
			Set<String> userAssetTypes = authentication.getAuthorities().stream()
					.filter(a -> a.getAuthority().startsWith("ASSETTYPE_"))
					.map(a -> a.getAuthority().replace("ASSETTYPE_", "")).collect(Collectors.toSet());
			return new ResponseEntity<>(userService.isAssetAccessible(assetCode, userOrgParts, userAssetTypes),
					HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error checking access for asset: " + assetCode, e);
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@RequestMapping(value = "/getMyDetails", method = RequestMethod.GET)
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization token", dataType = "string", paramType = "header") })
	ResponseEntity<?> getMyDetails(Authentication authentication) {
		try {
			return new ResponseEntity<>(userService.getMyDetails(authentication.getName()), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error getting my details for: " + authentication.getName(), e);
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	private String resolveToken(HttpServletRequest req) {
		String bearerToken = req.getHeader("Authorization");
		if (bearerToken != null && bearerToken.startsWith("Bearer ")) {
			return bearerToken.substring(7, bearerToken.length());
		}
		return null;
	}

	private boolean isSenseAdmin(Authentication authentication) {
		return authentication.getAuthorities().stream()
				.anyMatch(a -> a.getAuthority().equals(AccessType.SENSE_ADMIN.name()));
	}
}
package com.sense.users.service;

import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.neo4j.ogm.session.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.simpleemail.AmazonSimpleEmailService;
import com.amazonaws.services.simpleemail.AmazonSimpleEmailServiceClientBuilder;
import com.amazonaws.services.simpleemail.model.Body;
import com.amazonaws.services.simpleemail.model.Content;
import com.amazonaws.services.simpleemail.model.Destination;
import com.amazonaws.services.simpleemail.model.Message;
import com.amazonaws.services.simpleemail.model.SendEmailRequest;
import com.sense.sensemodel.model.assets.Asset;
import com.sense.sensemodel.model.assets.AssetType;
import com.sense.sensemodel.model.organisation.Organisation;
import com.sense.sensemodel.model.users.AccessRight;
import com.sense.sensemodel.model.users.AccessType;
import com.sense.sensemodel.model.users.Department;
import com.sense.sensemodel.model.users.Role;
import com.sense.sensemodel.model.users.User;
import com.sense.sensemodel.model.users.UserAccess;
import com.sense.sensemodel.repository.assets.AssetRepository;
import com.sense.sensemodel.repository.assets.AssetTypeRepository;
import com.sense.sensemodel.repository.organisation.OrganisationRepository;
import com.sense.sensemodel.repository.users.AccessRightRepository;
import com.sense.sensemodel.repository.users.DepartmentRepository;
import com.sense.sensemodel.repository.users.RoleRepository;
import com.sense.sensemodel.repository.users.UserRepository;
import com.sense.users.model.ModifyDepartmentRequest;
import com.sense.users.model.UpdateUserRequest;
import com.sense.users.model.UpdateUserRequest.DepartmentRoleRequest;
import com.sense.users.model.UpdateUserRequest.UpdateRightsMode;

@Service
public class UserService {
	// private Logger logger = LoggerFactory.getLogger(UserService.class);

	@Autowired
	private DepartmentRepository departmentRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private AccessRightRepository accessRightRepository;

	@Autowired
	private RoleRepository rolesRepository;

	@Autowired
	private AssetTypeRepository assetTypeRepository;

	@Autowired
	private AssetRepository assetRepository;

	@Autowired
	private OrganisationRepository organisationRepository;

	@Autowired
	private Session dbSession;
	
	@Value("${userServiceUrl}")
	private String userServiceUrl;

	//TODO: set in dev properties as well
	@Value("${fromProbusMail}")
	private String fromProbusMail;

	BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

	public void createAdminDepartmentAndRoleAndUser(String company, String companyAdminEmail) throws Exception {
		Set<Department> existingDepartments = departmentRepository.findByCompanyIdAndActiveInd(company, true);
		if (existingDepartments.stream()
				.anyMatch(d -> d.getName().equals(Department.KnowDepartmentType.ADMIN.name()))) {
			throw new RuntimeException("Admin department already exists for: " + company);
		}
		Set<String> adminAccessRights = Stream.of(AccessType.ASSET_ADMIN.name(), AccessType.ORG_ADMIN.name(),
				AccessType.CREATE_USER.name(), AccessType.ADMIN_LOGIN.name()).collect(Collectors.toSet());
		Set<AccessRight> accessRights = accessRightRepository.findByAccessTypeInAndCompanyIn(adminAccessRights,
				new HashSet<String>(Arrays.asList(company, "ALL")));
		if (adminAccessRights.size() != accessRights.size()) {
			throw new RuntimeException("access rights mismatch while fetching. Returned : "
					+ StringUtils.join(" ",
							accessRights.stream().map(r -> r.getAccessType()).collect(Collectors.toSet()))
					+ " requested: " + StringUtils.join(" ", adminAccessRights));
		}
		Role adminRole = new Role(Role.KnownRoleType.Admin_Role.name(), null, accessRights);
		Department adminDepartment = new Department(Department.KnowDepartmentType.ADMIN.name(), company, adminRole,
				null);
		adminDepartment = departmentRepository.save(adminDepartment);
		Map<String, String> adminDepRoles = new HashMap<>();
		adminDepRoles.put(adminDepartment.getCode(), adminDepartment.getRootRole().getCode());
		User adminUser = new User(company + "_admin", company + "_admin", companyAdminEmail, "admin", "Admin",
				adminDepRoles, adminRole.getAllowedAccessRights(), new HashSet<String>(Arrays.asList(company)),
				company);
		createUser(adminUser);
	}

	public void addDepartmentToCompany(String departmentName, String company, Set<String> assetTypeNames) {
		Set<AssetType> assetTypes = assetTypeRepository.findByCompanyAndTypeIn(company, assetTypeNames);
		if (!(assetTypeNames.size() == assetTypes.size()) || !(assetTypes.stream().map(at -> at.getType())
				.collect(Collectors.toSet()).containsAll(assetTypeNames)))
			throw new RuntimeException("asset type mismatch while fetching. Returned : "
					+ StringUtils.join(" ", assetTypes.stream().map(at -> at.getType()).collect(Collectors.toSet()))
					+ " requested: " + StringUtils.join(" ", assetTypeNames));
		Set<AccessRight> accessRights = accessRightRepository.findByAccessTypeInAndCompanyIn(
				AccessRight.standardAccessRights, new HashSet<String>(Arrays.asList(company, "ALL")));
		Role departmentHeadRole = new Role("Head", null, accessRights);
		Department newDepartment = new Department(departmentName, company, departmentHeadRole, assetTypes);
		departmentRepository.save(newDepartment);
	}

	public Set<Department> getDepartmentsForCompany(String company) {
		Set<Department> departments = departmentRepository.findByCompanyIdAndActiveInd(company, true);
		for (Department d : departments) {
			Set<Role> subRoles = rolesRepository.findRolesByParentDepartment(d.getCode());
			d.setSubRolesList(subRoles);
		}
		return departments;
	}

	public Set<Department> getDepartmentsByCode(Set<String> depCodes) {
		return departmentRepository.findByCodeInAndActiveInd(depCodes, true);
	}

	public void deleteDepartment(String departmentCode) {
		Department department = departmentRepository.findByCodeAndActiveInd(departmentCode, true)
				.orElseThrow(() -> new RuntimeException("department not found: " + departmentCode));
		department.setActiveInd(false);
		departmentRepository.save(department);
		String removeFromUsersQuery = String.format(
				"Match(u:User) where u.`departmentRoles.%s` is not null REMOVE u.`departmentRoles.%s`", departmentCode,
				departmentCode);
		dbSession.query(removeFromUsersQuery, Collections.emptyMap());
	}

	public void modifyDepartment(ModifyDepartmentRequest modifyDepartmentRequest) {
		Department department = departmentRepository
				.findByCodeAndActiveInd(modifyDepartmentRequest.getDepartmentCode(), true)
				.orElseThrow(() -> new RuntimeException(
						"department not found: " + modifyDepartmentRequest.getDepartmentCode()));
		for (String assetType : modifyDepartmentRequest.getModifyAssetsTypes().keySet()) {
			switch (modifyDepartmentRequest.getModifyAssetsTypes().get(assetType)) {
			case ADD:
				AssetType addAssetType = assetTypeRepository.findByCompanyAndType(department.getCompanyId(), assetType)
						.orElseThrow(() -> new RuntimeException("Requested assetType not found: " + assetType));
				department.getAccessibleAssetTypes().add(addAssetType);
				break;
			case DELETE:
				department.getAccessibleAssetTypes().removeIf(at -> at.getType().equals(assetType));
				break;
			}
		}
		departmentRepository.save(department);
	}

	public Role addRole(Role newRole, String parentDepRoleId, String company) {
		Role parent = rolesRepository.findByCodeAndActiveInd(parentDepRoleId, true)
				.orElseThrow(() -> new RuntimeException("Role not found: " + parentDepRoleId));
		if (!parent.getAllowedAccessRights().containsAll(newRole.getAllowedAccessRights())) {
			throw new RuntimeException("sub role rights:" + StringUtils.join(" ", newRole.getAllowedAccessRights())
					+ "must be subset of parent role rights:" + StringUtils.join(" ", parent.getAllowedAccessRights()));
		}
		Set<AccessRight> existingAccessRights = accessRightRepository.findByAccessTypeInAndCompanyIn(
				newRole.getAllowedAccessRights().stream().map(ar -> ar.getAccessType()).collect(Collectors.toSet()),
				new HashSet<String>(Arrays.asList(company, "ALL")));
		newRole.setAllowedAccessRights(existingAccessRights);
		newRole = new Role(newRole.getName(), parent, newRole.getAllowedAccessRights());
		return rolesRepository.save(newRole);
	}

	public void deleteRole(String roleCode) {
		Set<Role> rootAndSubRoles = rolesRepository.getRoleAndSubRoles(roleCode);
		Department parentDepartment = rolesRepository.findParentDepartment(roleCode)
				.orElseThrow(() -> new RuntimeException("Root department not found for role: " + roleCode));
		Set<String> rootAndSubRolesCodes = rootAndSubRoles.stream().map(r -> r.getCode()).collect(Collectors.toSet());
		// Assuming user has has only one of these roles in parent department so
		// removing department
		String removeFromUsersQuery = String.format(
				"Match(u:User) where u.`departmentRoles.%s` in {rootAndSubRolesCodes} REMOVE u.`departmentRoles.%s`",
				parentDepartment.getCode(), parentDepartment.getCode());
		Map<String, Object> params = new HashMap<>();
		params.put("rootAndSubRolesCodes", rootAndSubRolesCodes);
		rootAndSubRoles.stream().forEach(r -> r.setActiveInd(false));
		dbSession.query(removeFromUsersQuery, params);
		rolesRepository.saveAll(rootAndSubRoles);
	}

	public Set<Role> getRolesByCode(Set<String> roleCodes) {
		return rolesRepository.findByCodeInAndActiveInd(roleCodes, true);
	}

	public void createUser(User user) throws Exception {
		if (user.getUserId() == null || user.getUserId().equals("")) {
			throw new RuntimeException("user id can't be blank");
		}
		if (user.getPswrd() == null || user.getPswrd().equals("")) {
			throw new RuntimeException("password can't be blank");
		}
		if (user.getEmail() == null || user.getEmail().equals("")) {
			throw new RuntimeException("email can't be blank");
		}
		if (userRepository.findByUserIdAndEnabled(user.getUserId(), true).isPresent()) {
			throw new RuntimeException("user already exists:" + user.getUserId());
		}
		checkDepartmentsAndRoles(user.getDepartmentRoles().keySet(), new HashSet<>(user.getDepartmentRoles().values()));
		Set<Organisation> existingOrgParts = organisationRepository.findByEntityIdInAndActiveInd(user.getOrgParts(),
				true);
		if (!(existingOrgParts.size() == user.getOrgParts().size()))
			throw new RuntimeException("one of org part codes not found in db: "
					+ StringUtils.join(" ", user.getOrgParts()) + " found: " + StringUtils.join(" ",
							existingOrgParts.stream().map(o -> o.getEntityId()).collect(Collectors.toSet())));
		user.getAccessRights().removeIf(ar -> ar.getAccessType().equals("SENSE_ADMIN"));
		user.setAccessRights(findAccessRights(
				user.getAccessRights().stream().map(ar -> ar.getAccessType()).collect(Collectors.toSet()),
				user.getCompanyId()));
		user.setCreationDate(new Date());
		user.setPswrd(encoder.encode(user.getPswrd()));
		user.setEnabled(true);
		userRepository.save(user);
		sendUserCreationEmail(user.getEmail());
	}

	protected void sendUserCreationEmail(String userEmail) throws Exception {
		AWSCredentialsProvider obj = new AWSCredentialsProvider() {
			@Override
			public void refresh() {
			}

			@Override
			public AWSCredentials getCredentials() {
				// TODO: Create new credentials for this
				final BasicAWSCredentials creds = new BasicAWSCredentials("AKIAXGOZXBPZ7MC6K5OT",
						"0ZmV7Rz3mDzOSroXuqp6UXyx6RLedX3mu7iEWC2M");
				return creds;
			}
		};
		AmazonSimpleEmailService client = AmazonSimpleEmailServiceClientBuilder.standard().withRegion(Regions.US_WEST_2)
				.withCredentials(obj).build();
		SendEmailRequest request = new SendEmailRequest().withDestination(new Destination().withToAddresses(userEmail))
				.withMessage(
						new Message()
								.withBody(new Body()
										.withHtml(new Content().withCharset("UTF-8")
												.withData("<a href='" + userServiceUrl
														+ "'/login/changePassword'>Change password</a>"))
										.withText(new Content().withCharset("UTF-8")
												.withData("Change password using the provided link")))
								.withSubject(new Content().withCharset("UTF-8").withData("sense user creation mail")))
				.withSource(fromProbusMail);
		client.sendEmail(request);
		System.out.println("Email sent!");
	}

	private Set<AccessRight> findAccessRights(Set<String> requestedRights, String company) {
		requestedRights.removeIf(r -> r.equals(AccessType.SENSE_ADMIN.name()));
		Set<AccessRight> foundAccessRights = accessRightRepository.findByAccessTypeInAndCompanyIn(requestedRights,
				new HashSet<String>(Arrays.asList(company, "ALL")));
		if (!(foundAccessRights.size() == requestedRights.size()))
			throw new RuntimeException("one of requested rights not found in db: "
					+ StringUtils.join(" ", requestedRights) + " found: " + StringUtils.join(" ",
							foundAccessRights.stream().map(ar -> ar.getAccessType()).collect(Collectors.toSet())));
		return foundAccessRights;
	}

	private void checkDepartmentsAndRoles(Set<String> requestedDepartments, Set<String> requestedRoles) {
		Set<Department> existingDeps = departmentRepository.findByCodeInAndActiveInd(requestedDepartments, true);
		if (!(existingDeps.size() == requestedDepartments.size()))
			throw new RuntimeException("one of department codes not found in db: "
					+ StringUtils.join(" ", requestedDepartments) + " found: "
					+ StringUtils.join(" ", existingDeps.stream().map(d -> d.getCode()).collect(Collectors.toSet())));
		Set<Role> existingRoles = rolesRepository.findByCodeInAndActiveInd(requestedRoles, true);
		if (!(existingRoles.size() == requestedRoles.size()))
			throw new RuntimeException("one of role codes not found in db: " + StringUtils.join(" ", requestedRoles)
					+ " found: "
					+ StringUtils.join(" ", existingRoles.stream().map(r -> r.getCode()).collect(Collectors.toSet())));
	}

	@Transactional
	public User updateUser(UpdateUserRequest updateUserRequest, String userId) {
		User user = userRepository.findByUserIdAndEnabled(userId, true)
				.orElseThrow(() -> new RuntimeException("user not found:" + userId));
		if (StringUtils.isNotEmpty(updateUserRequest.getNewEmail()))
			user.setEmail(updateUserRequest.getNewEmail());
		if (StringUtils.isNotEmpty(updateUserRequest.getNewDesignation()))
			user.setDesignation(updateUserRequest.getNewDesignation());
		if (StringUtils.isNotEmpty(updateUserRequest.getNewName()))
			user.setName(updateUserRequest.getNewName());
		if (StringUtils.isNotEmpty(updateUserRequest.getNewPhone()))
			user.setPhone(updateUserRequest.getNewPhone());

		if (updateUserRequest.getUpdateAccessRights().containsKey(UpdateRightsMode.ADD)) {
			Set<AccessRight> rightsToAdd = findAccessRights(
					updateUserRequest.getUpdateAccessRights().get(UpdateRightsMode.ADD), user.getCompanyId());
			user.getAccessRights().addAll(rightsToAdd);
		}
		if (updateUserRequest.getUpdateAccessRights().containsKey(UpdateRightsMode.DELETE)) {
			for (String rightToDelete : updateUserRequest.getUpdateAccessRights().get(UpdateRightsMode.DELETE)) {
				user.getAccessRights().removeIf(ar -> ar.getAccessType().equals(rightToDelete));
			}
		}
		checkDepartmentsAndRoles(
				updateUserRequest.getUpdateDepartmentRoles().stream().map(r -> r.getDepartment())
						.collect(Collectors.toSet()),
				updateUserRequest.getUpdateDepartmentRoles().stream().map(r -> r.getRole())
						.collect(Collectors.toSet()));
		for (DepartmentRoleRequest updateDepRole : updateUserRequest.getUpdateDepartmentRoles()) {
			switch (updateDepRole.getMode()) {
			case ADD:
			case UPDATE:
				user.getDepartmentRoles().put(updateDepRole.getDepartment(), updateDepRole.getRole());
				break;
			case DELETE:
				String removeFromUserQuery = String.format(
						"Match(u:User) where u.userId = {userId} and "
								+ "u.`departmentRoles.%s` = {role} REMOVE u.`departmentRoles.%s`",
						updateDepRole.getDepartment(), updateDepRole.getDepartment());
				Map<String, Object> params = new HashMap<>();
				params.put("userId", userId);
				params.put("role", updateDepRole.getRole());
				dbSession.query(removeFromUserQuery, params);
			}
		}
		return userRepository.save(user);
	}

	public void setLastLogin(String userId, Date loginTime) {
		User user = userRepository.findByUserIdAndEnabled(userId, true)
				.orElseThrow(() -> new RuntimeException("user not found:" + userId));
		user.setLastLoginTime(loginTime);
		userRepository.save(user);
	}

	public void disableUser(String userId) {
		User user = userRepository.findByUserIdAndEnabled(userId, true)
				.orElseThrow(() -> new RuntimeException("user not found:" + userId));
		user.setEnabled(false);
		userRepository.save(user);
	}

	public void changePassword(String userId, String newPassword) {
		User user = userRepository.findByUserIdAndEnabled(userId, true)
				.orElseThrow(() -> new RuntimeException("user not found:" + userId));
		user.setPswrd(encoder.encode(newPassword));
		userRepository.save(user);
	}

	public Set<User> searchUser(String name, String companyId) {
		return userRepository.findByNameRegexAndCompanyId(name + ".*", companyId);
	}

	public UserAccess getUseraccess(String userId, boolean orgs, boolean assets, boolean departments) {
		User user = userRepository.findByUserIdAndEnabled(userId, true)
				.orElseThrow(() -> new RuntimeException("user not found:" + userId));
		Set<Department> userDepartments = null;
		if (departments) {
			userDepartments = departmentRepository.findByCodeInAndActiveInd(user.getDepartmentRoles().keySet(), true);
		}
		Set<String> accessibleOrgParts = null;
		if (orgs) {
			accessibleOrgParts = organisationRepository.findActiveSubOrgsIdsByOrgIdIn(user.getOrgParts());
			accessibleOrgParts.addAll(user.getOrgParts());
		}
		Set<String> accessibleAssets = null;
		if (assets) {
			Set<String> accessibleAssetTypes = userDepartments.stream()
					.flatMap(d -> d.getAccessibleAssetTypes().stream()).map(at -> at.getType())
					.collect(Collectors.toSet());
			accessibleAssets = assetRepository
					.getAllChildrenAssetsCodesForOrgEntityIdInAndAssetTypeIn(accessibleOrgParts, accessibleAssetTypes);
		}
		return new UserAccess(userId, accessibleOrgParts, accessibleAssets);
	}

	public User getMyDetails(String userId) {
	User user = userRepository.findByUserIdAndEnabled(userId, true)
				.orElseThrow(() -> new RuntimeException("user not found:" + userId));
		User details = new User(user.getUserId(), user.getName(), user.getEmail(), null, user.getDesignation(),
				user.getDepartmentRoles(), null, null, null);
		return details;
	}

	public boolean isOrgAccessible(String orgId, Set<String> userOrgParts) {
		if (userOrgParts.contains(orgId))
			return true;
		Optional<Organisation> accessibleOrg = organisationRepository.isOrgAccessible(orgId, userOrgParts);
		if (!accessibleOrg.isPresent())
			return false;
		if (accessibleOrg.get().getEntityId().equals(orgId))
			return true;
		return false;
	}

	public boolean isAssetAccessible(String assetCode, Set<String> userOrgParts, Set<String> userAssetTypes) {
		Optional<Asset> accessibleAsset = assetRepository.isAssetAccessible(assetCode, userOrgParts, userAssetTypes);
		if (!accessibleAsset.isPresent())
			return false;
		if (accessibleAsset.get().getCode().equals(assetCode))
			return true;
		return false;
	}

	public Set<AccessRight> getAccessRights(String company) {
		return accessRightRepository.findByCompanyIn(Stream.of(company, "ALL").collect(Collectors.toSet()));
	}
}
